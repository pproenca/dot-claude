---
name: python-best-practices
description: Python performance optimization guidelines. This skill should be used when writing, reviewing, or refactoring Python code to ensure optimal performance patterns. Triggers on tasks involving I/O operations, memory management, async programming, data processing, or performance improvements.
---

# Python Best Practices

## Overview

Comprehensive performance optimization guide for Python applications, containing 45+ rules across 8 categories. Rules are prioritized by impact to guide automated refactoring and code generation.

## When to Apply

Reference these guidelines when:
- Writing new Python code
- Implementing data processing pipelines
- Reviewing code for performance issues
- Refactoring existing Python code
- Optimizing I/O operations or memory usage

## Priority-Ordered Guidelines

Rules are prioritized by impact:

| Priority | Category | Impact |
|----------|----------|--------|
| 1 | I/O Optimization | CRITICAL |
| 2 | Memory Management | CRITICAL |
| 3 | Async/Await Patterns | HIGH |
| 4 | Data Structures | MEDIUM-HIGH |
| 5 | Imports & Modules | MEDIUM |
| 6 | Iteration Patterns | MEDIUM |
| 7 | String Operations | LOW-MEDIUM |
| 8 | Advanced Patterns | LOW |

## Quick Reference

### Critical Patterns (Apply First)

**I/O Optimization:**
- Use context managers for file handling
- Buffer file reads/writes appropriately
- Use `mmap` for large file access
- Batch database operations
- Use connection pooling

**Memory Management:**
- Use generators instead of lists for large sequences
- Use `__slots__` for memory-heavy classes
- Avoid circular references
- Use `weakref` for caches
- Profile with `tracemalloc`

### High-Impact Async Patterns

- Use `asyncio.gather()` for concurrent operations
- Avoid blocking calls in async functions
- Use `asyncio.Queue` for producer-consumer
- Use `async with` for async context managers

### Medium-Impact Data Patterns

- Use `set` for O(1) membership testing
- Use `collections.deque` for queue operations
- Use `bisect` for sorted list operations
- Use `dataclasses` over manual `__init__`

### Iteration Patterns

- Use list comprehensions over `map()`/`filter()`
- Use `itertools` for complex iterations
- Avoid repeated indexing in loops
- Use `enumerate()` instead of manual counters

### String Patterns

- Use `str.join()` for concatenation
- Use f-strings over `format()` or `%`
- Compile regex patterns once
- Use `str` methods before regex

## References

Full documentation with code examples is available in:

- `references/python-performance-guidelines.md` - Complete guide with all patterns
- `references/rules/` - Individual rule files organized by category

To look up a specific pattern, grep the rules directory:
```
grep -l "generator" references/rules/
grep -l "asyncio" references/rules/
grep -l "memory" references/rules/
```

## Rule Categories in `references/rules/`

- `io-*` - I/O optimization patterns
- `memory-*` - Memory management techniques
- `async-*` - Async/await patterns
- `data-*` - Data structure selection
- `imports-*` - Import and module patterns
- `iter-*` - Iteration optimization
- `strings-*` - String operation patterns
- `advanced-*` - Advanced optimization techniques
