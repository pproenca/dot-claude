# Python Best Practices

**Version 0.1.0**
Engineering Guidelines
January 2026

> **Note:**
> This document is mainly for agents and LLMs to follow when maintaining,
> generating, or refactoring Python codebases. Humans may also find it useful,
> but guidance here is optimized for automation and consistency by AI-assisted workflows.

---

## Abstract

Comprehensive performance optimization guide for Python applications, designed for AI agents and LLMs. Contains 45+ rules across 8 categories, prioritized by impact from critical (I/O optimization, memory management) to incremental (advanced patterns). Each rule includes detailed explanations, real-world examples comparing incorrect vs. correct implementations, and specific impact metrics to guide automated refactoring and code generation.

---

## Table of Contents

1. [I/O Optimization](#1-io-optimization) — **CRITICAL**
   - 1.1 [Use Context Managers for File Handling](#11-use-context-managers-for-file-handling)
   - 1.2 [Buffer File Reads and Writes](#12-buffer-file-reads-and-writes)
   - 1.3 [Use mmap for Large File Access](#13-use-mmap-for-large-file-access)
   - 1.4 [Batch Database Operations](#14-batch-database-operations)
   - 1.5 [Use Connection Pooling](#15-use-connection-pooling)
   - 1.6 [Use pathlib for Path Operations](#16-use-pathlib-for-path-operations)
2. [Memory Management](#2-memory-management) — **CRITICAL**
   - 2.1 [Use Generators Instead of Lists](#21-use-generators-instead-of-lists)
   - 2.2 [Use __slots__ for Memory-Heavy Classes](#22-use-slots-for-memory-heavy-classes)
   - 2.3 [Use weakref for Caches](#23-use-weakref-for-caches)
   - 2.4 [Explicitly Delete Large Objects](#24-explicitly-delete-large-objects)
   - 2.5 [Avoid Unnecessary Data Copies](#25-avoid-unnecessary-data-copies)
   - 2.6 [Intern Repeated Strings](#26-intern-repeated-strings)
3. [Async/Await Patterns](#3-asyncawait-patterns) — **HIGH**
   - 3.1 [Use asyncio.gather for Concurrent Operations](#31-use-asynciogather-for-concurrent-operations)
   - 3.2 [Avoid Blocking Calls in Async Functions](#32-avoid-blocking-calls-in-async-functions)
   - 3.3 [Use asyncio.Queue for Producer-Consumer](#33-use-asyncioqueue-for-producer-consumer)
   - 3.4 [Use Async Context Managers](#34-use-async-context-managers)
   - 3.5 [Use TaskGroup for Structured Concurrency](#35-use-taskgroup-for-structured-concurrency)
4. [Data Structures](#4-data-structures) — **MEDIUM-HIGH**
   - 4.1 [Use Set for O(1) Membership Testing](#41-use-set-for-o1-membership-testing)
   - 4.2 [Use deque for Queue Operations](#42-use-deque-for-queue-operations)
   - 4.3 [Use defaultdict for Grouping](#43-use-defaultdict-for-grouping)
   - 4.4 [Use dataclasses for Structured Data](#44-use-dataclasses-for-structured-data)
   - 4.5 [Use bisect for Sorted List Operations](#45-use-bisect-for-sorted-list-operations)
5. [Imports & Modules](#5-imports--modules) — **MEDIUM**
   - 5.1 [Use Lazy Imports for Slow Modules](#51-use-lazy-imports-for-slow-modules)
   - 5.2 [Use Absolute Imports](#52-use-absolute-imports)
   - 5.3 [Import Specific Names](#53-import-specific-names)
6. [Iteration Patterns](#6-iteration-patterns) — **MEDIUM**
   - 6.1 [Use List Comprehensions](#61-use-list-comprehensions)
   - 6.2 [Use enumerate Instead of Manual Counters](#62-use-enumerate-instead-of-manual-counters)
   - 6.3 [Use itertools for Complex Iterations](#63-use-itertools-for-complex-iterations)
7. [String Operations](#7-string-operations) — **LOW-MEDIUM**
   - 7.1 [Use str.join for Concatenation](#71-use-strjoin-for-concatenation)
   - 7.2 [Use f-strings for Formatting](#72-use-f-strings-for-formatting)
   - 7.3 [Compile Regex Patterns Once](#73-compile-regex-patterns-once)
   - 7.4 [Use String Methods Before Regex](#74-use-string-methods-before-regex)
8. [Advanced Patterns](#8-advanced-patterns) — **LOW**
   - 8.1 [Use functools.lru_cache for Memoization](#81-use-functoolslru_cache-for-memoization)
   - 8.2 [Use Protocols for Structural Typing](#82-use-protocols-for-structural-typing)
   - 8.3 [Use contextlib for Custom Context Managers](#83-use-contextlib-for-custom-context-managers)

---

## 1. I/O Optimization

**Impact: CRITICAL**

I/O operations are typically the largest bottleneck in Python applications. Optimizing file access, network calls, and database operations yields the highest performance gains.

### 1.1 Use Context Managers for File Handling

Always use `with` statements for file operations to ensure proper resource cleanup.

**Incorrect:**

```python
f = open(path, 'r')
data = json.load(f)
f.close()  # Never reached if json.load() raises
```

**Correct:**

```python
with open(path, 'r') as f:
    data = json.load(f)
# File automatically closed, even on exception
```

### 1.2 Buffer File Reads and Writes

Reading or writing files line-by-line causes excessive system calls. Use buffered I/O or read in chunks.

**Incorrect:**

```python
def hash_file(path: str) -> str:
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()  # OOM for large files
```

**Correct:**

```python
def hash_file(path: str, chunk_size: int = 8192) -> str:
    hasher = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(chunk_size):
            hasher.update(chunk)
    return hasher.hexdigest()
```

### 1.3 Use mmap for Large File Access

Memory-mapped files allow random access without loading the entire file into memory.

```python
import mmap

def search_in_file(path: str, pattern: bytes) -> list[int]:
    with open(path, 'rb') as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            positions = []
            start = 0
            while (pos := mm.find(pattern, start)) != -1:
                positions.append(pos)
                start = pos + 1
            return positions
```

### 1.4 Batch Database Operations

Individual INSERT/UPDATE statements incur network round-trip and transaction overhead.

**Incorrect:**

```python
for user in users:
    cursor.execute("INSERT INTO users VALUES (?, ?)", (user['name'], user['email']))
    conn.commit()  # Commits after EVERY row
```

**Correct:**

```python
cursor.executemany(
    "INSERT INTO users VALUES (?, ?)",
    [(u['name'], u['email']) for u in users]
)
conn.commit()  # Single commit for all rows
```

### 1.5 Use Connection Pooling

Creating database or HTTP connections is expensive. Reuse connections through pooling.

```python
from psycopg2 import pool

db_pool = pool.ThreadedConnectionPool(minconn=5, maxconn=20, ...)

def get_user(user_id: int) -> dict:
    conn = db_pool.getconn()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        return cursor.fetchone()
    finally:
        db_pool.putconn(conn)
```

### 1.6 Use pathlib for Path Operations

`pathlib` provides an object-oriented interface for filesystem paths.

```python
from pathlib import Path

path = Path(base_dir) / 'config' / f'{env}.json'
python_files = list(Path(directory).rglob('*.py'))
content = path.read_text()
```

---

## 2. Memory Management

**Impact: CRITICAL**

Python's automatic memory management can lead to excessive memory usage if not carefully managed.

### 2.1 Use Generators Instead of Lists

Generators produce values on-demand, using constant memory.

**Incorrect:**

```python
def get_log_lines(path: str) -> list[str]:
    with open(path, 'r') as f:
        return [line.strip() for line in f]  # Loads entire file
```

**Correct:**

```python
def get_log_lines(path: str) -> Iterator[str]:
    with open(path, 'r') as f:
        for line in f:
            yield line.strip()  # One line at a time
```

### 2.2 Use __slots__ for Memory-Heavy Classes

`__slots__` saves 40-50% memory per instance by replacing `__dict__` with a fixed array.

```python
class Point:
    __slots__ = ('x', 'y', 'z')

    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z
```

### 2.3 Use weakref for Caches

Regular references prevent garbage collection. Use `weakref` for caches.

```python
import weakref

class ImageCache:
    def __init__(self):
        self._cache = weakref.WeakValueDictionary()

    def get(self, path: str) -> Image:
        img = self._cache.get(path)
        if img is None:
            img = Image.load(path)
            self._cache[path] = img
        return img
```

### 2.4 Explicitly Delete Large Objects

Use `del` and `gc.collect()` when you need to free memory promptly.

```python
import gc

def process_large_dataset():
    data = load_huge_dataset()
    result = analyze(data)
    del data
    gc.collect()
    return result
```

### 2.5 Avoid Unnecessary Data Copies

Use views, in-place operations, and copy-on-write semantics.

```python
# NumPy view (no copy)
view = arr[1:4]

# In-place operation
items.append(new_item)  # Not: items = items + [new_item]
```

### 2.6 Intern Repeated Strings

When the same string appears many times, interning ensures only one copy exists.

```python
import sys

def load_records(data: list[dict]) -> list[Record]:
    return [Record(status=sys.intern(d['status'])) for d in data]
```

---

## 3. Async/Await Patterns

**Impact: HIGH**

Modern Python async patterns enable concurrent I/O without threads.

### 3.1 Use asyncio.gather for Concurrent Operations

Run independent async operations concurrently.

**Incorrect:**

```python
profile = await fetch_profile(user_id)      # 100ms
orders = await fetch_orders(user_id)        # 150ms
# Total: 250ms
```

**Correct:**

```python
profile, orders = await asyncio.gather(
    fetch_profile(user_id),
    fetch_orders(user_id)
)
# Total: 150ms (max of both)
```

### 3.2 Avoid Blocking Calls in Async Functions

Blocking calls stop the entire event loop. Use async alternatives or executors.

```python
# Incorrect
data = requests.get(url).json()  # Blocking!

# Correct
async with httpx.AsyncClient() as client:
    response = await client.get(url)
    data = response.json()
```

### 3.3 Use asyncio.Queue for Producer-Consumer

`asyncio.Queue` provides thread-safe communication between async tasks.

```python
async def producer_consumer():
    queue = asyncio.Queue(maxsize=10)

    async def producer():
        for i in range(100):
            await queue.put(i)
        await queue.put(None)

    async def consumer():
        while (item := await queue.get()) is not None:
            await process(item)

    await asyncio.gather(producer(), consumer())
```

### 3.4 Use Async Context Managers

For resources that require async setup or cleanup.

```python
async with httpx.AsyncClient() as client:
    response = await client.get(url)
# client.aclose() called automatically
```

### 3.5 Use TaskGroup for Structured Concurrency

Python 3.11+ `TaskGroup` provides automatic cancellation on errors.

```python
async with asyncio.TaskGroup() as tg:
    for item in items:
        tg.create_task(process(item))
# If any task raises, all others cancelled automatically
```

---

## 4. Data Structures

**Impact: MEDIUM-HIGH**

Choosing the right data structure dramatically affects algorithm performance.

### 4.1 Use Set for O(1) Membership Testing

Lists require O(n) time for membership testing. Sets use O(1) hash lookups.

```python
# O(n) list lookup
valid_ids = [1, 2, 3, ...]
if user_id in valid_ids: ...

# O(1) set lookup
valid_ids = {1, 2, 3, ...}
if user_id in valid_ids: ...
```

### 4.2 Use deque for Queue Operations

Lists are O(n) for left-side operations. `deque` provides O(1) on both ends.

```python
from collections import deque

queue = deque()
queue.append(item)     # O(1) right
queue.popleft()        # O(1) left
```

### 4.3 Use defaultdict for Grouping

Eliminates key-existence checks when building grouped data.

```python
from collections import defaultdict

groups = defaultdict(list)
for item in items:
    groups[item['category']].append(item)
```

### 4.4 Use dataclasses for Structured Data

Reduces boilerplate for data-holding classes.

```python
from dataclasses import dataclass

@dataclass(slots=True)
class User:
    id: int
    name: str
    email: str
```

### 4.5 Use bisect for Sorted List Operations

Binary search for sorted lists in O(log n) time.

```python
import bisect

bisect.insort(sorted_list, value)  # O(log n) find + O(n) insert
idx = bisect.bisect_left(sorted_list, value)  # O(log n) find
```

---

## 5. Imports & Modules

**Impact: MEDIUM**

Import patterns affect startup time and memory usage.

### 5.1 Use Lazy Imports for Slow Modules

Defer imports until actually needed to reduce startup time.

```python
def process_data(data: list) -> list:
    import pandas as pd  # Only imported when function called
    return pd.DataFrame(data).to_dict()
```

### 5.2 Use Absolute Imports

Absolute imports are explicit and avoid circular import issues.

```python
# Correct
from mypackage.models import User
from mypackage.utils import helpers
```

### 5.3 Import Specific Names

Makes dependencies explicit and avoids repeated attribute lookups.

```python
from os.path import join, isfile
from collections import Counter
```

---

## 6. Iteration Patterns

**Impact: MEDIUM**

Python offers multiple iteration patterns with different performance characteristics.

### 6.1 Use List Comprehensions

More Pythonic, more readable, often faster than `map()`/`filter()`.

```python
# Correct
squares = [x ** 2 for x in numbers]
evens = [x for x in numbers if x % 2 == 0]
```

### 6.2 Use enumerate Instead of Manual Counters

Provides index and value together.

```python
for i, item in enumerate(items):
    print(f"{i}: {item}")
```

### 6.3 Use itertools for Complex Iterations

Memory-efficient building blocks for complex iteration.

```python
from itertools import chain, groupby, islice

all_items = list(chain(list1, list2, list3))
first_10 = list(islice(generator, 10))
```

---

## 7. String Operations

**Impact: LOW-MEDIUM**

Efficient string operations reduce CPU usage in string-heavy code.

### 7.1 Use str.join for Concatenation

O(n) vs O(n²) for many strings.

```python
# Correct
result = '\n'.join(lines)
```

### 7.2 Use f-strings for Formatting

Faster and more readable than older methods.

```python
message = f"Hello, {name}! Total: {price:.2f}"
```

### 7.3 Compile Regex Patterns Once

Don't compile inside functions or loops.

```python
import re

EMAIL_PATTERN = re.compile(r'[\w\.-]+@[\w\.-]+\.\w+')

def extract_emails(text: str) -> list[str]:
    return EMAIL_PATTERN.findall(text)
```

### 7.4 Use String Methods Before Regex

Built-in string methods are 10-100× faster for simple operations.

```python
# Use string methods
text.startswith(prefix)
text.split(',')
'World' in text

# Not regex for simple operations
re.match(rf'^{prefix}', text)  # Overkill
```

---

## 8. Advanced Patterns

**Impact: LOW**

Advanced optimization techniques for specific use cases.

### 8.1 Use functools.lru_cache for Memoization

Automatically caches function results.

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
```

### 8.2 Use Protocols for Structural Typing

Type-safe duck typing.

```python
from typing import Protocol

class Readable(Protocol):
    def read(self) -> str: ...

def process(obj: Readable) -> str:
    return obj.read()
```

### 8.3 Use contextlib for Custom Context Managers

Create context managers without boilerplate.

```python
from contextlib import contextmanager

@contextmanager
def timer(name: str):
    start = time.perf_counter()
    try:
        yield
    finally:
        print(f"{name}: {time.perf_counter() - start:.4f}s")
```

---

## References

1. [Python Documentation](https://docs.python.org/3/)
2. [PEP 8 - Style Guide](https://peps.python.org/pep-0008/)
3. [Real Python - Performance](https://realpython.com/python-performance/)
4. [Python Speed Tips](https://wiki.python.org/moin/PythonSpeed/PerformanceTips)
5. [asyncio Documentation](https://docs.python.org/3/library/asyncio.html)
6. [itertools Documentation](https://docs.python.org/3/library/itertools.html)
7. [dataclasses Documentation](https://docs.python.org/3/library/dataclasses.html)
