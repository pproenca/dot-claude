---
title: Use f-strings for String Formatting
impact: LOW-MEDIUM
impactDescription: faster and more readable
tags: strings, fstrings, formatting, performance
---

## Use f-strings for String Formatting

f-strings (formatted string literals) are faster and more readable than `%` formatting, `.format()`, or concatenation.

**Incorrect (older formatting methods):**

```python
# %-formatting (old style)
message = "Hello, %s! You have %d messages." % (name, count)

# str.format()
message = "Hello, {}! You have {} messages.".format(name, count)
message = "Hello, {name}! You have {count} messages.".format(name=name, count=count)

# Concatenation
message = "Hello, " + name + "! You have " + str(count) + " messages."
```

**Correct (f-strings):**

```python
# Clear and fast
message = f"Hello, {name}! You have {count} messages."

# Expressions in f-strings
message = f"Total: {price * quantity:.2f}"
greeting = f"Hello, {name.title()}!"
debug = f"Value: {value!r}"  # repr()
```

**f-string formatting options:**

```python
value = 42.12345
name = "Alice"

# Number formatting
f"{value:.2f}"      # '42.12' (2 decimal places)
f"{value:10.2f}"    # '     42.12' (width 10)
f"{value:010.2f}"   # '0000042.12' (zero-padded)
f"{value:+.2f}"     # '+42.12' (always show sign)
f"{value:,.2f}"     # '42.12' (thousands separator)
f"{value:.2e}"      # '4.21e+01' (scientific)
f"{value:.2%}"      # '4212.35%' (percentage)

# Integer formatting
n = 42
f"{n:05d}"          # '00042' (zero-padded)
f"{n:x}"            # '2a' (hex)
f"{n:b}"            # '101010' (binary)
f"{n:,}"            # '42' (thousands separator)

# String formatting
f"{name:>10}"       # '     Alice' (right-align)
f"{name:<10}"       # 'Alice     ' (left-align)
f"{name:^10}"       # '  Alice   ' (center)
f"{name:*^10}"      # '**Alice***' (fill char)
```

**Debug formatting (Python 3.8+):**

```python
x = 10
y = 20
# Self-documenting debug output
print(f"{x=}, {y=}, {x+y=}")
# Output: x=10, y=20, x+y=30

# With formatting
print(f"{value=:.2f}")
# Output: value=42.12
```

**Multi-line f-strings:**

```python
query = f"""
    SELECT *
    FROM users
    WHERE name = '{name}'
    AND age > {min_age}
"""

# Or using parentheses
message = (
    f"User: {name}\n"
    f"Email: {email}\n"
    f"Status: {status}"
)
```
