---
title: Enable Strict Mypy Mode
impact: LOW
impactDescription: Maximum type safety
tags: tooling, mypy, type-checking, strict
---

## Enable Strict Mypy Mode

Configure mypy in strict mode for maximum type safety and early error detection.

**Correct (strict mypy configuration):**

```toml
[tool.mypy]
python_version = "3.11"
strict = true
warn_return_any = true
warn_unused_ignores = true
show_error_codes = true
enable_error_code = ["ignore-without-code", "truthy-bool"]

# Relax rules for tests
[[tool.mypy.overrides]]
module = ["tests.*"]
disallow_untyped_defs = false

# Handle untyped third-party libraries
[[tool.mypy.overrides]]
module = ["third_party.*"]
ignore_missing_imports = true
```

Run with:
```bash
mypy .                    # Check all files
mypy src/                 # Check specific directory
mypy --strict src/        # Strict mode on command line
```

Reference: [mypy documentation](https://mypy.readthedocs.io/)
