# Sections

This file defines all sections, their ordering, impact levels, and descriptions.
The section ID (in parentheses) is the filename prefix used to group rules.

---

## 1. I/O Optimization (io)

**Impact:** CRITICAL
**Description:** I/O operations are typically the largest bottleneck in Python applications. Optimizing file access, network calls, and database operations yields the highest performance gains. Python's GIL doesn't affect I/O-bound operations, making this the most impactful optimization category.

## 2. Memory Management (memory)

**Impact:** CRITICAL
**Description:** Python's automatic memory management can lead to excessive memory usage if not carefully managed. Generators, `__slots__`, and proper object lifecycle management prevent memory bloat and reduce garbage collection pressure.

## 3. Async/Await Patterns (async)

**Impact:** HIGH
**Description:** Modern Python async patterns enable concurrent I/O without threads. Proper use of `asyncio` eliminates I/O blocking and maximizes throughput for network-bound applications.

## 4. Data Structures (data)

**Impact:** MEDIUM-HIGH
**Description:** Choosing the right data structure dramatically affects algorithm performance. Python's built-in types have different time complexities; selecting appropriately prevents O(n) operations where O(1) is possible.

## 5. Imports & Modules (imports)

**Impact:** MEDIUM
**Description:** Import patterns affect startup time and memory usage. Lazy imports, avoiding circular dependencies, and proper package structure reduce cold start times and improve maintainability.

## 6. Iteration Patterns (iter)

**Impact:** MEDIUM
**Description:** Python offers multiple iteration patterns with different performance characteristics. List comprehensions, generators, and `itertools` functions provide optimized implementations for common patterns.

## 7. String Operations (strings)

**Impact:** LOW-MEDIUM
**Description:** String operations are common in Python applications. Efficient concatenation, formatting, and pattern matching reduce CPU usage in string-heavy code paths.

## 8. Advanced Patterns (advanced)

**Impact:** LOW
**Description:** Advanced optimization techniques for specific use cases. These patterns require careful implementation and are typically only needed for performance-critical hot paths.
