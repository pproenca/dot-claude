---
title: Use TaskGroup for Structured Concurrency
impact: MEDIUM
impactDescription: better error handling and cancellation
tags: async, asyncio, taskgroup, structured-concurrency
---

## Use TaskGroup for Structured Concurrency

Python 3.11+ `TaskGroup` provides structured concurrency with automatic cancellation on errors.

**Incorrect (unstructured task creation):**

```python
async def process_all(items: list) -> list:
    tasks = []
    for item in items:
        task = asyncio.create_task(process(item))
        tasks.append(task)

    # If one task raises, others continue running
    # Need manual cancellation and error handling
    try:
        return await asyncio.gather(*tasks)
    except Exception:
        for task in tasks:
            task.cancel()
        raise
```

**Correct (TaskGroup with automatic cleanup):**

```python
async def process_all(items: list) -> list:
    results = []

    async with asyncio.TaskGroup() as tg:
        for item in items:
            tg.create_task(process(item))

    # If any task raises, all others are cancelled automatically
    # All tasks complete before exiting the context manager
    return results
```

**Collecting results from TaskGroup:**

```python
async def fetch_all_urls(urls: list[str]) -> list[str]:
    results = {}

    async def fetch_and_store(url: str, index: int):
        results[index] = await fetch_url(url)

    async with asyncio.TaskGroup() as tg:
        for i, url in enumerate(urls):
            tg.create_task(fetch_and_store(url, i))

    # Results in original order
    return [results[i] for i in range(len(urls))]
```

**Handle partial failures:**

```python
async def fetch_with_fallback(urls: list[str]) -> list[str | None]:
    results: dict[int, str | None] = {}

    async def safe_fetch(url: str, index: int):
        try:
            results[index] = await fetch_url(url)
        except Exception as e:
            results[index] = None
            logging.error(f"Failed to fetch {url}: {e}")

    async with asyncio.TaskGroup() as tg:
        for i, url in enumerate(urls):
            tg.create_task(safe_fetch(url, i))

    return [results[i] for i in range(len(urls))]
```

**Nested TaskGroups:**

```python
async def complex_pipeline(data: list) -> dict:
    async with asyncio.TaskGroup() as outer:
        # First stage: fetch all
        fetch_task = outer.create_task(fetch_all(data))

        # Second stage runs after fetch completes
        async def transform_stage():
            fetched = await fetch_task
            async with asyncio.TaskGroup() as inner:
                for item in fetched:
                    inner.create_task(transform(item))

        outer.create_task(transform_stage())
```

Reference: [PEP 654 - Exception Groups and except*](https://peps.python.org/pep-0654/)
