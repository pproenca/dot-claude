---
title: Use __slots__ for Memory-Heavy Classes
impact: CRITICAL
impactDescription: 40-50% memory reduction per instance
tags: memory, slots, classes, optimization
---

## Use __slots__ for Memory-Heavy Classes

By default, Python stores instance attributes in a `__dict__` dictionary. `__slots__` replaces this with a fixed array, saving 40-50% memory per instance.

**Incorrect (default dict-based attributes):**

```python
class Point:
    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

# Each instance has a __dict__ overhead (~100 bytes on 64-bit Python)
points = [Point(i, i+1, i+2) for i in range(1_000_000)]
# Memory: ~200MB
```

**Correct (slots-based attributes):**

```python
class Point:
    __slots__ = ('x', 'y', 'z')

    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

# No __dict__, fixed attribute storage
points = [Point(i, i+1, i+2) for i in range(1_000_000)]
# Memory: ~100MB (50% reduction)
```

**Inheritance with slots:**

```python
class Point2D:
    __slots__ = ('x', 'y')

    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

class Point3D(Point2D):
    __slots__ = ('z',)  # Only add NEW attributes

    def __init__(self, x: float, y: float, z: float):
        super().__init__(x, y)
        self.z = z
```

**Slots with default values (Python 3.10+):**

```python
class Config:
    __slots__ = ('host', 'port', 'timeout')

    def __init__(self, host: str = 'localhost', port: int = 8080, timeout: int = 30):
        self.host = host
        self.port = port
        self.timeout = timeout
```

**When NOT to use __slots__:**
- Need dynamic attributes (`__dict__` required)
- Using multiple inheritance with non-slots classes
- Need `__weakref__` (add to slots explicitly if needed)
- Class will be subclassed by unknown code

**Alternative: dataclasses with slots (Python 3.10+):**

```python
from dataclasses import dataclass

@dataclass(slots=True)
class Point:
    x: float
    y: float
    z: float
```

Reference: [Python Data Model - __slots__](https://docs.python.org/3/reference/datamodel.html#slots)
