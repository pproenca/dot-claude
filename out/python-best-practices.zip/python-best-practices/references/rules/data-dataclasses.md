---
title: Use dataclasses for Structured Data
impact: MEDIUM
impactDescription: less boilerplate, better performance
tags: data-structures, dataclasses, classes, typing
---

## Use dataclasses for Structured Data

`dataclasses` reduce boilerplate for classes that primarily hold data, with automatic `__init__`, `__repr__`, `__eq__`, and more.

**Incorrect (manual boilerplate):**

```python
class User:
    def __init__(self, id: int, name: str, email: str, active: bool = True):
        self.id = id
        self.name = name
        self.email = email
        self.active = active

    def __repr__(self):
        return f"User(id={self.id}, name={self.name!r}, email={self.email!r}, active={self.active})"

    def __eq__(self, other):
        if not isinstance(other, User):
            return NotImplemented
        return (self.id, self.name, self.email, self.active) == \
               (other.id, other.name, other.email, other.active)

    def __hash__(self):
        return hash((self.id, self.name, self.email, self.active))
```

**Correct (dataclass):**

```python
from dataclasses import dataclass

@dataclass
class User:
    id: int
    name: str
    email: str
    active: bool = True
    # __init__, __repr__, __eq__ generated automatically
```

**Dataclass features:**

```python
from dataclasses import dataclass, field
from typing import ClassVar

@dataclass
class User:
    id: int
    name: str
    email: str
    active: bool = True
    tags: list[str] = field(default_factory=list)  # Mutable default
    _cache: dict = field(default_factory=dict, repr=False)  # Excluded from repr

    # Class variable (not instance attribute)
    max_name_length: ClassVar[int] = 100

    def __post_init__(self):
        # Validation after init
        if len(self.name) > self.max_name_length:
            raise ValueError(f"Name too long: {len(self.name)}")
```

**Immutable dataclass (frozen):**

```python
@dataclass(frozen=True)
class Point:
    x: float
    y: float
    # Cannot modify after creation
    # Can be used as dict key or in sets
```

**Slots for memory efficiency (Python 3.10+):**

```python
@dataclass(slots=True)
class Point:
    x: float
    y: float
    # Uses __slots__ instead of __dict__
    # 40-50% less memory per instance
```

**Convert to/from dict:**

```python
from dataclasses import asdict, astuple

user = User(1, "Alice", "alice@example.com")
user_dict = asdict(user)  # {'id': 1, 'name': 'Alice', ...}
user_tuple = astuple(user)  # (1, 'Alice', 'alice@example.com', True)

# From dict
user = User(**user_dict)
```

Reference: [PEP 557 - Data Classes](https://peps.python.org/pep-0557/)
