---
title: Compile Regex Patterns Once
impact: LOW-MEDIUM
impactDescription: avoids repeated compilation
tags: strings, regex, compile, performance
---

## Compile Regex Patterns Once

Regex patterns should be compiled once and reused. Don't compile inside functions or loops.

**Incorrect (recompiles every call):**

```python
import re

def extract_emails(text: str) -> list[str]:
    # Pattern compiled on EVERY function call
    return re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', text)

def is_valid_phone(phone: str) -> bool:
    # Pattern compiled on EVERY function call
    return bool(re.match(r'^\+?1?\d{10,14}$', phone))

def process_logs(lines: list[str]) -> list[str]:
    errors = []
    for line in lines:
        # Pattern compiled on EVERY iteration!
        if re.search(r'ERROR|CRITICAL|FATAL', line):
            errors.append(line)
    return errors
```

**Correct (compile once at module level):**

```python
import re

# Compile once at module level
EMAIL_PATTERN = re.compile(r'[\w\.-]+@[\w\.-]+\.\w+')
PHONE_PATTERN = re.compile(r'^\+?1?\d{10,14}$')
ERROR_PATTERN = re.compile(r'ERROR|CRITICAL|FATAL')

def extract_emails(text: str) -> list[str]:
    return EMAIL_PATTERN.findall(text)

def is_valid_phone(phone: str) -> bool:
    return bool(PHONE_PATTERN.match(phone))

def process_logs(lines: list[str]) -> list[str]:
    return [line for line in lines if ERROR_PATTERN.search(line)]
```

**Pattern flags:**

```python
# Case-insensitive matching
WORD_PATTERN = re.compile(r'hello', re.IGNORECASE)

# Multiline mode (^ and $ match line boundaries)
LINE_PATTERN = re.compile(r'^error:', re.MULTILINE | re.IGNORECASE)

# Verbose mode for readable patterns
URL_PATTERN = re.compile(r'''
    https?://           # Protocol
    [\w\.-]+            # Domain
    (?:/[\w\.-]*)*      # Path
    (?:\?[\w=&]*)?      # Query string
''', re.VERBOSE)
```

**When string methods are faster:**

```python
# For simple searches, use string methods instead of regex
text = "Hello, World!"

# Incorrect: regex overkill
re.search(r'World', text)

# Correct: string method is faster
'World' in text
text.find('World')
text.startswith('Hello')
text.endswith('!')

# Incorrect: regex for simple replace
re.sub(r'World', 'Python', text)

# Correct: string method
text.replace('World', 'Python')
```

**Use regex only when needed:**
- Pattern matching with wildcards
- Character classes ([a-z], \d, \w)
- Repetition (+, *, ?, {n,m})
- Groups and captures
- Complex alternations
