---
title: Use Connection Pooling
impact: CRITICAL
impactDescription: eliminates connection overhead
tags: io, database, connection-pool, network
---

## Use Connection Pooling

Creating database or HTTP connections is expensive. Reuse connections through pooling.

**Incorrect (new connection per request):**

```python
def get_user(user_id: int) -> dict:
    # Creates new connection every call
    conn = psycopg2.connect(
        host='localhost',
        database='mydb',
        user='user',
        password='pass'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result
```

**Correct (connection pool):**

```python
from psycopg2 import pool

# Create pool once at module level
db_pool = pool.ThreadedConnectionPool(
    minconn=5,
    maxconn=20,
    host='localhost',
    database='mydb',
    user='user',
    password='pass'
)

def get_user(user_id: int) -> dict:
    conn = db_pool.getconn()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        return result
    finally:
        db_pool.putconn(conn)
```

**SQLAlchemy with pooling:**

```python
from sqlalchemy import create_engine

# Pool configuration in connection string
engine = create_engine(
    'postgresql://user:pass@localhost/mydb',
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,  # Verify connections are alive
    pool_recycle=3600    # Recycle connections after 1 hour
)
```

**HTTP connection pooling with requests:**

```python
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Create session once, reuse for all requests
session = requests.Session()
adapter = HTTPAdapter(
    pool_connections=10,
    pool_maxsize=20,
    max_retries=Retry(total=3, backoff_factor=0.1)
)
session.mount('http://', adapter)
session.mount('https://', adapter)

def fetch_data(url: str) -> dict:
    response = session.get(url)  # Reuses connection
    return response.json()
```

**httpx async with pooling:**

```python
import httpx

# Create client once
client = httpx.AsyncClient(
    limits=httpx.Limits(max_connections=100, max_keepalive_connections=20)
)

async def fetch_data(url: str) -> dict:
    response = await client.get(url)
    return response.json()
```
