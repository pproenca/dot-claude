---
title: Rule Title Here
impact: MEDIUM
impactDescription: Optional description of impact (e.g., "2-10× improvement")
tags: tag1, tag2, tag3
---

## Rule Title Here

Brief explanation of the rule and why it matters. This should be clear and concise, explaining the performance implications.

**Incorrect ({description of what's wrong}):**

```python
# Bad code example here
def bad_example():
    pass
```

**Correct ({description of what's right}):**

```python
# Good code example here
def good_example():
    pass
```

Reference: [Link to documentation or resource](https://example.com)
