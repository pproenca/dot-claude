---
title: Avoid Unnecessary Data Copies
impact: MEDIUM
impactDescription: reduces memory usage and CPU time
tags: memory, copies, views, numpy, pandas
---

## Avoid Unnecessary Data Copies

Many operations create unnecessary copies. Use views, in-place operations, and copy-on-write semantics to reduce memory usage.

**Incorrect (unnecessary copies):**

```python
def process_list(items: list[int]) -> list[int]:
    # Creates copy
    sorted_items = sorted(items)
    # Creates another copy
    filtered = [x for x in sorted_items if x > 0]
    # Creates yet another copy
    doubled = [x * 2 for x in filtered]
    return doubled

# 4 lists in memory at peak
```

**Correct (minimize copies):**

```python
def process_list(items: list[int]) -> list[int]:
    # Sort in place if original not needed
    items.sort()
    # Single pass with generator
    return [x * 2 for x in items if x > 0]

# Or if original must be preserved:
def process_list(items: list[int]) -> list[int]:
    return sorted(x * 2 for x in items if x > 0)
```

**NumPy views vs copies:**

```python
import numpy as np

arr = np.array([1, 2, 3, 4, 5])

# Creates a VIEW (no copy, shares memory)
view = arr[1:4]
view[0] = 99  # Modifies original arr!

# Creates a COPY (separate memory)
copy = arr[1:4].copy()
copy[0] = 99  # Original unchanged

# Slicing creates views
arr2d = np.array([[1, 2], [3, 4], [5, 6]])
row = arr2d[0]    # View
col = arr2d[:, 0]  # View

# Fancy indexing creates copies
selected = arr[[0, 2, 4]]  # Copy!
```

**Pandas copy-on-write (pandas 2.0+):**

```python
import pandas as pd

# Enable copy-on-write globally
pd.options.mode.copy_on_write = True

df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

# These now return views (no copy until modified)
subset = df['a']
filtered = df[df['a'] > 1]

# Copy only happens when modifying
subset.iloc[0] = 99  # Now creates a copy
```

**In-place operations:**

```python
# Incorrect: creates new list
items = items + [new_item]

# Correct: modifies in place
items.append(new_item)

# Incorrect: creates new list
items = [x * 2 for x in items]

# Correct: modifies in place (when appropriate)
for i in range(len(items)):
    items[i] *= 2
```
