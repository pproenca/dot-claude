---
title: Use contextlib for Custom Context Managers
impact: LOW
impactDescription: cleaner resource management
tags: advanced, contextlib, context-manager, resources
---

## Use contextlib for Custom Context Managers

The `contextlib` module provides decorators and utilities for creating context managers without boilerplate.

**Incorrect (class-based context manager):**

```python
class Timer:
    def __init__(self, name: str):
        self.name = name
        self.start = None

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed = time.perf_counter() - self.start
        print(f"{self.name}: {elapsed:.4f}s")
        return False

with Timer("operation"):
    do_something()
```

**Correct (contextmanager decorator):**

```python
from contextlib import contextmanager

@contextmanager
def timer(name: str):
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"{name}: {elapsed:.4f}s")

with timer("operation"):
    do_something()
```

**Yielding a value:**

```python
@contextmanager
def temporary_file(suffix: str = '.tmp'):
    import tempfile
    import os

    fd, path = tempfile.mkstemp(suffix=suffix)
    try:
        os.close(fd)
        yield path
    finally:
        if os.path.exists(path):
            os.unlink(path)

with temporary_file('.json') as path:
    with open(path, 'w') as f:
        json.dump(data, f)
    process_file(path)
# File automatically deleted
```

**Suppressing exceptions:**

```python
from contextlib import suppress

# Instead of try/except with pass
try:
    os.remove('file.txt')
except FileNotFoundError:
    pass

# Use suppress
with suppress(FileNotFoundError):
    os.remove('file.txt')
```

**Redirecting output:**

```python
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO

# Capture stdout
output = StringIO()
with redirect_stdout(output):
    print("This is captured")
captured = output.getvalue()

# Suppress output
with redirect_stdout(None):
    noisy_function()
```

**Combining context managers:**

```python
from contextlib import ExitStack

def process_files(paths: list[str]) -> list[str]:
    with ExitStack() as stack:
        files = [stack.enter_context(open(p)) for p in paths]
        return [f.read() for f in files]
    # All files closed automatically
```

**Async context manager:**

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def async_timer(name: str):
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"{name}: {elapsed:.4f}s")

async with async_timer("async operation"):
    await do_async_work()
```

Reference: [contextlib documentation](https://docs.python.org/3/library/contextlib.html)
