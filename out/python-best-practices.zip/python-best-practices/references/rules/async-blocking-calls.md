---
title: Avoid Blocking Calls in Async Functions
impact: CRITICAL
impactDescription: Prevents event loop starvation
tags: async, asyncio, blocking, executor
---

## Avoid Blocking Calls in Async Functions

Never call blocking I/O or CPU-intensive operations directly in async functions. This blocks the event loop and prevents other coroutines from running.

**Incorrect (blocking calls in async function):**

```python
import asyncio
import requests
import time

async def fetch_and_process():
    """Fetch data and process it."""
    # WRONG: This blocks the event loop!
    response = requests.get("https://api.example.com/data")

    # WRONG: This also blocks the event loop!
    time.sleep(1)

    return response.json()
```

**Correct (using async alternatives or executors):**

```python
import asyncio
import httpx

async def fetch_and_process():
    """Fetch data and process it."""
    # Use async HTTP client
    async with httpx.AsyncClient() as client:
        response = await client.get("https://api.example.com/data")

    # Use asyncio.sleep for delays
    await asyncio.sleep(1)

    return response.json()

# For unavoidable blocking calls
async def process_with_blocking():
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, blocking_function)
    return result
```

Reference: [Python asyncio](https://docs.python.org/3/library/asyncio.html)
