---
title: Use Protocols for Structural Typing
impact: LOW
impactDescription: type-safe duck typing
tags: advanced, protocols, typing, duck-typing
---

## Use Protocols for Structural Typing

`Protocol` classes define interfaces based on structure rather than inheritance, enabling type-safe duck typing.

**Incorrect (no type safety for duck typing):**

```python
def process_readable(obj) -> str:  # No type hints possible
    return obj.read()  # Hope it has read()!

def sort_items(items) -> list:  # What interface do items need?
    return sorted(items, key=lambda x: x.priority)
```

**Correct (Protocol defines expected interface):**

```python
from typing import Protocol

class Readable(Protocol):
    def read(self) -> str: ...

class HasPriority(Protocol):
    @property
    def priority(self) -> int: ...

def process_readable(obj: Readable) -> str:
    return obj.read()  # Type checker knows read() exists

def sort_items(items: list[HasPriority]) -> list[HasPriority]:
    return sorted(items, key=lambda x: x.priority)
```

**Classes implicitly implement Protocols:**

```python
from typing import Protocol

class Closable(Protocol):
    def close(self) -> None: ...

# File implicitly implements Closable (has close())
def cleanup(resource: Closable) -> None:
    resource.close()

# Works with any class that has close()
f = open('file.txt')
cleanup(f)  # OK

class Connection:
    def close(self) -> None:
        pass

cleanup(Connection())  # Also OK
```

**Protocol with attributes:**

```python
from typing import Protocol

class Named(Protocol):
    name: str

class Aged(Protocol):
    age: int

class Person(Protocol):
    name: str
    age: int

def greet(entity: Named) -> str:
    return f"Hello, {entity.name}!"

@dataclass
class User:
    name: str
    email: str

greet(User("Alice", "alice@example.com"))  # OK, User has name
```

**Runtime checkable protocols:**

```python
from typing import Protocol, runtime_checkable

@runtime_checkable
class Drawable(Protocol):
    def draw(self) -> None: ...

class Circle:
    def draw(self) -> None:
        print("Drawing circle")

# Can use isinstance at runtime
obj = Circle()
if isinstance(obj, Drawable):  # True
    obj.draw()
```

**Common Protocol patterns:**

```python
from typing import Protocol, Iterator, Callable

class Iterable(Protocol[T]):
    def __iter__(self) -> Iterator[T]: ...

class Comparable(Protocol):
    def __lt__(self, other: Self) -> bool: ...

class SupportsAdd(Protocol):
    def __add__(self, other: Self) -> Self: ...
```

Reference: [PEP 544 - Protocols](https://peps.python.org/pep-0544/)
