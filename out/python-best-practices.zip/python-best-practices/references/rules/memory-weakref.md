---
title: Use weakref for Caches
impact: HIGH
impactDescription: prevents memory leaks in caches
tags: memory, weakref, cache, garbage-collection
---

## Use weakref for Caches

Regular references prevent garbage collection. Use `weakref` for caches to allow objects to be collected when no longer needed elsewhere.

**Incorrect (strong reference cache causes memory leak):**

```python
class ImageCache:
    def __init__(self):
        self._cache: dict[str, Image] = {}

    def get(self, path: str) -> Image:
        if path not in self._cache:
            self._cache[path] = Image.load(path)
        return self._cache[path]

# Images never get garbage collected even if no longer used
cache = ImageCache()
for path in thousands_of_paths:
    img = cache.get(path)
    process(img)
# Memory keeps growing...
```

**Correct (weak reference cache allows GC):**

```python
import weakref

class ImageCache:
    def __init__(self):
        self._cache: weakref.WeakValueDictionary[str, Image] = weakref.WeakValueDictionary()

    def get(self, path: str) -> Image:
        img = self._cache.get(path)
        if img is None:
            img = Image.load(path)
            self._cache[path] = img
        return img

# Images are collected when no other references exist
cache = ImageCache()
for path in thousands_of_paths:
    img = cache.get(path)
    process(img)
# Memory stays bounded
```

**WeakKeyDictionary for object-keyed caches:**

```python
import weakref

# Cache computed values by object identity
_computed_cache: weakref.WeakKeyDictionary[object, Any] = weakref.WeakKeyDictionary()

def compute_expensive(obj: SomeClass) -> int:
    if obj not in _computed_cache:
        _computed_cache[obj] = expensive_calculation(obj)
    return _computed_cache[obj]

# When obj is garbage collected, cache entry is automatically removed
```

**Weak references with callbacks:**

```python
import weakref

def on_delete(ref):
    print(f"Object was garbage collected")

obj = SomeClass()
weak_ref = weakref.ref(obj, on_delete)

# Access the object
strong_ref = weak_ref()
if strong_ref is not None:
    use(strong_ref)

# When obj is deleted, callback is invoked
del obj  # Prints: "Object was garbage collected"
```

**functools.lru_cache for bounded caching:**

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def get_user(user_id: int) -> User:
    return db.fetch_user(user_id)

# Clear cache when needed
get_user.cache_clear()
```
