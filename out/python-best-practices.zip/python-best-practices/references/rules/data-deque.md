---
title: Use deque for Queue Operations
impact: MEDIUM-HIGH
impactDescription: O(1) vs O(n) for left operations
tags: data-structures, deque, queue, collections
---

## Use deque for Queue Operations

Lists are O(n) for left-side operations (insert/pop at index 0). `collections.deque` provides O(1) operations on both ends.

**Incorrect (O(n) list operations):**

```python
def process_queue(items: list) -> None:
    queue = list(items)
    while queue:
        item = queue.pop(0)  # O(n) - shifts all elements
        process(item)

def sliding_window(items: list, size: int) -> list:
    window = []
    results = []
    for item in items:
        window.append(item)
        if len(window) > size:
            window.pop(0)  # O(n) - shifts all elements
        if len(window) == size:
            results.append(sum(window))
    return results
```

**Correct (O(1) deque operations):**

```python
from collections import deque

def process_queue(items: list) -> None:
    queue = deque(items)
    while queue:
        item = queue.popleft()  # O(1)
        process(item)

def sliding_window(items: list, size: int) -> list:
    window = deque(maxlen=size)  # Auto-removes oldest when full
    results = []
    for item in items:
        window.append(item)  # O(1), auto-pops left if full
        if len(window) == size:
            results.append(sum(window))
    return results
```

**Deque as bounded buffer:**

```python
from collections import deque

# Keep only last N items
recent_logs = deque(maxlen=1000)

def log(message: str) -> None:
    recent_logs.append(message)
    # Oldest automatically removed when > 1000

# Rotate elements
d = deque([1, 2, 3, 4, 5])
d.rotate(2)   # [4, 5, 1, 2, 3]
d.rotate(-2)  # [1, 2, 3, 4, 5]
```

**Time complexity comparison:**

| Operation | list | deque |
|-----------|------|-------|
| append (right) | O(1) | O(1) |
| pop (right) | O(1) | O(1) |
| insert(0, x) | O(n) | O(1) |
| pop(0) | O(n) | O(1) |
| access by index | O(1) | O(n) |

**When to use list instead:**
- Need random access by index
- Need slicing
- Most operations are at the right end only
