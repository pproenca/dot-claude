---
title: Use itertools for Complex Iterations
impact: MEDIUM
impactDescription: efficient, memory-friendly, readable
tags: iteration, itertools, generators, functional
---

## Use itertools for Complex Iterations

The `itertools` module provides memory-efficient building blocks for complex iteration patterns.

**Common itertools functions:**

```python
from itertools import chain, groupby, islice, cycle, repeat, accumulate

# chain: flatten iterables
all_items = list(chain(list1, list2, list3))
all_items = list(chain.from_iterable([list1, list2, list3]))

# islice: slice iterators (can't use [:] on generators)
first_10 = list(islice(infinite_generator(), 10))
skip_first_5 = list(islice(items, 5, None))

# groupby: group consecutive items
# IMPORTANT: must be sorted by key first!
data = sorted(items, key=lambda x: x['category'])
for category, group in groupby(data, key=lambda x: x['category']):
    print(f"{category}: {list(group)}")
```

**Replacing manual loops:**

```python
from itertools import takewhile, dropwhile, filterfalse

# takewhile: take items while predicate is true
positive_prefix = list(takewhile(lambda x: x > 0, numbers))

# dropwhile: skip items while predicate is true
after_header = list(dropwhile(lambda x: x.startswith('#'), lines))

# filterfalse: opposite of filter
non_empty = list(filterfalse(lambda x: x == '', strings))
```

**Combinatorics:**

```python
from itertools import combinations, permutations, product

items = ['a', 'b', 'c']

# All pairs (order doesn't matter)
list(combinations(items, 2))  # [('a','b'), ('a','c'), ('b','c')]

# All orderings of pairs
list(permutations(items, 2))  # [('a','b'), ('a','c'), ('b','a'), ...]

# Cartesian product
list(product([1, 2], ['a', 'b']))  # [(1,'a'), (1,'b'), (2,'a'), (2,'b')]

# Nested loops as product
# Instead of:
for x in range(3):
    for y in range(3):
        for z in range(3):
            process(x, y, z)

# Use:
for x, y, z in product(range(3), repeat=3):
    process(x, y, z)
```

**Accumulation and running totals:**

```python
from itertools import accumulate
import operator

numbers = [1, 2, 3, 4, 5]

# Running sum
list(accumulate(numbers))  # [1, 3, 6, 10, 15]

# Running product
list(accumulate(numbers, operator.mul))  # [1, 2, 6, 24, 120]

# Running max
list(accumulate(numbers, max))  # [1, 2, 3, 4, 5]
```

**Pairwise iteration (Python 3.10+):**

```python
from itertools import pairwise

items = [1, 2, 3, 4]
for a, b in pairwise(items):
    print(f"{a} -> {b}")
# 1 -> 2
# 2 -> 3
# 3 -> 4
```

Reference: [itertools documentation](https://docs.python.org/3/library/itertools.html)
