---
title: Use asyncio.gather for Concurrent Operations
impact: HIGH
impactDescription: parallel execution of independent tasks
tags: async, asyncio, gather, concurrency
---

## Use asyncio.gather for Concurrent Operations

When you have independent async operations, run them concurrently with `asyncio.gather()` instead of awaiting sequentially.

**Incorrect (sequential execution):**

```python
async def fetch_user_data(user_id: int) -> dict:
    # Each await blocks until complete - total time = sum of all
    profile = await fetch_profile(user_id)      # 100ms
    orders = await fetch_orders(user_id)        # 150ms
    preferences = await fetch_preferences(user_id)  # 50ms
    # Total: 300ms

    return {
        'profile': profile,
        'orders': orders,
        'preferences': preferences
    }
```

**Correct (concurrent execution):**

```python
async def fetch_user_data(user_id: int) -> dict:
    # All requests start immediately, wait for all to complete
    profile, orders, preferences = await asyncio.gather(
        fetch_profile(user_id),
        fetch_orders(user_id),
        fetch_preferences(user_id)
    )
    # Total: max(100, 150, 50) = 150ms

    return {
        'profile': profile,
        'orders': orders,
        'preferences': preferences
    }
```

**Handle errors gracefully:**

```python
async def fetch_user_data(user_id: int) -> dict:
    results = await asyncio.gather(
        fetch_profile(user_id),
        fetch_orders(user_id),
        fetch_preferences(user_id),
        return_exceptions=True  # Don't raise, return exceptions
    )

    profile, orders, preferences = results

    return {
        'profile': profile if not isinstance(profile, Exception) else None,
        'orders': orders if not isinstance(orders, Exception) else [],
        'preferences': preferences if not isinstance(preferences, Exception) else {},
    }
```

**For dynamic number of tasks:**

```python
async def fetch_all_users(user_ids: list[int]) -> list[dict]:
    tasks = [fetch_user(uid) for uid in user_ids]
    return await asyncio.gather(*tasks)
```

**Limit concurrency with semaphore:**

```python
async def fetch_all_urls(urls: list[str], max_concurrent: int = 10) -> list[str]:
    semaphore = asyncio.Semaphore(max_concurrent)

    async def fetch_with_limit(url: str) -> str:
        async with semaphore:
            return await fetch_url(url)

    tasks = [fetch_with_limit(url) for url in urls]
    return await asyncio.gather(*tasks)
```
