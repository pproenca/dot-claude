---
title: Batch Database Operations
impact: CRITICAL
impactDescription: 10-100× improvement for bulk operations
tags: io, database, batch, bulk-insert, transactions
---

## Batch Database Operations

Individual INSERT/UPDATE statements incur network round-trip and transaction overhead. Batch operations into single transactions.

**Incorrect (individual inserts):**

```python
def save_users(users: list[dict]) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    for user in users:
        # Each insert is a separate transaction
        cursor.execute(
            "INSERT INTO users (name, email) VALUES (?, ?)",
            (user['name'], user['email'])
        )
        conn.commit()  # Commits after EVERY row
    cursor.close()
```

**Correct (batched with single transaction):**

```python
def save_users(users: list[dict]) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.executemany(
            "INSERT INTO users (name, email) VALUES (?, ?)",
            [(u['name'], u['email']) for u in users]
        )
        conn.commit()  # Single commit for all rows
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
```

**For very large datasets, batch in chunks:**

```python
def save_users_chunked(users: list[dict], chunk_size: int = 1000) -> None:
    conn = get_connection()
    cursor = conn.cursor()

    try:
        for i in range(0, len(users), chunk_size):
            chunk = users[i:i + chunk_size]
            cursor.executemany(
                "INSERT INTO users (name, email) VALUES (?, ?)",
                [(u['name'], u['email']) for u in chunk]
            )
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
```

**SQLAlchemy bulk operations:**

```python
# Incorrect: individual adds
def save_users_orm(session: Session, users: list[dict]) -> None:
    for user in users:
        session.add(User(**user))
    session.commit()

# Correct: bulk insert
def save_users_orm(session: Session, users: list[dict]) -> None:
    session.bulk_insert_mappings(User, users)
    session.commit()

# Even faster: Core insert
def save_users_core(session: Session, users: list[dict]) -> None:
    session.execute(User.__table__.insert(), users)
    session.commit()
```
