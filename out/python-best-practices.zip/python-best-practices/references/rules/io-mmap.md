---
title: Use mmap for Large File Access
impact: CRITICAL
impactDescription: enables random access without loading entire file
tags: io, files, mmap, memory-mapping, large-files
---

## Use mmap for Large File Access

Memory-mapped files allow random access to large files without loading them entirely into memory. The OS handles paging efficiently.

**Incorrect (loading entire file):**

```python
def search_in_file(path: str, pattern: bytes) -> list[int]:
    with open(path, 'rb') as f:
        content = f.read()  # Loads entire file into RAM

    positions = []
    start = 0
    while (pos := content.find(pattern, start)) != -1:
        positions.append(pos)
        start = pos + 1
    return positions
```

**Correct (memory-mapped):**

```python
import mmap

def search_in_file(path: str, pattern: bytes) -> list[int]:
    with open(path, 'rb') as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            positions = []
            start = 0
            while (pos := mm.find(pattern, start)) != -1:
                positions.append(pos)
                start = pos + 1
            return positions
```

**Random access example:**

```python
import mmap
import struct

def read_record(path: str, record_num: int, record_size: int = 100) -> bytes:
    with open(path, 'rb') as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            offset = record_num * record_size
            return mm[offset:offset + record_size]

def update_record(path: str, record_num: int, data: bytes, record_size: int = 100) -> None:
    with open(path, 'r+b') as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_WRITE) as mm:
            offset = record_num * record_size
            mm[offset:offset + len(data)] = data
```

**When to use mmap:**
- Files larger than available RAM
- Random access patterns
- Multiple processes reading same file
- Binary file manipulation

**When NOT to use mmap:**
- Small files (overhead not worth it)
- Sequential-only access (regular buffered I/O is fine)
- Files on network drives (poor performance)
