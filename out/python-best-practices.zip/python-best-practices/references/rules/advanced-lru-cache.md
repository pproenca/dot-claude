---
title: Use functools.lru_cache for Memoization
impact: LOW
impactDescription: caches expensive function results
tags: advanced, caching, lru-cache, memoization
---

## Use functools.lru_cache for Memoization

`@lru_cache` automatically caches function results, avoiding repeated computation for the same arguments.

**Incorrect (manual caching):**

```python
_fib_cache = {}

def fibonacci(n: int) -> int:
    if n in _fib_cache:
        return _fib_cache[n]
    if n < 2:
        result = n
    else:
        result = fibonacci(n - 1) + fibonacci(n - 2)
    _fib_cache[n] = result
    return result
```

**Correct (lru_cache):**

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

# Clear cache when needed
fibonacci.cache_clear()

# Check cache statistics
fibonacci.cache_info()
# CacheInfo(hits=46, misses=51, maxsize=128, currsize=51)
```

**Unlimited cache:**

```python
@lru_cache(maxsize=None)  # Unlimited cache
def expensive_computation(x: int) -> int:
    return x ** 2
```

**cache decorator (Python 3.9+):**

```python
from functools import cache

@cache  # Equivalent to lru_cache(maxsize=None)
def factorial(n: int) -> int:
    return n * factorial(n - 1) if n else 1
```

**Caching with unhashable arguments:**

```python
from functools import lru_cache
import json

# Can't cache functions with list/dict arguments directly
# Convert to hashable type

def make_hashable(obj):
    """Convert lists/dicts to hashable types."""
    if isinstance(obj, dict):
        return tuple(sorted((k, make_hashable(v)) for k, v in obj.items()))
    if isinstance(obj, list):
        return tuple(make_hashable(x) for x in obj)
    return obj

@lru_cache(maxsize=128)
def _query_cached(params_tuple):
    params = dict(params_tuple)
    return database.query(**params)

def query(params: dict):
    return _query_cached(make_hashable(params))
```

**Class method caching:**

```python
from functools import lru_cache

class DataProcessor:
    @lru_cache(maxsize=32)
    def process(self, key: str) -> dict:
        # Cached per (self, key) - careful with memory!
        return expensive_process(key)

# Better: cache on the data, not the instance
class DataProcessor:
    def __init__(self):
        self._process_cached = lru_cache(maxsize=32)(self._process)

    def _process(self, key: str) -> dict:
        return expensive_process(key)

    def process(self, key: str) -> dict:
        return self._process_cached(key)
```

Reference: [functools.lru_cache](https://docs.python.org/3/library/functools.html#functools.lru_cache)
