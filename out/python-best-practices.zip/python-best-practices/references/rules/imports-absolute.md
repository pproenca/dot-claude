---
title: Use Absolute Imports
impact: MEDIUM
impactDescription: avoids circular import issues
tags: imports, absolute, modules, organization
---

## Use Absolute Imports

Absolute imports are explicit and avoid ambiguity. They're less prone to circular import issues than relative imports.

**Incorrect (relative imports can be ambiguous):**

```python
# mypackage/utils/helpers.py
from ..models import User  # Where is models?
from . import validators   # Which validators?
from .common import format_date  # Hard to trace
```

**Correct (absolute imports are explicit):**

```python
# mypackage/utils/helpers.py
from mypackage.models import User
from mypackage.utils import validators
from mypackage.utils.common import format_date
```

**Breaking circular imports:**

```python
# Incorrect: circular import
# models.py
from mypackage.services import UserService

class User:
    def get_service(self):
        return UserService(self)

# services.py
from mypackage.models import User  # Circular!

class UserService:
    def __init__(self, user: User):
        self.user = user
```

```python
# Correct: import inside function
# models.py
class User:
    def get_service(self):
        from mypackage.services import UserService  # Deferred
        return UserService(self)

# services.py
from mypackage.models import User  # No circular import

class UserService:
    def __init__(self, user: User):
        self.user = user
```

**Type-only imports to avoid circular:**

```python
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mypackage.models import User  # Only for type hints

class UserService:
    def __init__(self, user: User):  # Type hint works
        self.user = user
```

**Import organization (PEP 8):**

```python
# 1. Standard library imports
import os
import sys
from pathlib import Path

# 2. Third-party imports
import numpy as np
import pandas as pd
from fastapi import FastAPI

# 3. Local application imports
from mypackage.models import User
from mypackage.utils import helpers
```

Reference: [PEP 8 - Imports](https://peps.python.org/pep-0008/#imports)
