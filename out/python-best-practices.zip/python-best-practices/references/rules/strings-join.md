---
title: Use str.join for String Concatenation
impact: LOW-MEDIUM
impactDescription: O(n) vs O(n²) for many strings
tags: strings, join, concatenation, performance
---

## Use str.join for String Concatenation

String concatenation with `+` creates intermediate strings. For many strings, use `str.join()` for O(n) performance.

**Incorrect (O(n²) concatenation):**

```python
def build_csv(rows: list[list[str]]) -> str:
    result = ''
    for row in rows:
        line = ''
        for cell in row:
            line = line + cell + ','  # Creates new string each time
        result = result + line[:-1] + '\n'
    return result

def format_items(items: list[str]) -> str:
    result = ''
    for i, item in enumerate(items):
        result += f"{i + 1}. {item}\n"  # O(n) per concatenation
    return result
```

**Correct (O(n) join):**

```python
def build_csv(rows: list[list[str]]) -> str:
    return '\n'.join(','.join(row) for row in rows)

def format_items(items: list[str]) -> str:
    return '\n'.join(f"{i + 1}. {item}" for i, item in enumerate(items, 1))
```

**Building strings in loops:**

```python
# Incorrect: repeated concatenation
def process_log(entries: list[str]) -> str:
    output = ''
    for entry in entries:
        output += f"[LOG] {entry}\n"
    return output

# Correct: collect then join
def process_log(entries: list[str]) -> str:
    lines = [f"[LOG] {entry}" for entry in entries]
    return '\n'.join(lines)

# Or with generator (memory efficient)
def process_log(entries: list[str]) -> str:
    return '\n'.join(f"[LOG] {entry}" for entry in entries)
```

**Common join patterns:**

```python
# Join with separator
words = ['hello', 'world']
' '.join(words)      # 'hello world'
', '.join(words)     # 'hello, world'
''.join(words)       # 'helloworld'
'\n'.join(words)     # 'hello\nworld'

# Join with path separator
from pathlib import Path
path = Path('/', 'home', 'user', 'file.txt')

# Join filtered values
valid = ', '.join(x for x in items if x)  # Skip empty/None
```

**When `+` concatenation is fine:**
- Few strings (2-3)
- Single concatenation (not in loop)
- f-strings are better for interpolation

```python
# These are fine:
full_name = first_name + ' ' + last_name
message = f"Hello, {name}!"
```
