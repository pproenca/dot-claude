---
title: Use Async Context Managers
impact: MEDIUM
impactDescription: proper async resource cleanup
tags: async, asyncio, context-manager, aenter, aexit
---

## Use Async Context Managers

For resources that require async setup or cleanup, use `async with` to ensure proper lifecycle management.

**Incorrect (manual async cleanup):**

```python
async def fetch_data():
    client = httpx.AsyncClient()
    try:
        response = await client.get('https://api.example.com')
        return response.json()
    finally:
        await client.aclose()  # Easy to forget

async def query_database():
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        result = await conn.fetch('SELECT * FROM users')
        return result
    finally:
        await conn.close()
```

**Correct (async context manager):**

```python
async def fetch_data():
    async with httpx.AsyncClient() as client:
        response = await client.get('https://api.example.com')
        return response.json()
    # client.aclose() called automatically

async def query_database():
    async with asyncpg.create_pool(DATABASE_URL) as pool:
        async with pool.acquire() as conn:
            return await conn.fetch('SELECT * FROM users')
    # Connection returned to pool automatically
```

**Creating custom async context managers:**

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def managed_connection(url: str):
    conn = await create_connection(url)
    try:
        yield conn
    finally:
        await conn.close()

async def use_connection():
    async with managed_connection('postgres://...') as conn:
        await conn.execute('...')
```

**Class-based async context manager:**

```python
class AsyncDatabaseSession:
    def __init__(self, url: str):
        self.url = url
        self.conn = None

    async def __aenter__(self):
        self.conn = await asyncpg.connect(self.url)
        return self.conn

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.conn.close()
        return False  # Don't suppress exceptions

async def main():
    async with AsyncDatabaseSession(DATABASE_URL) as conn:
        await conn.execute('...')
```

**Async iteration with context manager:**

```python
class AsyncFileReader:
    def __init__(self, path: str):
        self.path = path
        self.file = None

    async def __aenter__(self):
        self.file = await aiofiles.open(self.path)
        return self

    async def __aexit__(self, *args):
        await self.file.close()

    def __aiter__(self):
        return self

    async def __anext__(self):
        line = await self.file.readline()
        if not line:
            raise StopAsyncIteration
        return line.strip()

async def process_file():
    async with AsyncFileReader('data.txt') as reader:
        async for line in reader:
            process(line)
```
