---
title: Use secrets Module for Security
impact: LOW-MEDIUM
impactDescription: Cryptographically secure randomness
tags: security, secrets, random, tokens
---

## Use secrets Module for Security

Use `secrets` module for cryptographic randomness, not `random`.

**Incorrect (using random for security):**

```python
import random
import string

def generate_token() -> str:
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(32))
```

**Correct (using secrets module):**

```python
import secrets
import string

def generate_token() -> str:
    return secrets.token_urlsafe(32)

def generate_password(length: int = 16) -> str:
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(chars) for _ in range(length))

# Timing-attack safe comparison
def verify_token(provided: str, expected: str) -> bool:
    return secrets.compare_digest(provided, expected)
```

Reference: [secrets module](https://docs.python.org/3/library/secrets.html)
