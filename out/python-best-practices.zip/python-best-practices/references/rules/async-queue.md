---
title: Use asyncio.Queue for Producer-Consumer
impact: HIGH
impactDescription: efficient async data pipeline
tags: async, asyncio, queue, producer-consumer
---

## Use asyncio.Queue for Producer-Consumer

`asyncio.Queue` provides thread-safe communication between async tasks without blocking.

**Incorrect (shared list with manual coordination):**

```python
async def producer_consumer():
    items = []
    done = False

    async def producer():
        nonlocal done
        for i in range(100):
            items.append(i)
            await asyncio.sleep(0.01)
        done = True

    async def consumer():
        while not done or items:
            if items:
                item = items.pop(0)  # O(n) operation!
                await process(item)
            else:
                await asyncio.sleep(0.01)  # Busy waiting

    await asyncio.gather(producer(), consumer())
```

**Correct (asyncio.Queue):**

```python
async def producer_consumer():
    queue: asyncio.Queue[int] = asyncio.Queue(maxsize=10)

    async def producer():
        for i in range(100):
            await queue.put(i)  # Blocks if queue full
        await queue.put(None)  # Sentinel to signal done

    async def consumer():
        while True:
            item = await queue.get()  # Blocks until item available
            if item is None:
                break
            await process(item)
            queue.task_done()

    await asyncio.gather(producer(), consumer())
```

**Multiple consumers:**

```python
async def parallel_processing(items: list, num_workers: int = 4):
    queue: asyncio.Queue = asyncio.Queue()
    results: list = []

    async def worker(worker_id: int):
        while True:
            item = await queue.get()
            if item is None:
                queue.task_done()
                break
            result = await process(item)
            results.append(result)
            queue.task_done()

    # Start workers
    workers = [asyncio.create_task(worker(i)) for i in range(num_workers)]

    # Feed items to queue
    for item in items:
        await queue.put(item)

    # Send shutdown signal to all workers
    for _ in range(num_workers):
        await queue.put(None)

    # Wait for all items to be processed
    await queue.join()
    await asyncio.gather(*workers)

    return results
```

**Priority queue:**

```python
import asyncio
from dataclasses import dataclass, field
from typing import Any

@dataclass(order=True)
class PrioritizedItem:
    priority: int
    item: Any = field(compare=False)

async def priority_processing():
    queue: asyncio.PriorityQueue = asyncio.PriorityQueue()

    await queue.put(PrioritizedItem(2, "low priority"))
    await queue.put(PrioritizedItem(0, "high priority"))
    await queue.put(PrioritizedItem(1, "medium priority"))

    while not queue.empty():
        item = await queue.get()
        print(item.item)  # high, medium, low
```
