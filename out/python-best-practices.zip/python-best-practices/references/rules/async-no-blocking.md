---
title: Avoid Blocking Calls in Async Functions
impact: HIGH
impactDescription: prevents event loop blocking
tags: async, asyncio, blocking, event-loop
---

## Avoid Blocking Calls in Async Functions

Blocking calls in async functions stop the entire event loop. Use async alternatives or run blocking code in executors.

**Incorrect (blocks event loop):**

```python
async def process_request(request):
    # These block the event loop!
    data = requests.get(url).json()  # Blocking HTTP
    time.sleep(1)  # Blocking sleep
    result = heavy_computation(data)  # CPU-bound blocking
    with open('file.txt') as f:  # Blocking file I/O
        content = f.read()
    return result
```

**Correct (non-blocking alternatives):**

```python
import asyncio
import aiofiles
import httpx

async def process_request(request):
    # Async HTTP client
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        data = response.json()

    # Async sleep
    await asyncio.sleep(1)

    # Run CPU-bound in thread pool
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, heavy_computation, data)

    # Async file I/O
    async with aiofiles.open('file.txt') as f:
        content = await f.read()

    return result
```

**Run blocking code in executor:**

```python
import asyncio
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# Thread pool for I/O-bound blocking code
thread_pool = ThreadPoolExecutor(max_workers=10)

# Process pool for CPU-bound code
process_pool = ProcessPoolExecutor(max_workers=4)

async def fetch_sync_api(url: str) -> dict:
    """Run blocking requests library in thread pool."""
    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(
        thread_pool,
        lambda: requests.get(url).json()
    )
    return response

async def compute_heavy(data: list) -> int:
    """Run CPU-bound computation in process pool."""
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        process_pool,
        heavy_computation,
        data
    )
    return result
```

**Common blocking calls to avoid:**
- `requests.get()` → use `httpx` or `aiohttp`
- `time.sleep()` → use `asyncio.sleep()`
- `open().read()` → use `aiofiles`
- Database drivers → use async versions (asyncpg, aiomysql)
- `subprocess.run()` → use `asyncio.create_subprocess_exec()`
