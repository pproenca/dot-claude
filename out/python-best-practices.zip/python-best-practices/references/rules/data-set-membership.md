---
title: Use Set for O(1) Membership Testing
impact: MEDIUM-HIGH
impactDescription: O(1) vs O(n) lookup
tags: data-structures, set, membership, lookup
---

## Use Set for O(1) Membership Testing

Lists require O(n) time for membership testing. Sets use hash tables for O(1) average-case lookup.

**Incorrect (O(n) list lookup):**

```python
def filter_valid_users(users: list[dict], valid_ids: list[int]) -> list[dict]:
    return [u for u in users if u['id'] in valid_ids]
    # For 10K users × 10K valid_ids = 100M comparisons

def has_duplicates(items: list) -> bool:
    seen = []
    for item in items:
        if item in seen:  # O(n) per check
            return True
        seen.append(item)
    return False
    # O(n²) total
```

**Correct (O(1) set lookup):**

```python
def filter_valid_users(users: list[dict], valid_ids: list[int]) -> list[dict]:
    valid_set = set(valid_ids)  # O(n) one-time conversion
    return [u for u in users if u['id'] in valid_set]
    # For 10K users × 10K valid_ids = 10K lookups

def has_duplicates(items: list) -> bool:
    seen = set()
    for item in items:
        if item in seen:  # O(1) per check
            return True
        seen.add(item)
    return False
    # O(n) total

# Even simpler:
def has_duplicates(items: list) -> bool:
    return len(items) != len(set(items))
```

**Set operations for filtering:**

```python
# Find common elements
list_a = [1, 2, 3, 4, 5]
list_b = [4, 5, 6, 7, 8]
common = list(set(list_a) & set(list_b))  # [4, 5]

# Find differences
only_in_a = list(set(list_a) - set(list_b))  # [1, 2, 3]

# Remove duplicates while preserving order
def dedupe_ordered(items: list) -> list:
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
```

**When to use list instead:**
- Need to preserve duplicates
- Need ordered iteration (use `dict.fromkeys()` for ordered unique)
- Items are unhashable (dicts, lists)
- Very small collections (< 10 items, overhead not worth it)
