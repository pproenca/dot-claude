---
title: Use Context Managers for File Handling
impact: CRITICAL
impactDescription: prevents resource leaks
tags: io, files, context-manager, with-statement
---

## Use Context Managers for File Handling

Always use `with` statements for file operations to ensure proper resource cleanup, even when exceptions occur.

**Incorrect (manual file handling):**

```python
def read_config(path: str) -> dict:
    f = open(path, 'r')
    data = json.load(f)
    f.close()  # Never reached if json.load() raises
    return data

def write_log(path: str, message: str) -> None:
    f = open(path, 'a')
    f.write(message + '\n')
    # Forgot to close - file descriptor leak
```

**Correct (context manager):**

```python
def read_config(path: str) -> dict:
    with open(path, 'r') as f:
        return json.load(f)
    # File automatically closed, even on exception

def write_log(path: str, message: str) -> None:
    with open(path, 'a') as f:
        f.write(message + '\n')
    # File automatically closed
```

**Multiple files:**

```python
# Incorrect: nested try-finally
def copy_file(src: str, dst: str) -> None:
    f_src = open(src, 'rb')
    try:
        f_dst = open(dst, 'wb')
        try:
            f_dst.write(f_src.read())
        finally:
            f_dst.close()
    finally:
        f_src.close()

# Correct: multiple context managers
def copy_file(src: str, dst: str) -> None:
    with open(src, 'rb') as f_src, open(dst, 'wb') as f_dst:
        f_dst.write(f_src.read())
```

Reference: [PEP 343 - The "with" Statement](https://peps.python.org/pep-0343/)
