---
title: Buffer File Reads and Writes
impact: CRITICAL
impactDescription: 10-100× improvement for large files
tags: io, files, buffering, performance
---

## Buffer File Reads and Writes

Reading or writing files line-by-line or byte-by-byte causes excessive system calls. Use buffered I/O or read in chunks.

**Incorrect (unbuffered line-by-line):**

```python
def process_large_file(path: str) -> int:
    count = 0
    with open(path, 'r') as f:
        for line in f:  # Already buffered, but...
            # Writing unbuffered
            with open('output.txt', 'a') as out:  # Opens file N times!
                out.write(line.upper())
            count += 1
    return count
```

**Correct (buffered batch processing):**

```python
def process_large_file(path: str) -> int:
    count = 0
    with open(path, 'r') as f, open('output.txt', 'w') as out:
        for line in f:
            out.write(line.upper())
            count += 1
    return count
```

**For binary files, use explicit buffering:**

```python
# Incorrect: reading entire file into memory
def hash_file(path: str) -> str:
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()  # OOM for large files

# Correct: chunked reading
def hash_file(path: str, chunk_size: int = 8192) -> str:
    hasher = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(chunk_size):
            hasher.update(chunk)
    return hasher.hexdigest()
```

**Adjust buffer size for your use case:**

```python
# Larger buffer for sequential reads (128KB)
with open(path, 'rb', buffering=131072) as f:
    process(f)

# Line-buffered for real-time logs
with open(path, 'w', buffering=1) as f:
    f.write('immediate\n')
```
