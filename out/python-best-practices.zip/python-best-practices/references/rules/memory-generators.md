---
title: Use Generators Instead of Lists for Large Sequences
impact: CRITICAL
impactDescription: constant memory vs O(n) memory
tags: memory, generators, yield, lazy-evaluation
---

## Use Generators Instead of Lists for Large Sequences

Generators produce values on-demand, using constant memory regardless of sequence size. Lists store all values in memory simultaneously.

**Incorrect (list stores all values):**

```python
def get_log_lines(path: str) -> list[str]:
    with open(path, 'r') as f:
        return [line.strip() for line in f]  # Loads entire file into memory

def process_logs(path: str) -> int:
    lines = get_log_lines(path)  # 10GB file = 10GB+ memory
    error_count = sum(1 for line in lines if 'ERROR' in line)
    return error_count
```

**Correct (generator yields on demand):**

```python
def get_log_lines(path: str) -> Iterator[str]:
    with open(path, 'r') as f:
        for line in f:
            yield line.strip()  # One line at a time

def process_logs(path: str) -> int:
    lines = get_log_lines(path)  # Returns immediately, constant memory
    error_count = sum(1 for line in lines if 'ERROR' in line)
    return error_count
```

**Generator expressions vs list comprehensions:**

```python
# Incorrect: creates list of 10 million items
squares = [x ** 2 for x in range(10_000_000)]
result = sum(squares)

# Correct: generator expression, constant memory
squares = (x ** 2 for x in range(10_000_000))
result = sum(squares)
```

**Chaining generators:**

```python
def read_files(paths: list[str]) -> Iterator[str]:
    for path in paths:
        with open(path, 'r') as f:
            yield from f  # Yields each line from each file

def filter_errors(lines: Iterator[str]) -> Iterator[str]:
    for line in lines:
        if 'ERROR' in line:
            yield line

def format_errors(lines: Iterator[str]) -> Iterator[str]:
    for line in lines:
        yield f"[ERROR] {line.strip()}"

# Pipeline uses constant memory regardless of file sizes
paths = ['app.log', 'error.log', 'debug.log']
errors = format_errors(filter_errors(read_files(paths)))
for error in errors:
    print(error)
```

**When to use lists instead:**
- Need random access (indexing)
- Need to iterate multiple times
- Small, known-size collections
- Need `len()` or slicing
