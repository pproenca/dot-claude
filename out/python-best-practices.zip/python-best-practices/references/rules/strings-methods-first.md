---
title: Use String Methods Before Regex
impact: LOW-MEDIUM
impactDescription: 10-100× faster for simple operations
tags: strings, methods, regex, performance
---

## Use String Methods Before Regex

Built-in string methods are much faster than regex for simple operations. Only use regex when pattern matching is needed.

**Incorrect (regex for simple operations):**

```python
import re

def clean_whitespace(text: str) -> str:
    return re.sub(r'\s+', ' ', text).strip()

def check_prefix(text: str, prefix: str) -> bool:
    return bool(re.match(rf'^{re.escape(prefix)}', text))

def split_on_comma(text: str) -> list[str]:
    return re.split(r',\s*', text)

def remove_digits(text: str) -> str:
    return re.sub(r'\d', '', text)
```

**Correct (string methods):**

```python
def clean_whitespace(text: str) -> str:
    return ' '.join(text.split())  # split() handles all whitespace

def check_prefix(text: str, prefix: str) -> bool:
    return text.startswith(prefix)

def split_on_comma(text: str) -> list[str]:
    return [part.strip() for part in text.split(',')]

def remove_digits(text: str) -> str:
    return text.translate(str.maketrans('', '', '0123456789'))
```

**String methods reference:**

```python
text = "  Hello, World!  "

# Stripping
text.strip()         # 'Hello, World!'
text.lstrip()        # 'Hello, World!  '
text.rstrip()        # '  Hello, World!'
text.strip(' !')     # 'Hello, World'

# Checking
text.startswith('  H')
text.endswith('!  ')
text.isalnum()
text.isalpha()
text.isdigit()
text.islower()
text.isupper()

# Finding
text.find('World')   # 9 (index, or -1 if not found)
text.index('World')  # 9 (raises if not found)
text.count('l')      # 3
'World' in text      # True

# Replacing
text.replace('World', 'Python')
text.replace('l', 'L', 1)  # Replace only first occurrence

# Splitting and joining
text.split()         # ['Hello,', 'World!']
text.split(',')      # ['  Hello', ' World!  ']
'|'.join(['a', 'b']) # 'a|b'

# Case conversion
text.lower()
text.upper()
text.title()
text.capitalize()
text.swapcase()
```

**translate for character removal/mapping:**

```python
# Remove specific characters (faster than regex)
remove_chars = str.maketrans('', '', '.,!?')
text.translate(remove_chars)

# Replace characters
replace_chars = str.maketrans('abc', 'xyz')
'abcdef'.translate(replace_chars)  # 'xyzdef'
```

**When to use regex:**
- Complex patterns (email, URL, phone)
- Wildcards and character classes
- Capturing groups
- Variable repetition
- Lookahead/lookbehind
