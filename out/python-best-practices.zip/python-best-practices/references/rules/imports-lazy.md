---
title: Use Lazy Imports for Slow Modules
impact: MEDIUM
impactDescription: faster startup time
tags: imports, lazy, startup, performance
---

## Use Lazy Imports for Slow Modules

Some modules are expensive to import. Defer imports until actually needed to reduce startup time.

**Incorrect (eager import slows startup):**

```python
import pandas as pd  # ~500ms to import
import numpy as np   # ~200ms to import
import tensorflow    # ~2000ms to import

def process_data(data: list) -> list:
    # Only uses pandas, but all modules imported at startup
    df = pd.DataFrame(data)
    return df.to_dict()

def simple_calculation(x: int) -> int:
    # Doesn't use any heavy imports
    return x * 2
```

**Correct (lazy import when needed):**

```python
def process_data(data: list) -> list:
    import pandas as pd  # Only imported when function is called
    df = pd.DataFrame(data)
    return df.to_dict()

def train_model(data):
    import tensorflow as tf  # Only imported when training
    model = tf.keras.Sequential([...])
    return model.fit(data)

def simple_calculation(x: int) -> int:
    return x * 2  # No import overhead
```

**Module-level lazy import pattern:**

```python
# Type hints without runtime import
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd  # Only imported for type checking

_pd = None

def get_pandas():
    global _pd
    if _pd is None:
        import pandas as pd
        _pd = pd
    return _pd

def process_data(data: list) -> pd.DataFrame:
    pd = get_pandas()
    return pd.DataFrame(data)
```

**Using importlib for conditional imports:**

```python
import importlib

def get_optional_dependency(name: str):
    try:
        return importlib.import_module(name)
    except ImportError:
        return None

# Use optional dependency
orjson = get_optional_dependency('orjson')
if orjson:
    dumps = orjson.dumps
else:
    import json
    dumps = json.dumps
```

**When to use lazy imports:**
- CLI tools where only some commands need heavy modules
- Libraries where not all features need all dependencies
- Startup-time-critical applications
- Optional features with optional dependencies
