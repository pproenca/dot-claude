---
title: Use enumerate Instead of Manual Counters
impact: MEDIUM
impactDescription: cleaner code, avoids off-by-one errors
tags: iteration, enumerate, index, loops
---

## Use enumerate Instead of Manual Counters

`enumerate()` provides index and value together, eliminating manual counter management.

**Incorrect (manual counter):**

```python
def find_indices(items: list, target) -> list[int]:
    indices = []
    i = 0
    for item in items:
        if item == target:
            indices.append(i)
        i += 1  # Easy to forget or misplace
    return indices

def print_numbered(items: list) -> None:
    i = 0
    while i < len(items):
        print(f"{i + 1}. {items[i]}")
        i += 1
```

**Correct (enumerate):**

```python
def find_indices(items: list, target) -> list[int]:
    return [i for i, item in enumerate(items) if item == target]

def print_numbered(items: list) -> None:
    for i, item in enumerate(items, start=1):  # Start from 1
        print(f"{i}. {item}")
```

**enumerate with unpacking:**

```python
# Enumerate over tuples
pairs = [('a', 1), ('b', 2), ('c', 3)]
for i, (letter, number) in enumerate(pairs):
    print(f"{i}: {letter} = {number}")

# Enumerate over dict items
for i, (key, value) in enumerate(data.items()):
    print(f"{i}: {key} -> {value}")
```

**Custom start index:**

```python
# Start from 1 (for user-facing output)
for line_num, line in enumerate(lines, start=1):
    if 'error' in line.lower():
        print(f"Error on line {line_num}: {line}")

# Start from offset
for chunk_num, chunk in enumerate(chunks, start=offset):
    process_chunk(chunk_num, chunk)
```

**Avoid indexing when iterating:**

```python
# Incorrect: unnecessary indexing
for i in range(len(items)):
    process(items[i])

# Correct: direct iteration
for item in items:
    process(item)

# When you need the index too
for i, item in enumerate(items):
    process(i, item)
```

**zip with enumerate:**

```python
# Iterate multiple lists with index
names = ['Alice', 'Bob', 'Charlie']
scores = [95, 87, 92]

for i, (name, score) in enumerate(zip(names, scores), start=1):
    print(f"{i}. {name}: {score}")
```
