---
title: Intern Repeated Strings
impact: LOW-MEDIUM
impactDescription: reduces memory for repeated strings
tags: memory, strings, intern, deduplication
---

## Intern Repeated Strings

When the same string appears many times, interning ensures only one copy exists in memory.

**Incorrect (duplicate string objects):**

```python
def load_records(data: list[dict]) -> list[Record]:
    records = []
    for d in data:
        # Each record has its own copy of status string
        records.append(Record(
            status=d['status'],  # "active", "inactive", "pending"
            category=d['category']  # Repeated values
        ))
    return records

# 1 million records with status="active" = 1 million string objects
```

**Correct (interned strings):**

```python
import sys

def load_records(data: list[dict]) -> list[Record]:
    records = []
    for d in data:
        records.append(Record(
            status=sys.intern(d['status']),
            category=sys.intern(d['category'])
        ))
    return records

# 1 million records with status="active" = 1 string object
```

**Pre-intern known values:**

```python
# Define interned constants
STATUS_ACTIVE = sys.intern('active')
STATUS_INACTIVE = sys.intern('inactive')
STATUS_PENDING = sys.intern('pending')

STATUS_MAP = {
    'active': STATUS_ACTIVE,
    'inactive': STATUS_INACTIVE,
    'pending': STATUS_PENDING,
}

def load_records(data: list[dict]) -> list[Record]:
    records = []
    for d in data:
        records.append(Record(
            status=STATUS_MAP.get(d['status'], sys.intern(d['status'])),
        ))
    return records
```

**When to use interning:**
- High-cardinality columns with repeated values (status, category, country)
- Log processing with repeated message templates
- Parsing with repeated tokens

**When NOT to use:**
- Unique strings (IDs, timestamps)
- Short-lived strings
- Already-interned literals (Python auto-interns string literals)

**Note:** Python automatically interns:
- String literals in source code
- Strings that look like identifiers
- Dictionary keys (implementation detail)

```python
# These are automatically interned
a = 'hello'
b = 'hello'
a is b  # True (same object)

# These are NOT automatically interned
a = ''.join(['h', 'e', 'l', 'l', 'o'])
b = ''.join(['h', 'e', 'l', 'l', 'o'])
a is b  # False (different objects)
```
