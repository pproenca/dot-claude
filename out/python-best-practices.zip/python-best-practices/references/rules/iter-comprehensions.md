---
title: Use List Comprehensions Over map/filter
impact: MEDIUM
impactDescription: more readable, often faster
tags: iteration, comprehensions, map, filter
---

## Use List Comprehensions Over map/filter

List comprehensions are more Pythonic, more readable, and often faster than `map()` and `filter()` with lambdas.

**Incorrect (map/filter with lambdas):**

```python
# Hard to read, slower due to function call overhead
squares = list(map(lambda x: x ** 2, numbers))
evens = list(filter(lambda x: x % 2 == 0, numbers))
even_squares = list(map(lambda x: x ** 2, filter(lambda x: x % 2 == 0, numbers)))

# Nested map is even worse
matrix_doubled = list(map(lambda row: list(map(lambda x: x * 2, row)), matrix))
```

**Correct (list comprehensions):**

```python
# Clear and fast
squares = [x ** 2 for x in numbers]
evens = [x for x in numbers if x % 2 == 0]
even_squares = [x ** 2 for x in numbers if x % 2 == 0]

# Nested comprehension
matrix_doubled = [[x * 2 for x in row] for row in matrix]
```

**When map IS appropriate:**

```python
# With existing named function (no lambda)
names = ['alice', 'bob', 'charlie']

# This is fine - no lambda overhead
upper_names = list(map(str.upper, names))

# Equivalent comprehension (also fine)
upper_names = [name.upper() for name in names]

# map with multiple iterables
pairs = list(map(lambda a, b: a + b, list1, list2))
# Comprehension alternative
pairs = [a + b for a, b in zip(list1, list2)]
```

**Dictionary and set comprehensions:**

```python
# Dictionary comprehension
word_lengths = {word: len(word) for word in words}

# Set comprehension
unique_lengths = {len(word) for word in words}

# Conditional dictionary
long_words = {word: len(word) for word in words if len(word) > 5}
```

**Generator expressions for memory efficiency:**

```python
# List comprehension (stores all in memory)
total = sum([x ** 2 for x in range(1_000_000)])

# Generator expression (constant memory)
total = sum(x ** 2 for x in range(1_000_000))
```

**Readability limit - don't overdo it:**

```python
# Too complex - use a loop instead
result = [
    transform(x)
    for group in data
    for x in group.items
    if x.active and group.visible
    if not x.deleted
]

# Clearer as a loop
result = []
for group in data:
    if not group.visible:
        continue
    for x in group.items:
        if x.active and not x.deleted:
            result.append(transform(x))
```
