---
title: Use pathlib for Path Operations
impact: MEDIUM
impactDescription: cleaner code, fewer bugs
tags: io, files, pathlib, paths
---

## Use pathlib for Path Operations

`pathlib` provides an object-oriented interface for filesystem paths, reducing string manipulation errors and improving readability.

**Incorrect (string manipulation):**

```python
import os

def get_config_path(base_dir: str, env: str) -> str:
    return os.path.join(base_dir, 'config', env + '.json')

def ensure_dir(path: str) -> None:
    dir_path = os.path.dirname(path)
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def list_python_files(directory: str) -> list[str]:
    result = []
    for root, dirs, files in os.walk(directory):
        for f in files:
            if f.endswith('.py'):
                result.append(os.path.join(root, f))
    return result
```

**Correct (pathlib):**

```python
from pathlib import Path

def get_config_path(base_dir: str, env: str) -> Path:
    return Path(base_dir) / 'config' / f'{env}.json'

def ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

def list_python_files(directory: str) -> list[Path]:
    return list(Path(directory).rglob('*.py'))
```

**Common pathlib patterns:**

```python
from pathlib import Path

path = Path('/home/user/project/data/file.txt')

# Path components
path.name        # 'file.txt'
path.stem        # 'file'
path.suffix      # '.txt'
path.parent      # Path('/home/user/project/data')
path.parts       # ('/', 'home', 'user', 'project', 'data', 'file.txt')

# Path operations
path.exists()
path.is_file()
path.is_dir()
path.stat().st_size

# Reading and writing
text = path.read_text()
path.write_text('content')
data = path.read_bytes()
path.write_bytes(b'data')

# Finding files
Path('.').glob('*.py')       # Current dir only
Path('.').rglob('*.py')      # Recursive
Path('.').iterdir()          # List directory contents
```

Reference: [pathlib documentation](https://docs.python.org/3/library/pathlib.html)
