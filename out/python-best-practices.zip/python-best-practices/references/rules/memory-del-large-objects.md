---
title: Explicitly Delete Large Objects
impact: MEDIUM
impactDescription: frees memory immediately
tags: memory, del, garbage-collection, large-objects
---

## Explicitly Delete Large Objects

Python's garbage collector may not immediately free memory for large objects. Use `del` and `gc.collect()` when you need to free memory promptly.

**Incorrect (memory held until GC runs):**

```python
def process_large_dataset():
    data = load_huge_dataset()  # 2GB in memory
    result = analyze(data)

    # data still in memory here
    do_more_work()  # Might OOM if needs memory

    return result
    # data finally eligible for GC after function returns
```

**Correct (explicit deletion):**

```python
import gc

def process_large_dataset():
    data = load_huge_dataset()  # 2GB in memory
    result = analyze(data)

    del data  # Remove reference
    gc.collect()  # Force garbage collection

    do_more_work()  # Memory now available

    return result
```

**Context manager for temporary large objects:**

```python
from contextlib import contextmanager
import gc

@contextmanager
def temporary_large_object(loader):
    """Load large object and ensure cleanup."""
    obj = loader()
    try:
        yield obj
    finally:
        del obj
        gc.collect()

def process():
    with temporary_large_object(load_huge_dataset) as data:
        result = analyze(data)
    # data deleted and collected here

    # Safe to allocate more memory
    another_result = do_more_work()
    return result, another_result
```

**Chunked processing to avoid large objects:**

```python
# Incorrect: load all into memory
def process_all_files(paths: list[str]) -> list[Result]:
    all_data = [load_file(p) for p in paths]  # All in memory
    return [process(d) for d in all_data]

# Correct: process one at a time
def process_all_files(paths: list[str]) -> list[Result]:
    results = []
    for path in paths:
        data = load_file(path)
        results.append(process(data))
        del data  # Free before next iteration
    return results
```

**Note:** Don't overuse `del` and `gc.collect()`. They're only needed for:
- Very large objects (hundreds of MB+)
- Memory-constrained environments
- Long-running processes with periodic large allocations
