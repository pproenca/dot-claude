---
title: Use defaultdict for Grouping
impact: MEDIUM
impactDescription: cleaner code, fewer conditionals
tags: data-structures, defaultdict, grouping, collections
---

## Use defaultdict for Grouping

`collections.defaultdict` eliminates key-existence checks when building grouped data structures.

**Incorrect (manual key checking):**

```python
def group_by_category(items: list[dict]) -> dict[str, list]:
    groups = {}
    for item in items:
        category = item['category']
        if category not in groups:
            groups[category] = []
        groups[category].append(item)
    return groups

def count_words(text: str) -> dict[str, int]:
    counts = {}
    for word in text.split():
        if word not in counts:
            counts[word] = 0
        counts[word] += 1
    return counts
```

**Correct (defaultdict):**

```python
from collections import defaultdict

def group_by_category(items: list[dict]) -> dict[str, list]:
    groups = defaultdict(list)
    for item in items:
        groups[item['category']].append(item)
    return dict(groups)

def count_words(text: str) -> dict[str, int]:
    counts = defaultdict(int)
    for word in text.split():
        counts[word] += 1
    return dict(counts)
```

**Common defaultdict patterns:**

```python
from collections import defaultdict

# Grouping with set (unique values)
def unique_tags_by_user(posts: list[dict]) -> dict[int, set]:
    tags = defaultdict(set)
    for post in posts:
        tags[post['user_id']].update(post['tags'])
    return dict(tags)

# Nested defaultdict
def nested_groups(items: list[dict]) -> dict:
    groups = defaultdict(lambda: defaultdict(list))
    for item in items:
        groups[item['year']][item['month']].append(item)
    return groups

# Accumulating values
def sum_by_category(items: list[dict]) -> dict[str, float]:
    totals = defaultdict(float)
    for item in items:
        totals[item['category']] += item['amount']
    return dict(totals)
```

**Alternative: dict.setdefault():**

```python
# For one-off uses without importing
def group_by_category(items: list[dict]) -> dict[str, list]:
    groups = {}
    for item in items:
        groups.setdefault(item['category'], []).append(item)
    return groups
```

**Counter for counting:**

```python
from collections import Counter

# Even simpler for counting
def count_words(text: str) -> dict[str, int]:
    return dict(Counter(text.split()))

# Most common
counter = Counter(text.split())
top_10 = counter.most_common(10)
```
