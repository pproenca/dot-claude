---
title: Chain Exceptions Properly
impact: MEDIUM
impactDescription: Preserves full traceback for debugging
tags: error, exception, chaining, traceback
---

## Chain Exceptions Properly

Always use `raise ... from` to properly chain exceptions and preserve context. This provides better debugging information.

**Incorrect (losing exception context):**

```python
def process_config(path: str) -> dict:
    """Process configuration file."""
    try:
        with open(path) as f:
            return parse_config(f.read())
    except FileNotFoundError:
        raise ConfigError("Config file not found")  # Loses original traceback

def fetch_data(url: str) -> dict:
    try:
        return make_request(url)
    except Exception:
        raise DataError("Failed to fetch data")  # Loses original exception
```

**Correct (properly chaining exceptions):**

```python
def process_config(path: str) -> dict:
    """Process configuration file."""
    try:
        with open(path) as f:
            return parse_config(f.read())
    except FileNotFoundError as e:
        raise ConfigError(f"Config file not found: {path}") from e

def fetch_data(url: str) -> dict:
    try:
        return make_request(url)
    except RequestError as e:
        raise DataError(f"Failed to fetch data from {url}") from e
    except Exception as e:
        # Use 'from None' to explicitly suppress chain if needed
        raise DataError("Unexpected error") from None
```

Reference: [Python Exception Chaining](https://docs.python.org/3/tutorial/errors.html#exception-chaining)
