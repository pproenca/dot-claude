---
title: Store Secrets in Environment Variables
impact: LOW-MEDIUM
impactDescription: Keeps secrets out of code
tags: security, secrets, environment, configuration
---

## Store Secrets in Environment Variables

Never hardcode secrets in source code.

**Incorrect (hardcoded secrets):**

```python
API_KEY = "sk-1234567890abcdef"
DATABASE_URL = "postgresql://user:password@localhost/db"
```

**Correct (environment variables):**

```python
import os

API_KEY = os.environ["API_KEY"]
DATABASE_URL = os.environ["DATABASE_URL"]

# With defaults for optional settings
DEBUG = os.environ.get("DEBUG", "false").lower() == "true"

# Using pydantic-settings for validation
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    api_key: str
    database_url: str
    debug: bool = False

    class Config:
        env_file = ".env"

settings = Settings()
```

Reference: [pydantic-settings](https://docs.pydantic.dev/latest/concepts/pydantic_settings/)
