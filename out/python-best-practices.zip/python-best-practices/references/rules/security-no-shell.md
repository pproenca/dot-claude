---
title: Avoid shell=True in Subprocess
impact: LOW-MEDIUM
impactDescription: Prevents shell injection
tags: security, subprocess, shell, injection
---

## Avoid shell=True in Subprocess

Avoid `shell=True` in subprocess calls to prevent shell injection attacks.

**Incorrect (using shell=True):**

```python
import subprocess

def list_files(directory: str) -> str:
    """List files in a directory."""
    result = subprocess.run(
        f"ls -la {directory}",  # DANGER: Shell injection!
        shell=True,
        capture_output=True,
        text=True
    )
    return result.stdout
```

**Correct (pass arguments as list):**

```python
import subprocess
from pathlib import Path

def list_files(directory: str) -> str:
    """Safely list files in a directory."""
    path = Path(directory).resolve()
    result = subprocess.run(
        ["ls", "-la", str(path)],
        capture_output=True,
        text=True,
        check=True
    )
    return result.stdout

# If you need shell features, use shlex.quote
import shlex

def safe_shell_command(user_input: str) -> str:
    quoted = shlex.quote(user_input)
    # Still prefer avoiding shell=True when possible
```

Reference: [subprocess security](https://docs.python.org/3/library/subprocess.html#security-considerations)
