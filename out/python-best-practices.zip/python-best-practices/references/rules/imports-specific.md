---
title: Import Specific Names, Not Modules
impact: LOW-MEDIUM
impactDescription: clearer code, slight performance benefit
tags: imports, specific, namespace, clarity
---

## Import Specific Names, Not Modules

Importing specific names makes dependencies explicit and avoids repeated attribute lookups in hot paths.

**Incorrect (module-level imports with attribute access):**

```python
import os
import json
import collections

def process_files(directory: str) -> list[dict]:
    results = []
    for filename in os.listdir(directory):  # os.listdir
        path = os.path.join(directory, filename)  # os.path.join
        if os.path.isfile(path):  # os.path.isfile
            with open(path) as f:
                data = json.load(f)  # json.load
                results.append(data)
    return results

def count_items(items: list) -> dict:
    return dict(collections.Counter(items))  # collections.Counter
```

**Correct (specific imports):**

```python
from os import listdir
from os.path import join, isfile
from json import load as json_load
from collections import Counter

def process_files(directory: str) -> list[dict]:
    results = []
    for filename in listdir(directory):
        path = join(directory, filename)
        if isfile(path):
            with open(path) as f:
                data = json_load(f)
                results.append(data)
    return results

def count_items(items: list) -> dict:
    return dict(Counter(items))
```

**Avoid `from module import *`:**

```python
# Incorrect: pollutes namespace, unclear dependencies
from os.path import *
from utils import *

# What does this use? Who knows!
result = join(dirname(path), basename(other))
```

```python
# Correct: explicit dependencies
from os.path import join, dirname, basename

result = join(dirname(path), basename(other))
```

**Aliasing for clarity:**

```python
# When names might conflict or are unclear
from datetime import datetime as dt
from typing import List as ListType  # Avoid shadowing builtins

# Common conventions
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```

**Exception: when module namespace is needed:**

```python
# Sometimes the module prefix adds clarity
import json
import logging

# json.dumps and json.loads are clearer than dumps/loads alone
data = json.dumps(obj)
obj = json.loads(data)

# logging.info vs just info
logging.info("Message")
```
