---
title: Use bisect for Sorted List Operations
impact: MEDIUM
impactDescription: O(log n) vs O(n) insertion point
tags: data-structures, bisect, sorted, binary-search
---

## Use bisect for Sorted List Operations

The `bisect` module provides efficient binary search for sorted lists, finding insertion points in O(log n) time.

**Incorrect (O(n) linear search):**

```python
def insert_sorted(sorted_list: list[int], value: int) -> None:
    for i, item in enumerate(sorted_list):
        if value <= item:
            sorted_list.insert(i, value)
            return
    sorted_list.append(value)

def find_insertion_point(sorted_list: list[int], value: int) -> int:
    for i, item in enumerate(sorted_list):
        if value <= item:
            return i
    return len(sorted_list)
```

**Correct (O(log n) binary search):**

```python
import bisect

def insert_sorted(sorted_list: list[int], value: int) -> None:
    bisect.insort(sorted_list, value)  # O(log n) find + O(n) insert

def find_insertion_point(sorted_list: list[int], value: int) -> int:
    return bisect.bisect_left(sorted_list, value)  # O(log n)
```

**bisect functions:**

```python
import bisect

sorted_list = [1, 3, 3, 3, 5, 7]

# Find leftmost insertion point
bisect.bisect_left(sorted_list, 3)   # 1 (before existing 3s)

# Find rightmost insertion point
bisect.bisect_right(sorted_list, 3)  # 4 (after existing 3s)
bisect.bisect(sorted_list, 3)        # Same as bisect_right

# Insert maintaining sort order
bisect.insort_left(sorted_list, 4)   # [1, 3, 3, 3, 4, 5, 7]
bisect.insort_right(sorted_list, 4)  # [1, 3, 3, 3, 4, 4, 5, 7]
```

**Find value in sorted list:**

```python
import bisect

def binary_search(sorted_list: list, value) -> int | None:
    """Return index of value if found, None otherwise."""
    i = bisect.bisect_left(sorted_list, value)
    if i < len(sorted_list) and sorted_list[i] == value:
        return i
    return None

def count_occurrences(sorted_list: list, value) -> int:
    """Count occurrences of value in O(log n)."""
    left = bisect.bisect_left(sorted_list, value)
    right = bisect.bisect_right(sorted_list, value)
    return right - left
```

**Grade lookup example:**

```python
import bisect

def grade(score: int) -> str:
    breakpoints = [60, 70, 80, 90]
    grades = ['F', 'D', 'C', 'B', 'A']
    return grades[bisect.bisect(breakpoints, score)]

grade(55)   # 'F'
grade(85)   # 'B'
grade(100)  # 'A'
```

**Custom key (Python 3.10+):**

```python
import bisect
from operator import attrgetter

@dataclass
class Event:
    timestamp: float
    name: str

events = [Event(1.0, 'a'), Event(3.0, 'b'), Event(5.0, 'c')]

# Find insertion point by timestamp
idx = bisect.bisect_left(events, 2.0, key=attrgetter('timestamp'))
```
