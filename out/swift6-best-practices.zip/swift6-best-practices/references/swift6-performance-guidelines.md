# Swift 6 Best Practices

**Version 0.1.0**
January 2026

> **Note:**
> This document is designed for AI agents and LLMs to follow when maintaining,
> generating, or refactoring Swift 6 codebases. Humans may also find it useful,
> but guidance here is optimized for automation and consistency.

---

## Abstract

Comprehensive performance optimization guide for Swift 6 applications, designed for AI agents and LLMs. Contains 45+ rules across 8 categories, prioritized by impact from critical (concurrency, memory management) to incremental (low-level optimization). Each rule includes detailed explanations, real-world examples comparing incorrect vs. correct implementations, and specific impact metrics to guide automated refactoring and code generation.

---

## Table of Contents

1. [Concurrency & Actors](#1-concurrency--actors) — **CRITICAL**
   - 1.1 [Minimize @MainActor Usage](#11-minimize-mainactor-usage)
   - 1.2 [Explicit Sendable Conformance](#12-explicit-sendable-conformance)
   - 1.3 [Use TaskGroup for Parallel Work](#13-use-taskgroup-for-parallel-work)
   - 1.4 [Handle Actor Reentrancy](#14-handle-actor-reentrancy)
   - 1.5 [Bridge Callbacks with AsyncStream](#15-bridge-callbacks-with-asyncstream)
   - 1.6 [Use nonisolated for Pure Functions](#16-use-nonisolated-for-pure-functions)
2. [Memory Management](#2-memory-management) — **CRITICAL**
   - 2.1 [Use [weak self] in Escaping Closures](#21-use-weak-self-in-escaping-closures)
   - 2.2 [Use autoreleasepool in Tight Loops](#22-use-autoreleasepool-in-tight-loops)
   - 2.3 [Prefer Value Types to Reduce Allocations](#23-prefer-value-types-to-reduce-allocations)
   - 2.4 [Implement Copy-on-Write for Large Values](#24-implement-copy-on-write-for-large-values)
   - 2.5 [Use unowned When Lifetime is Guaranteed](#25-use-unowned-when-lifetime-is-guaranteed)
3. [Collection Performance](#3-collection-performance) — **HIGH**
   - 3.1 [Use ContiguousArray for Non-Bridged Types](#31-use-contiguousarray-for-non-bridged-types)
   - 3.2 [Reserve Capacity Before Bulk Insertions](#32-reserve-capacity-before-bulk-insertions)
   - 3.3 [Use Lazy Sequences to Defer Computation](#33-use-lazy-sequences-to-defer-computation)
   - 3.4 [Use Dictionary Initializers Over Loops](#34-use-dictionary-initializers-over-loops)
   - 3.5 [Use Slices to Avoid Copies](#35-use-slices-to-avoid-copies)
4. [Compile Time & Binary Size](#4-compile-time--binary-size) — **HIGH**
   - 4.1 [Use @inlinable for Hot-Path Functions](#41-use-inlinable-for-hot-path-functions)
   - 4.2 [Control Generic Specialization](#42-control-generic-specialization)
   - 4.3 [Use final for Non-Inherited Classes](#43-use-final-for-non-inherited-classes)
5. [String Performance](#5-string-performance) — **MEDIUM-HIGH**
   - 5.1 [Use UTF-8 View for Byte Operations](#51-use-utf-8-view-for-byte-operations)
   - 5.2 [Manage Substring Lifetime](#52-manage-substring-lifetime)
   - 5.3 [Optimize String Interpolation](#53-optimize-string-interpolation)
6. [Protocol & Generics](#6-protocol--generics) — **MEDIUM**
   - 6.1 [Prefer Generics Over Existentials in Hot Paths](#61-prefer-generics-over-existentials-in-hot-paths)
   - 6.2 [Use Constrained Protocol Extensions](#62-use-constrained-protocol-extensions)
7. [Value Semantics](#7-value-semantics) — **MEDIUM**
   - 7.1 [Use inout for Large Struct Mutations](#71-use-inout-for-large-struct-mutations)
   - 7.2 [Optimize Struct Memory Layout](#72-optimize-struct-memory-layout)
8. [Low-Level Optimization](#8-low-level-optimization) — **LOW-MEDIUM**
   - 8.1 [Use Unsafe Buffer Pointers for Bulk Operations](#81-use-unsafe-buffer-pointers-for-bulk-operations)
   - 8.2 [Use SIMD Types for Parallel Operations](#82-use-simd-types-for-parallel-operations)

---

## 1. Concurrency & Actors

**Impact: CRITICAL**

Swift 6 introduces strict concurrency checking by default. Proper use of actors, Sendable conformance, and structured concurrency eliminates data races at compile time.

### 1.1 Minimize @MainActor Usage

Only apply `@MainActor` to code that directly updates the UI.

**Incorrect:**

```swift
@MainActor
class DataProcessor {
    var results: [Result] = []

    func processData(_ data: [Data]) async {
        for item in data {
            let result = await heavyComputation(item)  // Blocks main thread!
            results.append(result)
        }
        updateUI()
    }
}
```

**Correct:**

```swift
class DataProcessor {
    @MainActor var results: [Result] = []

    func processData(_ data: [Data]) async {
        var localResults: [Result] = []
        for item in data {
            let result = await heavyComputation(item)  // Off main thread
            localResults.append(result)
        }
        await MainActor.run {
            results = localResults
            updateUI()
        }
    }

    nonisolated func heavyComputation(_ data: Data) async -> Result {
        // CPU-intensive work on background
    }
}
```

### 1.2 Explicit Sendable Conformance

Mark value types as `Sendable` explicitly when crossing actor boundaries.

**Incorrect:**

```swift
struct UserData {
    let id: UUID
    var preferences: [String: Any]  // NOT Sendable!
}
```

**Correct:**

```swift
struct UserData: Sendable {
    let id: UUID
    let preferences: [String: String]  // Sendable types
}
```

### 1.3 Use TaskGroup for Parallel Work

Use structured concurrency instead of spawning unstructured tasks.

**Incorrect:**

```swift
func fetchAllUsers(ids: [String]) async throws -> [User] {
    var tasks: [Task<User, Error>] = []
    for id in ids {
        tasks.append(Task { try await fetchUser(id: id) })
    }
    return try await tasks.map { try await $0.value }
}
```

**Correct:**

```swift
func fetchAllUsers(ids: [String]) async throws -> [User] {
    try await withThrowingTaskGroup(of: User.self) { group in
        for id in ids {
            group.addTask { try await fetchUser(id: id) }
        }
        return try await group.reduce(into: []) { $0.append($1) }
    }
}
```

### 1.4 Handle Actor Reentrancy

Actors can be reentered at any `await` point. Re-validate state after suspension.

**Incorrect:**

```swift
actor BankAccount {
    var balance: Decimal = 1000

    func withdraw(_ amount: Decimal) async throws {
        guard balance >= amount else { throw BankError.insufficientFunds }
        await recordTransaction(amount)
        balance -= amount  // May go negative if reentered!
    }
}
```

**Correct:**

```swift
actor BankAccount {
    var balance: Decimal = 1000

    func withdraw(_ amount: Decimal) async throws {
        guard balance >= amount else { throw BankError.insufficientFunds }
        await recordTransaction(amount)
        guard balance >= amount else { throw BankError.insufficientFunds }
        balance -= amount
    }
}
```

### 1.5 Bridge Callbacks with AsyncStream

Use `AsyncStream` to bridge callback-based APIs.

**Correct:**

```swift
var locations: AsyncStream<CLLocation> {
    AsyncStream { continuation in
        self.continuation = continuation
        continuation.onTermination = { _ in
            self.locationManager.stopUpdatingLocation()
        }
        locationManager.startUpdatingLocation()
    }
}
```

### 1.6 Use nonisolated for Pure Functions

Mark functions that don't access mutable actor state as `nonisolated`.

**Correct:**

```swift
actor DataFormatter {
    var locale: Locale = .current

    nonisolated func formatCurrency(_ value: Double, locale: Locale) -> String {
        // Pure function, no actor hop needed
        NumberFormatter.localizedString(from: NSNumber(value: value), number: .currency)
    }
}
```

---

## 2. Memory Management

**Impact: CRITICAL**

Understanding ARC, retain cycles, and allocation patterns is essential for Swift performance.

### 2.1 Use [weak self] in Escaping Closures

Prevent retain cycles in closures that may outlive `self`.

**Correct:**

```swift
urlSession.dataTask(with: url) { [weak self] data, _, _ in
    guard let self else { return }
    self.processData(data)
}.resume()
```

### 2.2 Use autoreleasepool in Tight Loops

Release Foundation objects promptly in loops.

**Correct:**

```swift
for url in urls {
    autoreleasepool {
        let data = try? Data(contentsOf: url)
        if let image = data.flatMap({ UIImage(data: $0) }) {
            images.append(applyFilters(image))
        }
    }
}
```

### 2.3 Prefer Value Types to Reduce Allocations

Use structs instead of classes when reference semantics aren't needed.

**Correct:**

```swift
struct Point {
    var x, y: Double
}
// Stack allocated, no ARC overhead
```

### 2.4 Implement Copy-on-Write for Large Values

Defer copying until mutation for large value types.

**Correct:**

```swift
struct ImageBuffer {
    private var storage: ImageStorage

    mutating func setPixel(at index: Int, value: UInt8) {
        if !isKnownUniquelyReferenced(&storage) {
            storage = ImageStorage(pixels: storage.pixels)
        }
        storage.pixels[index] = value
    }
}
```

### 2.5 Use unowned When Lifetime is Guaranteed

Avoid weak reference overhead when lifetime is certain.

**Correct:**

```swift
class Child {
    unowned let parent: Parent  // Parent always outlives Child
}
```

---

## 3. Collection Performance

**Impact: HIGH**

Choosing the right collection type and access patterns yields significant improvements.

### 3.1 Use ContiguousArray for Non-Bridged Types

Eliminate bridging overhead for value types.

**Correct:**

```swift
let points: ContiguousArray<Point> = []
// No NSArray bridging check on access
```

### 3.2 Reserve Capacity Before Bulk Insertions

Avoid multiple reallocations.

**Correct:**

```swift
var results: [Result] = []
results.reserveCapacity(items.count)
for item in items {
    results.append(process(item))
}
```

### 3.3 Use Lazy Sequences to Defer Computation

Avoid intermediate allocations and enable early termination.

**Correct:**

```swift
let result = numbers.lazy
    .map { $0 * 2 }
    .filter { $0 > 1000 }
    .first
```

### 3.4 Use Dictionary Initializers Over Loops

**Correct:**

```swift
let index = Dictionary(uniqueKeysWithValues: users.map { ($0.id, $0) })
let groups = Dictionary(grouping: employees, by: \.department)
```

### 3.5 Use Slices to Avoid Copies

Share storage with the original collection.

**Correct:**

```swift
let firstHalf = array[0..<array.count/2]  // ArraySlice, no copy
```

---

## 4. Compile Time & Binary Size

**Impact: HIGH**

Control compilation behavior for optimal build times and runtime performance.

### 4.1 Use @inlinable for Hot-Path Functions

Enable cross-module inlining.

**Correct:**

```swift
@inlinable
public func dot(_ other: Vector3) -> Double {
    x * other.x + y * other.y + z * other.z
}
```

### 4.2 Control Generic Specialization

Balance compile time vs runtime performance.

**Correct:**

```swift
@_specialize(where T == Int)
@_specialize(where T == Double)
public func process<T: Numeric>(_ values: [T]) -> T {
    values.reduce(0, +)
}
```

### 4.3 Use final for Non-Inherited Classes

Enable devirtualization.

**Correct:**

```swift
final class NetworkClient {
    func fetch(url: URL) async throws -> Data { }
}
```

---

## 5. String Performance

**Impact: MEDIUM-HIGH**

Swift strings are Unicode-correct but require understanding for optimal performance.

### 5.1 Use UTF-8 View for Byte Operations

**Correct:**

```swift
func isASCII(_ string: String) -> Bool {
    for byte in string.utf8 {
        if byte > 127 { return false }
    }
    return true
}
```

### 5.2 Manage Substring Lifetime

Convert to String when storing long-term.

**Correct:**

```swift
var errorMessages: [String] = []  // Not [Substring]
for line in logFile.split(separator: "\n") {
    if line.hasPrefix("ERROR") {
        errorMessages.append(String(line))
    }
}
```

### 5.3 Optimize String Interpolation

Use append operations in hot paths.

**Correct:**

```swift
var result = ""
result.reserveCapacity(100)
result.append(timestamp.description)
result.append(" [")
result.append(level)
result.append("]")
```

---

## 6. Protocol & Generics

**Impact: MEDIUM**

Choose between existentials and generics based on performance requirements.

### 6.1 Prefer Generics Over Existentials in Hot Paths

**Correct:**

```swift
func totalArea<S: Shape>(_ shapes: [S]) -> Double {
    shapes.reduce(0) { $0 + $1.area() }  // Static dispatch
}
```

### 6.2 Use Constrained Protocol Extensions

Provide optimized implementations for specific types.

**Correct:**

```swift
extension Array where Element: BinaryInteger {
    func sum() -> Element {
        // Optimized for integers
    }
}
```

---

## 7. Value Semantics

**Impact: MEDIUM**

Proper use of value types enables safe concurrent code and predictable performance.

### 7.1 Use inout for Large Struct Mutations

**Correct:**

```swift
mutating func makeMove(_ move: Move) {
    board[move.row][move.col] = move.tile
    history.append(move)  // In-place modification
}
```

### 7.2 Optimize Struct Memory Layout

Order properties to minimize padding.

**Correct:**

```swift
struct WellAligned {
    var int64: Int64     // 8 bytes
    var int32: Int32     // 4 bytes
    var bool1: Bool      // 1 byte
    var bool2: Bool      // 1 byte + 2 padding
}
// 16 bytes total
```

---

## 8. Low-Level Optimization

**Impact: LOW-MEDIUM**

For performance-critical code when profiling indicates necessity.

### 8.1 Use Unsafe Buffer Pointers for Bulk Operations

**Correct:**

```swift
array.withUnsafeBufferPointer { buffer in
    for i in 0..<buffer.count {
        sum += buffer[i]  // No bounds checking
    }
}
```

### 8.2 Use SIMD Types for Parallel Operations

**Correct:**

```swift
let a: SIMD4<Float> = [1, 2, 3, 4]
let b: SIMD4<Float> = [5, 6, 7, 8]
let sum = a + b  // Single instruction for 4 additions
```

---

## References

1. [Swift Documentation](https://docs.swift.org/swift-book/)
2. [Swift Evolution Proposals](https://github.com/apple/swift-evolution)
3. [Swift Performance Tips](https://github.com/apple/swift/blob/main/docs/OptimizationTips.rst)
4. [WWDC Sessions on Swift Concurrency](https://developer.apple.com/videos/)
5. [Swift Forums - Using Swift](https://forums.swift.org/c/swift-users/)
