---
title: Use unowned When Lifetime is Guaranteed
impact: MEDIUM
impactDescription: avoids optional unwrapping overhead
tags: memory, swift6, unowned, weak, lifetime, ARC
---

## Use unowned When Lifetime is Guaranteed

Use `unowned` instead of `weak` when you can guarantee the referenced object will outlive the reference. This avoids the overhead of optional unwrapping and weak reference bookkeeping.

**Incorrect (unnecessary weak when lifetime is guaranteed):**

```swift
class Parent {
    var children: [Child] = []

    func addChild() {
        let child = Child(parent: self)
        children.append(child)
    }
}

class Child {
    weak var parent: Parent?  // Unnecessary optional

    init(parent: Parent) {
        self.parent = parent
    }

    func notifyParent() {
        parent?.didUpdate(self)  // Forced to unwrap every time
    }
}
```

**Correct (unowned for guaranteed lifetime):**

```swift
class Parent {
    var children: [Child] = []

    func addChild() {
        let child = Child(parent: self)
        children.append(child)
    }

    deinit {
        // Children are deallocated with Parent
        // so unowned reference is always valid
    }
}

class Child {
    unowned let parent: Parent  // Non-optional, always valid

    init(parent: Parent) {
        self.parent = parent
    }

    func notifyParent() {
        parent.didUpdate(self)  // No unwrapping needed
    }
}
```

**Common safe patterns for unowned:**

```swift
// 1. Delegate pattern where delegate owns the delegator
class TableView {
    unowned let dataSource: TableViewDataSource

    init(dataSource: TableViewDataSource) {
        self.dataSource = dataSource
    }
}

// 2. Closures in the same scope
class ViewModel {
    var items: [Item] = []

    func loadItems() {
        // Closure executes synchronously, self guaranteed to exist
        fetchItems { [unowned self] newItems in
            self.items = newItems
        }
    }
}

// 3. Nested types
class OuterClass {
    class InnerClass {
        unowned let outer: OuterClass

        init(outer: OuterClass) {
            self.outer = outer
        }
    }
}
```

**When NOT to use unowned:**

```swift
// DON'T use unowned in escaping closures that may outlive self
class BadExample {
    func startAsyncWork() {
        // WRONG: self may be deallocated before completion
        someAsyncAPI { [unowned self] in  // CRASH if self deallocated
            self.handleResult()
        }
    }
}

// Use weak instead
class GoodExample {
    func startAsyncWork() {
        someAsyncAPI { [weak self] in
            self?.handleResult()  // Safe
        }
    }
}
```

**Performance comparison:**

```swift
// weak: ~2-3x slower due to side table lookup and optional
// unowned: same speed as strong reference

// In tight loops, this matters:
for _ in 0..<1_000_000 {
    child.parent.doSomething()  // unowned: fast
    child.parent?.doSomething() // weak: slower + branch
}
```

Reference: [Unowned References](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/automaticreferencecounting/#Unowned-References)
