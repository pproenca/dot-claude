---
title: Bridge Callbacks with AsyncStream
impact: HIGH
impactDescription: clean integration with legacy APIs
tags: async, swift6, AsyncStream, callbacks, bridging
---

## Bridge Callbacks with AsyncStream

Use `AsyncStream` to bridge callback-based APIs to async/await. This provides proper backpressure, cancellation support, and clean integration with structured concurrency.

**Incorrect (callback hell, no cancellation):**

```swift
class LocationTracker {
    var locationCallback: ((CLLocation) -> Void)?

    func startTracking() {
        locationManager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        locations.forEach { locationCallback?($0) }
    }
}

// Usage - callback-based
let tracker = LocationTracker()
tracker.locationCallback = { location in
    print(location)
}
tracker.startTracking()
// No easy way to stop, no async/await integration
```

**Correct (AsyncStream with cancellation):**

```swift
class LocationTracker {
    private var continuation: AsyncStream<CLLocation>.Continuation?

    var locations: AsyncStream<CLLocation> {
        AsyncStream { continuation in
            self.continuation = continuation

            continuation.onTermination = { @Sendable _ in
                self.locationManager.stopUpdatingLocation()
            }

            locationManager.startUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        for location in locations {
            continuation?.yield(location)
        }
    }

    func stopTracking() {
        continuation?.finish()
    }
}

// Usage - clean async/await
let tracker = LocationTracker()
for await location in tracker.locations {
    print(location)
    if shouldStop {
        break  // Automatically calls onTermination
    }
}
```

**For single-value callbacks, use CheckedContinuation:**

```swift
func fetchData() async throws -> Data {
    try await withCheckedThrowingContinuation { continuation in
        legacyFetch { result in
            switch result {
            case .success(let data):
                continuation.resume(returning: data)
            case .failure(let error):
                continuation.resume(throwing: error)
            }
        }
    }
}
```

**For buffered streams with backpressure:**

```swift
let (stream, continuation) = AsyncStream.makeStream(
    of: Event.self,
    bufferingPolicy: .bufferingNewest(10)  // Keep only latest 10
)

// Producer
Task {
    for event in eventSource {
        let result = continuation.yield(event)
        if case .terminated = result {
            break  // Consumer cancelled
        }
    }
    continuation.finish()
}

// Consumer
for await event in stream {
    await process(event)
}
```

Reference: [AsyncStream Documentation](https://developer.apple.com/documentation/swift/asyncstream)
