---
title: Use nonisolated for Pure Functions
impact: HIGH
impactDescription: eliminates unnecessary actor hops
tags: async, swift6, nonisolated, actors, pure-functions
---

## Use nonisolated for Pure Functions

Mark functions that don't access mutable actor state as `nonisolated`. This eliminates actor hops for callers and allows synchronous access to pure computations.

**Incorrect (unnecessary actor isolation):**

```swift
actor DataFormatter {
    var locale: Locale = .current

    // These don't need actor isolation but force callers to await
    func formatCurrency(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = locale
        return formatter.string(from: NSNumber(value: value)) ?? ""
    }

    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.locale = locale
        return formatter.string(from: date)
    }
}

// Caller must await even for simple formatting
let formatter = DataFormatter()
let price = await formatter.formatCurrency(99.99)  // Unnecessary hop
```

**Correct (nonisolated for pure computations):**

```swift
actor DataFormatter {
    var locale: Locale = .current

    // Pure functions don't need isolation
    nonisolated func formatCurrency(_ value: Double, locale: Locale) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = locale
        return formatter.string(from: NSNumber(value: value)) ?? ""
    }

    nonisolated func formatDate(_ date: Date, locale: Locale) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.locale = locale
        return formatter.string(from: date)
    }

    // Method that uses actor state
    func formatCurrentCurrency(_ value: Double) async -> String {
        formatCurrency(value, locale: locale)
    }
}

// Callers can use without await
let formatter = DataFormatter()
let price = formatter.formatCurrency(99.99, locale: .current)  // Synchronous!
```

**Use nonisolated(unsafe) only for immutable external state:**

```swift
actor Configuration {
    // These are set once at startup and never mutate
    nonisolated(unsafe) let apiEndpoint: URL
    nonisolated(unsafe) let apiKey: String

    init(endpoint: URL, key: String) {
        self.apiEndpoint = endpoint
        self.apiKey = key
    }

    nonisolated var baseURL: URL {
        apiEndpoint  // Safe because it's immutable
    }
}
```

**Computed properties can be nonisolated:**

```swift
actor User {
    let id: UUID
    let firstName: String
    let lastName: String
    var email: String  // Mutable, needs isolation

    // Pure computation from immutable state
    nonisolated var fullName: String {
        "\(firstName) \(lastName)"
    }

    // This needs isolation because it accesses mutable state
    var displayName: String {
        "\(fullName) <\(email)>"
    }
}

let user = User(id: UUID(), firstName: "John", lastName: "Doe", email: "john@example.com")
print(user.fullName)  // Synchronous, no await needed
print(await user.displayName)  // Requires await
```

Reference: [SE-0313 Improved control over actor isolation](https://github.com/apple/swift-evolution/blob/main/proposals/0313-actor-isolation-control.md)
