---
title: Prefer Generics Over Existentials in Hot Paths
impact: MEDIUM
impactDescription: avoids existential container overhead
tags: protocols, swift6, generics, existentials, any, performance
---

## Prefer Generics Over Existentials in Hot Paths

Existential types (`any Protocol`) use dynamic dispatch and boxing. In performance-critical code, use concrete generics (`some Protocol` or `<T: Protocol>`) to enable static dispatch and inline optimization.

**Incorrect (existential overhead):**

```swift
protocol Shape {
    func area() -> Double
}

struct Circle: Shape {
    var radius: Double
    func area() -> Double { .pi * radius * radius }
}

struct Rectangle: Shape {
    var width, height: Double
    func area() -> Double { width * height }
}

// Existential array - each element boxed, dynamic dispatch
func totalArea(_ shapes: [any Shape]) -> Double {
    var total = 0.0
    for shape in shapes {
        // Dynamic dispatch through existential container
        total += shape.area()
    }
    return total
}
```

Each element in `[any Shape]` is a 40-byte existential container with indirect storage for large types.

**Correct (generic specialization):**

```swift
// Generic function - specialized at compile time
func totalArea<S: Shape>(_ shapes: [S]) -> Double {
    var total = 0.0
    for shape in shapes {
        // Static dispatch, can be inlined
        total += shape.area()
    }
    return total
}

// Usage
let circles: [Circle] = [Circle(radius: 1), Circle(radius: 2)]
let total = totalArea(circles)  // Specialized for Circle
```

**Use `some` for opaque return types:**

```swift
// Returns concrete type, no existential boxing
func makeShape() -> some Shape {
    Circle(radius: 5)
}

// Caller gets optimized access
let shape = makeShape()
let area = shape.area()  // Static dispatch
```

**When existentials are acceptable:**

```swift
// Heterogeneous collections require existentials
var mixedShapes: [any Shape] = [
    Circle(radius: 1),
    Rectangle(width: 2, height: 3)
]

// Infrequent calls - overhead negligible
func describeShape(_ shape: any Shape) -> String {
    "Area: \(shape.area())"
}

// Protocol with Self or associated type requirements
// Now allowed in Swift 5.7+ with 'any'
protocol Container {
    associatedtype Element
    var elements: [Element] { get }
}

var containers: [any Container] = []
```

**Swift 6 primary associated types:**

```swift
// Use primary associated types for cleaner existentials
protocol Collection<Element> {
    associatedtype Element
    // ...
}

// Constrained existential
var intCollections: [any Collection<Int>] = []
```

**Benchmark comparison:**

```swift
// 1 million iterations:
// Existential dispatch: ~45ms
// Generic specialization: ~12ms
// ~4× improvement

// Memory per element:
// Existential: 40 bytes (container)
// Concrete: 8-16 bytes (actual size)
```

Reference: [Existential Types in Swift](https://developer.apple.com/documentation/swift/existentialtype)
