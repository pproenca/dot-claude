---
title: Use TaskGroup for Parallel Work
impact: CRITICAL
impactDescription: 2-10× improvement for parallel operations
tags: async, swift6, TaskGroup, parallel, structured-concurrency
---

## Use TaskGroup for Parallel Work

For parallel operations, use `TaskGroup` instead of spawning multiple unstructured `Task {}` instances. TaskGroup provides automatic cancellation propagation, bounded concurrency, and proper error handling.

**Incorrect (unstructured tasks, no cancellation):**

```swift
func fetchAllUsers(ids: [String]) async throws -> [User] {
    var users: [User] = []
    var tasks: [Task<User, Error>] = []

    // Creates unbounded tasks, no cancellation propagation
    for id in ids {
        let task = Task {
            try await fetchUser(id: id)
        }
        tasks.append(task)
    }

    // Manual collection, leaks tasks on error
    for task in tasks {
        let user = try await task.value
        users.append(user)
    }

    return users
}
```

**Correct (structured concurrency with TaskGroup):**

```swift
func fetchAllUsers(ids: [String]) async throws -> [User] {
    try await withThrowingTaskGroup(of: User.self) { group in
        for id in ids {
            group.addTask {
                try await fetchUser(id: id)
            }
        }

        var users: [User] = []
        users.reserveCapacity(ids.count)

        for try await user in group {
            users.append(user)
        }

        return users
    }
}
```

**For ordered results, use indexed tuples:**

```swift
func fetchAllUsersOrdered(ids: [String]) async throws -> [User] {
    try await withThrowingTaskGroup(of: (Int, User).self) { group in
        for (index, id) in ids.enumerated() {
            group.addTask {
                let user = try await fetchUser(id: id)
                return (index, user)
            }
        }

        var results = [(Int, User)]()
        results.reserveCapacity(ids.count)

        for try await result in group {
            results.append(result)
        }

        return results.sorted { $0.0 < $1.0 }.map(\.1)
    }
}
```

**For bounded concurrency:**

```swift
func fetchWithLimit(ids: [String], maxConcurrent: Int) async throws -> [User] {
    try await withThrowingTaskGroup(of: User.self) { group in
        var iterator = ids.makeIterator()
        var users: [User] = []

        // Start initial batch
        for _ in 0..<min(maxConcurrent, ids.count) {
            if let id = iterator.next() {
                group.addTask { try await fetchUser(id: id) }
            }
        }

        // As each completes, start next
        for try await user in group {
            users.append(user)
            if let id = iterator.next() {
                group.addTask { try await fetchUser(id: id) }
            }
        }

        return users
    }
}
```

Reference: [Swift TaskGroup Documentation](https://developer.apple.com/documentation/swift/taskgroup)
