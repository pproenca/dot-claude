---
title: Use Dictionary Initializers Over Loops
impact: MEDIUM-HIGH
impactDescription: cleaner code with optimized internals
tags: collections, swift6, Dictionary, initialization, performance
---

## Use Dictionary Initializers Over Loops

Use `Dictionary(uniqueKeysWithValues:)` and `Dictionary(grouping:by:)` instead of manual loops. These initializers are optimized and express intent clearly.

**Incorrect (manual loop):**

```swift
func buildUserIndex(_ users: [User]) -> [String: User] {
    var index: [String: User] = [:]

    for user in users {
        index[user.id] = user  // Potential hash collisions, rehashing
    }

    return index
}

func groupByDepartment(_ employees: [Employee]) -> [String: [Employee]] {
    var groups: [String: [Employee]] = [:]

    for employee in employees {
        if groups[employee.department] == nil {
            groups[employee.department] = []
        }
        groups[employee.department]?.append(employee)
    }

    return groups
}
```

**Correct (optimized initializers):**

```swift
func buildUserIndex(_ users: [User]) -> [String: User] {
    Dictionary(uniqueKeysWithValues: users.map { ($0.id, $0) })
}

func groupByDepartment(_ employees: [Employee]) -> [String: [Employee]] {
    Dictionary(grouping: employees, by: \.department)
}
```

**Handle duplicate keys:**

```swift
// When keys might not be unique, use the merging variant
let wordCounts = Dictionary(
    words.map { ($0, 1) },
    uniquingKeysWith: +  // Sum counts for duplicates
)

// Or keep first/last occurrence
let firstOccurrence = Dictionary(
    items.map { ($0.id, $0) },
    uniquingKeysWith: { first, _ in first }
)

let lastOccurrence = Dictionary(
    items.map { ($0.id, $0) },
    uniquingKeysWith: { _, last in last }
)
```

**Transform values efficiently:**

```swift
// mapValues is more efficient than rebuilding
let userNames = userIndex.mapValues { $0.name }

// compactMapValues to filter and transform
let activeUserNames = userIndex.compactMapValues { user in
    user.isActive ? user.name : nil
}
```

**Merge dictionaries:**

```swift
// Merge with conflict resolution
let merged = dict1.merging(dict2) { current, new in
    new  // Prefer values from dict2
}

// In-place merging
var config = defaultConfig
config.merge(userConfig) { _, user in user }
```

**Filter efficiently:**

```swift
// filter returns a new Dictionary (not an Array)
let activeUsers = userIndex.filter { $0.value.isActive }

// More efficient than:
// Dictionary(uniqueKeysWithValues: userIndex.filter { $0.value.isActive })
```

**KeyPath-based grouping:**

```swift
struct Sale {
    let product: String
    let region: String
    let amount: Double
}

// Group by multiple criteria
let byRegion = Dictionary(grouping: sales, by: \.region)
let byProduct = Dictionary(grouping: sales, by: \.product)

// Nested grouping
let byRegionThenProduct = byRegion.mapValues { regionSales in
    Dictionary(grouping: regionSales, by: \.product)
}
```

Reference: [Dictionary Initializers](https://developer.apple.com/documentation/swift/dictionary)
