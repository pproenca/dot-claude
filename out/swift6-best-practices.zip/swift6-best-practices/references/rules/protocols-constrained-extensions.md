---
title: Use Constrained Protocol Extensions
impact: MEDIUM
impactDescription: reduces code duplication while maintaining type safety
tags: protocols, swift6, extensions, constraints, generics
---

## Use Constrained Protocol Extensions

Add default implementations to protocols using constrained extensions. This provides optimized implementations for specific type categories while maintaining a generic fallback.

**Incorrect (no specialized implementations):**

```swift
protocol Summable {
    static func + (lhs: Self, rhs: Self) -> Self
    static var zero: Self { get }
}

extension Array where Element: Summable {
    func sum() -> Element {
        // Generic implementation for all Summable types
        reduce(Element.zero, +)
    }
}

// Every type uses the same implementation
// No optimization for common cases like Int, Double
```

**Correct (constrained specializations):**

```swift
protocol Summable {
    static func + (lhs: Self, rhs: Self) -> Self
    static var zero: Self { get }
}

// Generic fallback
extension Array where Element: Summable {
    func sum() -> Element {
        reduce(Element.zero, +)
    }
}

// Optimized for numeric types using SIMD
extension Array where Element: BinaryInteger {
    func sum() -> Element {
        // Can use accelerated integer operations
        var total = Element.zero
        for element in self {
            total &+= element  // Overflow-safe addition
        }
        return total
    }
}

extension Array where Element: BinaryFloatingPoint {
    func sum() -> Element {
        // Can use vectorized floating-point operations
        withUnsafeBufferPointer { buffer in
            // Potential for SIMD optimization
            buffer.reduce(Element.zero, +)
        }
    }
}
```

**Layer constraints for progressive specialization:**

```swift
protocol Drawable {
    func draw(in context: GraphicsContext)
}

// Base implementation
extension Drawable {
    func draw(in context: GraphicsContext) {
        // Generic drawing
    }
}

// Specialized for shapes with bounds
extension Drawable where Self: BoundedShape {
    func draw(in context: GraphicsContext) {
        context.clip(to: bounds)
        // Optimized bounded drawing
    }
}

// Even more specialized for rectangles
extension Drawable where Self == Rectangle {
    func draw(in context: GraphicsContext) {
        // Fast path for rectangles
        context.fill(CGRect(origin: origin, size: size))
    }
}
```

**Constrain with multiple protocols:**

```swift
extension Collection where Element: Comparable, Element: Hashable {
    func uniqueSorted() -> [Element] {
        Array(Set(self)).sorted()
    }
}

extension Collection where Element: Equatable, Self: RandomAccessCollection {
    func fastContains(_ element: Element) -> Bool {
        // Can use random access for optimization
        for i in indices {
            if self[i] == element { return true }
        }
        return false
    }
}
```

**Use same-type constraints:**

```swift
extension Sequence where Element == String {
    func joinedWithCommas() -> String {
        joined(separator: ", ")
    }
}

extension Dictionary where Key == String, Value == Any {
    func jsonString() -> String? {
        // Specialized for JSON-like dictionaries
        try? JSONSerialization.data(withJSONObject: self)
            .flatMap { String(data: $0, encoding: .utf8) }
    }
}
```

**Compiler selects most specific:**

```swift
let ints = [1, 2, 3, 4, 5]
ints.sum()  // Uses BinaryInteger specialization

let doubles = [1.0, 2.0, 3.0]
doubles.sum()  // Uses BinaryFloatingPoint specialization

struct CustomNumber: Summable { /* ... */ }
let customs = [CustomNumber(), CustomNumber()]
customs.sum()  // Uses generic Summable fallback
```

Reference: [Protocol Extensions](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/#Protocol-Extensions)
