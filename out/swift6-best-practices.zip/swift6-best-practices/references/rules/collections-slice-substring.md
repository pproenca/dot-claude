---
title: Use Slices to Avoid Copies
impact: MEDIUM
impactDescription: O(1) slicing instead of O(n) copying
tags: collections, swift6, Slice, ArraySlice, Substring, performance
---

## Use Slices to Avoid Copies

Use `ArraySlice` and `Substring` for temporary views into collections. Slices share storage with the original, avoiding copies until mutation.

**Incorrect (copies data):**

```swift
func processFirstHalf(_ data: [Int]) -> Int {
    let halfCount = data.count / 2
    let firstHalf = Array(data[0..<halfCount])  // Copies half the array!

    return firstHalf.reduce(0, +)
}

func parseHeader(_ content: String) -> String {
    let headerEnd = content.firstIndex(of: "\n") ?? content.endIndex
    let header = String(content[..<headerEnd])  // Copies the substring!

    return header.uppercased()
}
```

**Correct (uses slices):**

```swift
func processFirstHalf(_ data: [Int]) -> Int {
    let halfCount = data.count / 2
    let firstHalf = data[0..<halfCount]  // ArraySlice, no copy

    return firstHalf.reduce(0, +)  // Works directly on slice
}

func parseHeader(_ content: String) -> Substring {
    let headerEnd = content.firstIndex(of: "\n") ?? content.endIndex
    let header = content[..<headerEnd]  // Substring, no copy

    return header  // Return Substring if caller doesn't need String
}
```

**Convert to owned type when needed:**

```swift
func getWords(_ text: String) -> [String] {
    // Substrings for intermediate work
    let substrings = text.split(separator: " ")

    // Convert to String only at the end
    return substrings.map(String.init)
}

// Or keep as Substring if not stored long-term
func processWords(_ text: String) {
    for word in text.split(separator: " ") {  // Substring
        print(word)  // No String conversion needed
    }
}
```

**Careful: Slices retain the original:**

```swift
// WRONG: Small slice keeps huge array alive
class DataProcessor {
    var cachedSlice: ArraySlice<Int>?

    func process(_ hugeArray: [Int]) {
        // This slice keeps entire hugeArray in memory!
        cachedSlice = hugeArray[0..<10]
    }
}

// CORRECT: Convert to Array when storing
class DataProcessor {
    var cachedData: [Int]?

    func process(_ hugeArray: [Int]) {
        cachedData = Array(hugeArray[0..<10])  // Only 10 elements stored
    }
}
```

**Slice indices start from original:**

```swift
let array = [0, 1, 2, 3, 4, 5]
let slice = array[2..<5]  // [2, 3, 4]

// WRONG: Slice indices are NOT 0-based
// slice[0]  // Fatal error!

// CORRECT: Use original indices
slice[2]  // Returns 2
slice[3]  // Returns 3

// Or use slice.indices
for i in slice.indices {
    print(slice[i])
}

// Or iterate directly
for element in slice {
    print(element)
}
```

**Substring for parsing:**

```swift
func parseKeyValue(_ line: String) -> (key: Substring, value: Substring)? {
    guard let separatorIndex = line.firstIndex(of: "=") else {
        return nil
    }

    let key = line[..<separatorIndex]
    let value = line[line.index(after: separatorIndex)...]

    return (key.trimmingCharacters(in: .whitespaces)[...],
            value.trimmingCharacters(in: .whitespaces)[...])
}
```

Reference: [ArraySlice Documentation](https://developer.apple.com/documentation/swift/arrayslice)
