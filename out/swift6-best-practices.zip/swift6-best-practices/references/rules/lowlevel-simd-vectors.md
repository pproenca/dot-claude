---
title: Use SIMD Types for Parallel Operations
impact: LOW-MEDIUM
impactDescription: 2-8× speedup for numeric operations
tags: lowlevel, swift6, SIMD, vectors, parallel, performance
---

## Use SIMD Types for Parallel Operations

Use Swift's built-in SIMD types to perform operations on multiple values simultaneously. Modern CPUs can process 2-8 values in a single instruction.

**Incorrect (scalar operations):**

```swift
struct Vector4 {
    var x, y, z, w: Float

    static func + (lhs: Vector4, rhs: Vector4) -> Vector4 {
        Vector4(
            x: lhs.x + rhs.x,  // 4 separate additions
            y: lhs.y + rhs.y,
            z: lhs.z + rhs.z,
            w: lhs.w + rhs.w
        )
    }

    func dot(_ other: Vector4) -> Float {
        x * other.x + y * other.y + z * other.z + w * other.w
    }
}
```

**Correct (SIMD operations):**

```swift
typealias Vector4 = SIMD4<Float>

// Addition is automatic - single instruction for 4 values
let a: Vector4 = [1, 2, 3, 4]
let b: Vector4 = [5, 6, 7, 8]
let sum = a + b  // [6, 8, 10, 12] - one instruction

// Dot product with SIMD
extension SIMD4 where Scalar: FloatingPoint {
    func dot(_ other: Self) -> Scalar {
        (self * other).sum()  // Multiply + horizontal sum
    }
}
```

**Common SIMD types:**

```swift
// 2-component vectors
let v2: SIMD2<Float> = [1.0, 2.0]
let v2d: SIMD2<Double> = [1.0, 2.0]

// 3-component vectors (padded to 4 internally)
let v3: SIMD3<Float> = [1.0, 2.0, 3.0]

// 4-component vectors
let v4: SIMD4<Float> = [1.0, 2.0, 3.0, 4.0]
let v4i: SIMD4<Int32> = [1, 2, 3, 4]

// 8-component vectors (AVX)
let v8: SIMD8<Float> = [1, 2, 3, 4, 5, 6, 7, 8]

// 16-component for integers
let v16: SIMD16<Int8> = .init(repeating: 1)
```

**Matrix operations:**

```swift
import simd

// Use simd matrix types for transformations
var transform = simd_float4x4(1)  // Identity matrix

// Rotation around Y axis
let angle: Float = .pi / 4
let rotation = simd_float4x4(
    simd_float4(cos(angle), 0, sin(angle), 0),
    simd_float4(0, 1, 0, 0),
    simd_float4(-sin(angle), 0, cos(angle), 0),
    simd_float4(0, 0, 0, 1)
)

transform = rotation * transform

// Transform a point
let point = simd_float4(1, 0, 0, 1)
let transformed = transform * point
```

**Batch processing with SIMD:**

```swift
func normalizeVectors(_ vectors: inout [SIMD3<Float>]) {
    for i in vectors.indices {
        let length = simd_length(vectors[i])
        if length > 0 {
            vectors[i] /= length  // SIMD division
        }
    }
}

// Process 4 scalars at once
func processInBatches(_ values: [Float]) -> [Float] {
    var results = [Float]()
    results.reserveCapacity(values.count)

    var i = 0
    while i + 4 <= values.count {
        let batch = SIMD4<Float>(
            values[i], values[i+1], values[i+2], values[i+3]
        )
        let processed = batch * batch + 1  // x² + 1 for 4 values
        results.append(contentsOf: [processed.x, processed.y, processed.z, processed.w])
        i += 4
    }

    // Handle remainder
    while i < values.count {
        results.append(values[i] * values[i] + 1)
        i += 1
    }

    return results
}
```

**Use Accelerate for large arrays:**

```swift
import Accelerate

func vectorAdd(_ a: [Float], _ b: [Float]) -> [Float] {
    var result = [Float](repeating: 0, count: a.count)
    vDSP_vadd(a, 1, b, 1, &result, 1, vDSP_Length(a.count))
    return result
}

func dotProduct(_ a: [Float], _ b: [Float]) -> Float {
    var result: Float = 0
    vDSP_dotpr(a, 1, b, 1, &result, vDSP_Length(a.count))
    return result
}
```

Reference: [SIMD Documentation](https://developer.apple.com/documentation/swift/simd)
