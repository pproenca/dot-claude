---
title: Reserve Capacity Before Bulk Insertions
impact: HIGH
impactDescription: avoids multiple reallocations
tags: collections, swift6, reserveCapacity, Array, Dictionary, performance
---

## Reserve Capacity Before Bulk Insertions

When building a collection with a known or estimated size, call `reserveCapacity(_:)` first. This avoids multiple reallocations as the collection grows.

**Incorrect (multiple reallocations):**

```swift
func processItems(_ items: [Item]) -> [Result] {
    var results: [Result] = []

    for item in items {
        // Array reallocates multiple times as it grows:
        // capacity: 0 -> 1 -> 2 -> 4 -> 8 -> 16 -> ... -> 1024
        results.append(process(item))
    }

    return results
}

// For 1000 items: ~10 reallocations, each copying all elements
```

**Correct (single allocation):**

```swift
func processItems(_ items: [Item]) -> [Result] {
    var results: [Result] = []
    results.reserveCapacity(items.count)  // Single allocation

    for item in items {
        results.append(process(item))  // No reallocations
    }

    return results
}

// For 1000 items: 1 allocation, 0 copies
```

**Works for Dictionary and Set too:**

```swift
func buildIndex(_ items: [Item]) -> [String: Item] {
    var index: [String: Item] = [:]
    index.reserveCapacity(items.count)

    for item in items {
        index[item.id] = item
    }

    return index
}

func uniqueValues<T: Hashable>(_ items: [T]) -> Set<T> {
    var set = Set<T>()
    set.reserveCapacity(items.count)  // Upper bound

    for item in items {
        set.insert(item)
    }

    return set
}
```

**Use with initializers when possible:**

```swift
// Even better: use transforming initializers
let results = items.map { process($0) }  // Optimized internally

let index = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })

let set = Set(items)  // Reserves capacity automatically
```

**Estimate when exact count unknown:**

```swift
func parseCSV(_ content: String) -> [[String]] {
    var rows: [[String]] = []
    // Estimate ~100 bytes per row
    rows.reserveCapacity(content.utf8.count / 100)

    for line in content.split(separator: "\n") {
        var columns: [String] = []
        columns.reserveCapacity(10)  // Estimate ~10 columns
        // Parse columns...
        rows.append(columns)
    }

    return rows
}
```

**ContiguousArray benefits more:**

```swift
var points = ContiguousArray<Point>()
points.reserveCapacity(1_000_000)

// ContiguousArray + reserveCapacity = optimal performance
// Single contiguous memory block, no bridging, no reallocations
```

Reference: [Collection.reserveCapacity](https://developer.apple.com/documentation/swift/array/reservecapacity(_:))
