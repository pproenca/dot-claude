---
title: Use UTF-8 View for Byte Operations
impact: MEDIUM-HIGH
impactDescription: avoids Unicode grapheme cluster overhead
tags: strings, swift6, utf8, Unicode, performance
---

## Use UTF-8 View for Byte Operations

When working with ASCII or byte-level string operations, use `.utf8` view instead of iterating characters. Character iteration involves expensive grapheme cluster boundary detection.

**Incorrect (Character iteration overhead):**

```swift
func countBytes(_ string: String) -> Int {
    var count = 0
    for char in string {
        // Each character requires grapheme cluster detection
        count += char.utf8.count
    }
    return count
}

func isASCII(_ string: String) -> Bool {
    for char in string {
        // O(n) grapheme cluster iteration
        if char.asciiValue == nil {
            return false
        }
    }
    return true
}
```

**Correct (direct UTF-8 access):**

```swift
func countBytes(_ string: String) -> Int {
    string.utf8.count  // O(1) for native Swift strings
}

func isASCII(_ string: String) -> Bool {
    for byte in string.utf8 {
        // Direct byte iteration, no grapheme detection
        if byte > 127 {
            return false
        }
    }
    return true
}
```

**Use for parsing and searching:**

```swift
// Fast ASCII-based parsing
func parseCSVLine(_ line: String) -> [Substring] {
    var fields: [Substring] = []
    var start = line.startIndex
    var inQuotes = false

    for i in line.utf8.indices {
        let byte = line.utf8[i]

        switch byte {
        case UInt8(ascii: "\""):
            inQuotes.toggle()
        case UInt8(ascii: ",") where !inQuotes:
            fields.append(line[start..<i])
            start = line.index(after: i)
        default:
            break
        }
    }

    fields.append(line[start...])
    return fields
}

// Fast byte search
func containsNullByte(_ string: String) -> Bool {
    string.utf8.contains(0)
}
```

**Compare with Data efficiently:**

```swift
// String to UTF-8 bytes
let bytes = Array(string.utf8)

// Or use withContiguousStorageIfAvailable for zero-copy
string.utf8.withContiguousStorageIfAvailable { buffer in
    // Direct pointer access to UTF-8 bytes
    processBytes(buffer)
}

// UTF-8 bytes to String
if let string = String(bytes: bytes, encoding: .utf8) {
    print(string)
}
```

**When to use Character iteration:**

```swift
// DO use Characters when:
// - Counting user-visible characters (emoji, accented letters)
// - Manipulating text at grapheme boundaries
// - Display/UI operations

let emoji = "👨‍👩‍👧‍👦"
emoji.count          // 1 (correct for display)
emoji.utf8.count     // 25 (bytes, not useful for display)

// DON'T use Characters for:
// - ASCII parsing (logs, protocols, file formats)
// - Byte counting
// - Hash computation
// - Network protocol implementation
```

**Use utf8CString for C interop:**

```swift
let cString = string.utf8CString  // Null-terminated [CChar]

// Or bridge directly
string.withCString { ptr in
    // ptr is UnsafePointer<CChar>
    strlen(ptr)
}
```

Reference: [String Performance](https://developer.apple.com/documentation/swift/string#overview)
