---
title: Use Lazy Sequences to Defer Computation
impact: HIGH
impactDescription: avoids intermediate allocations
tags: collections, swift6, lazy, sequences, functional, performance
---

## Use Lazy Sequences to Defer Computation

Use `.lazy` to defer sequence operations until elements are actually needed. This avoids creating intermediate arrays and enables early termination.

**Incorrect (creates intermediate arrays):**

```swift
let numbers = Array(1...1_000_000)

// Creates 3 intermediate arrays!
let result = numbers
    .map { $0 * 2 }          // Array 1: 1M elements
    .filter { $0 > 1000 }    // Array 2: ~999K elements
    .map { String($0) }      // Array 3: ~999K strings
    .first                   // Only needed ONE element!

// Memory: ~24MB for intermediate arrays
// Time: Processes all 1M elements even though we only need first match
```

**Correct (lazy evaluation):**

```swift
let numbers = Array(1...1_000_000)

// No intermediate arrays, stops at first match
let result = numbers.lazy
    .map { $0 * 2 }
    .filter { $0 > 1000 }
    .map { String($0) }
    .first

// Memory: O(1)
// Time: Processes only ~501 elements (until first > 1000)
```

**Perfect for prefix/first operations:**

```swift
// Find first 10 valid items
let validItems = allItems.lazy
    .filter { $0.isValid }
    .prefix(10)

// Convert to Array only when needed
let validArray = Array(validItems)
```

**Combine with other optimizations:**

```swift
// Lazy + short-circuit
func findUser(matching criteria: Criteria) -> User? {
    users.lazy
        .filter { $0.matchesCriteria(criteria) }  // Deferred
        .first  // Stops at first match
}

// Lazy + large data sets
func processLogs(_ logs: [LogEntry]) -> [Summary] {
    logs.lazy
        .filter { $0.level >= .warning }
        .map { summarize($0) }
        .prefix(100)  // Only need first 100 warnings
        .map(Array.init)  // Materialize only when needed
}
```

**When NOT to use lazy:**

```swift
// DON'T use lazy when you need all elements anyway
let allDoubled = numbers.lazy.map { $0 * 2 }
for n in allDoubled {  // Iterates everything
    print(n)
}
// Lazy adds overhead per-element, no benefit here

// DON'T use lazy with side effects
numbers.lazy.map {
    print($0)  // May never execute if result unused!
    return $0 * 2
}

// DO use eager evaluation when:
// - You need all elements
// - You'll iterate multiple times
// - The collection is small
let smallResult = smallArray.map { $0 * 2 }  // Fine without lazy
```

**Custom lazy operations:**

```swift
extension LazySequenceProtocol {
    func compactMapFirst<T>(_ transform: (Element) -> T?) -> T? {
        for element in self {
            if let result = transform(element) {
                return result
            }
        }
        return nil
    }
}

// Usage
let firstValidUser = users.lazy.compactMapFirst { user in
    user.isActive ? user : nil
}
```

Reference: [LazySequence Documentation](https://developer.apple.com/documentation/swift/lazysequence)
