---
title: Use final for Non-Inherited Classes
impact: MEDIUM
impactDescription: enables devirtualization
tags: compile, swift6, final, classes, optimization, devirtualization
---

## Use final for Non-Inherited Classes

Mark classes as `final` when they won't be subclassed. This allows the compiler to devirtualize method calls, replacing dynamic dispatch with direct calls.

**Incorrect (dynamic dispatch overhead):**

```swift
class NetworkClient {
    func fetch(url: URL) async throws -> Data {
        // Implementation
    }

    func post(url: URL, body: Data) async throws -> Data {
        // Implementation
    }
}

// Every call to fetch() or post() goes through vtable lookup
let client = NetworkClient()
let data = try await client.fetch(url: someURL)  // Dynamic dispatch
```

**Correct (direct dispatch):**

```swift
final class NetworkClient {
    func fetch(url: URL) async throws -> Data {
        // Implementation
    }

    func post(url: URL, body: Data) async throws -> Data {
        // Implementation
    }
}

// Compiler can inline or directly call methods
let client = NetworkClient()
let data = try await client.fetch(url: someURL)  // Direct call
```

**Mark individual methods as final:**

```swift
class BaseViewController: UIViewController {
    // Can be overridden
    func setupUI() {
        // Default implementation
    }

    // Cannot be overridden, enables optimization
    final func trackAnalytics() {
        // Analytics code - no subclass should change this
    }
}
```

**Private implies final:**

```swift
class DataManager {
    // Private methods are implicitly final
    private func internalProcess() {
        // Compiler treats as final
    }

    // File-private also implies final within the file
    fileprivate func helperMethod() {
        // Optimized as final
    }
}
```

**Whole Module Optimization helps:**

```swift
// With -whole-module-optimization, compiler can infer final
// for classes not subclassed within the module

// But explicit final is:
// 1. Self-documenting
// 2. Enforced across modules
// 3. Guaranteed optimization

// Enable in Package.swift:
.target(
    name: "MyTarget",
    swiftSettings: [.unsafeFlags(["-whole-module-optimization"])]
)
```

**Performance impact:**

```swift
// Dynamic dispatch: ~2-3 nanoseconds overhead per call
// Direct dispatch: ~0.3 nanoseconds

// In tight loops, this matters:
for _ in 0..<1_000_000 {
    client.process()  // 2-3 seconds with dynamic dispatch
                      // 0.3 seconds with final
}
```

**Combine with @inlinable for maximum optimization:**

```swift
public final class MathUtils {
    @inlinable
    public static func lerp(_ a: Double, _ b: Double, t: Double) -> Double {
        a + (b - a) * t
    }

    @inlinable
    public static func clamp(_ value: Double, min: Double, max: Double) -> Double {
        Swift.min(Swift.max(value, min), max)
    }
}

// Calls can be fully inlined across modules
```

Reference: [Swift Performance Tips](https://github.com/apple/swift/blob/main/docs/OptimizationTips.rst)
