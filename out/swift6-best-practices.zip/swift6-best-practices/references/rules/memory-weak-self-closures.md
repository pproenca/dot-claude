---
title: Use [weak self] in Escaping Closures
impact: CRITICAL
impactDescription: prevents retain cycles and memory leaks
tags: memory, swift6, weak, closures, retain-cycles, ARC
---

## Use [weak self] in Escaping Closures

Use `[weak self]` in escaping closures that may outlive `self` to prevent retain cycles. This is especially critical in async callbacks, notification observers, and timer handlers.

**Incorrect (retain cycle, memory leak):**

```swift
class NetworkManager {
    var onDataReceived: ((Data) -> Void)?
    private var urlSession: URLSession!

    func startFetching(url: URL) {
        // This closure captures self strongly
        urlSession.dataTask(with: url) { data, _, _ in
            if let data = data {
                self.processData(data)  // Strong reference to self
                self.onDataReceived?(data)
            }
        }.resume()
    }

    func processData(_ data: Data) {
        // Processing...
    }

    deinit {
        print("NetworkManager deallocated")  // Never called!
    }
}
```

**Correct (weak self prevents retain cycle):**

```swift
class NetworkManager {
    var onDataReceived: ((Data) -> Void)?
    private var urlSession: URLSession!

    func startFetching(url: URL) {
        urlSession.dataTask(with: url) { [weak self] data, _, _ in
            guard let self else { return }  // Swift 5.7+ unwrap syntax

            if let data = data {
                self.processData(data)
                self.onDataReceived?(data)
            }
        }.resume()
    }

    func processData(_ data: Data) {
        // Processing...
    }

    deinit {
        print("NetworkManager deallocated")  // Now called properly
    }
}
```

**For async/await, use Task with weak capture:**

```swift
class ViewModel {
    var data: [Item] = []

    func loadData() {
        Task { [weak self] in
            guard let self else { return }

            let items = try await fetchItems()
            await MainActor.run {
                self.data = items  // Safe, won't retain if deallocated
            }
        }
    }
}
```

**When strong capture is intentional:**

```swift
class OneTimeLoader {
    func loadOnce(completion: @escaping () -> Void) {
        // Strong capture is intentional - keeps self alive until completion
        URLSession.shared.dataTask(with: url) { [self] data, _, _ in
            self.process(data)
            completion()
            // self deallocates after this if no other references
        }.resume()
    }
}
```

**Use unowned when lifetime is guaranteed:**

```swift
class Parent {
    var child: Child!

    init() {
        // Child cannot outlive Parent, so unowned is safe
        child = Child(parent: self)
    }
}

class Child {
    unowned let parent: Parent  // Safe: parent always outlives child

    init(parent: Parent) {
        self.parent = parent
    }
}
```

Reference: [ARC in Swift](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/automaticreferencecounting/)
