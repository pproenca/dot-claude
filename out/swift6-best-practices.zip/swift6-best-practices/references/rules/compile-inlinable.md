---
title: Use @inlinable for Hot-Path Functions
impact: HIGH
impactDescription: enables cross-module optimization
tags: compile, swift6, inlinable, optimization, performance
---

## Use @inlinable for Hot-Path Functions

Mark frequently-called functions with `@inlinable` to allow the compiler to inline them across module boundaries. This enables aggressive optimizations for hot paths.

**Incorrect (no cross-module inlining):**

```swift
// In MyFramework module
public struct Vector3 {
    public var x, y, z: Double

    public init(x: Double, y: Double, z: Double) {
        self.x = x
        self.y = y
        self.z = z
    }

    // Cannot be inlined in client code
    public func dot(_ other: Vector3) -> Double {
        x * other.x + y * other.y + z * other.z
    }

    public func length() -> Double {
        sqrt(dot(self))
    }
}
```

Client code must make function calls across module boundary, preventing optimizations.

**Correct (enables inlining):**

```swift
// In MyFramework module
public struct Vector3 {
    public var x, y, z: Double

    @inlinable
    public init(x: Double, y: Double, z: Double) {
        self.x = x
        self.y = y
        self.z = z
    }

    @inlinable
    public func dot(_ other: Vector3) -> Double {
        x * other.x + y * other.y + z * other.z
    }

    @inlinable
    public func length() -> Double {
        sqrt(dot(self))
    }
}
```

Client code can now inline these operations, enabling SIMD vectorization and loop unrolling.

**Use @usableFromInline for private helpers:**

```swift
public struct Matrix4x4 {
    @usableFromInline
    var elements: (Double, Double, Double, Double,
                   Double, Double, Double, Double,
                   Double, Double, Double, Double,
                   Double, Double, Double, Double)

    @inlinable
    public func multiplied(by other: Matrix4x4) -> Matrix4x4 {
        // Implementation can reference @usableFromInline members
        multiplyImpl(self, other)
    }

    @usableFromInline
    func multiplyImpl(_ a: Matrix4x4, _ b: Matrix4x4) -> Matrix4x4 {
        // Internal implementation
    }
}
```

**When to use @inlinable:**

```swift
// DO use for:
// - Small, frequently-called functions
// - Generic algorithm implementations
// - Mathematical operations
// - Property accessors in performance-critical types

@inlinable
public func clamp<T: Comparable>(_ value: T, min: T, max: T) -> T {
    Swift.min(Swift.max(value, min), max)
}

// DON'T use for:
// - Large functions (increases binary size)
// - Functions likely to change (breaks ABI)
// - Functions with complex logic

// This would bloat client binaries:
// @inlinable  // DON'T
public func complexAlgorithm(_ data: [Int]) -> [Int] {
    // 100 lines of code...
}
```

**Combine with @frozen for complete optimization:**

```swift
@frozen
public struct SIMD4<Scalar: SIMDScalar> {
    public var x, y, z, w: Scalar

    @inlinable
    public static func + (lhs: SIMD4, rhs: SIMD4) -> SIMD4 {
        SIMD4(x: lhs.x + rhs.x, y: lhs.y + rhs.y,
              z: lhs.z + rhs.z, w: lhs.w + rhs.w)
    }
}
```

Reference: [SE-0193 Cross-module inlining](https://github.com/apple/swift-evolution/blob/main/proposals/0193-cross-module-inlining-and-specialization.md)
