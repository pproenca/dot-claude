---
title: Manage Substring Lifetime
impact: MEDIUM-HIGH
impactDescription: prevents unexpected memory retention
tags: strings, swift6, Substring, memory, lifetime
---

## Manage Substring Lifetime

Substrings share storage with their parent String. When storing substrings long-term, convert to String to avoid keeping large strings in memory.

**Incorrect (retains entire string):**

```swift
class LogParser {
    var errorMessages: [Substring] = []  // Retains parent strings!

    func parse(_ logFile: String) {
        for line in logFile.split(separator: "\n") {
            if line.hasPrefix("ERROR") {
                // Each Substring keeps the entire logFile alive
                errorMessages.append(line)
            }
        }
    }
}

// 100KB log file with 10 errors:
// Expected memory: ~1KB for error messages
// Actual memory: ~100KB (entire log retained)
```

**Correct (convert for storage):**

```swift
class LogParser {
    var errorMessages: [String] = []  // Owns the strings

    func parse(_ logFile: String) {
        for line in logFile.split(separator: "\n") {
            if line.hasPrefix("ERROR") {
                // Convert to String for independent storage
                errorMessages.append(String(line))
            }
        }
    }
}

// 100KB log file with 10 errors:
// Memory: ~1KB (only error messages retained)
```

**Use Substring for temporary operations:**

```swift
// Good: Substring for intermediate parsing
func extractValue(from line: String, key: String) -> String? {
    guard let keyRange = line.range(of: "\(key)=") else {
        return nil
    }

    let valueStart = keyRange.upperBound
    let valueEnd = line[valueStart...].firstIndex(of: " ") ?? line.endIndex

    // Substring for intermediate work
    let valueSubstring = line[valueStart..<valueEnd]

    // Convert to String only at the return
    return String(valueSubstring)
}

// Also good: Return Substring when caller will use immediately
func firstWord(of string: String) -> Substring {
    let end = string.firstIndex(of: " ") ?? string.endIndex
    return string[..<end]
}
```

**Indicate Substring return type clearly:**

```swift
// Make it clear that caller should convert if storing
extension String {
    /// Returns a Substring. Convert to String if storing long-term.
    func extractDomain() -> Substring? {
        guard let atIndex = firstIndex(of: "@") else { return nil }
        return self[index(after: atIndex)...]
    }
}

// Caller decides based on usage
let email = "user@example.com"
let domainSubstring = email.extractDomain()  // Temporary use OK
let domainString = email.extractDomain().map(String.init)  // For storage
```

**Split returns Substrings:**

```swift
let csv = "a,b,c,d,e"

// split() returns [Substring]
let parts = csv.split(separator: ",")  // Shares storage with csv

// For storage, convert explicitly
let storedParts: [String] = csv.split(separator: ",").map(String.init)

// Or use components() which returns [String]
let stringParts = csv.components(separatedBy: ",")  // Creates new Strings
```

**Check with Instruments:**

```swift
// Use Instruments > Allocations to detect:
// - Large String allocations that persist
// - Substrings keeping parent strings alive

// Look for String objects with size >> expected content
```

Reference: [Substring Documentation](https://developer.apple.com/documentation/swift/substring)
