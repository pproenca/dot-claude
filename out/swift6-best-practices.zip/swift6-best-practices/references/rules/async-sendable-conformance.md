---
title: Explicit Sendable Conformance
impact: CRITICAL
impactDescription: enables compile-time data race prevention
tags: async, swift6, Sendable, concurrency, thread-safety
---

## Explicit Sendable Conformance

In Swift 6, the compiler enforces `Sendable` requirements strictly. Mark value types as `Sendable` explicitly when they will cross actor boundaries. This enables compiler verification of thread safety.

**Incorrect (implicit Sendable, compiler warnings):**

```swift
// Swift 6 warns: type may not be Sendable
struct UserData {
    let id: UUID
    let name: String
    var preferences: [String: Any]  // [String: Any] is NOT Sendable!
}

actor UserManager {
    func process(_ data: UserData) {  // Warning: UserData may not be Sendable
        // ...
    }
}
```

**Correct (explicit Sendable with safe types):**

```swift
struct UserData: Sendable {
    let id: UUID
    let name: String
    let preferences: [String: String]  // Use Sendable types
}

actor UserManager {
    func process(_ data: UserData) {  // No warning, verified safe
        // ...
    }
}
```

**For classes, use @unchecked Sendable carefully:**

```swift
// Only when you can guarantee thread safety manually
final class ThreadSafeCache: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: [String: Data] = [:]

    func get(_ key: String) -> Data? {
        lock.lock()
        defer { lock.unlock() }
        return storage[key]
    }

    func set(_ key: String, value: Data) {
        lock.lock()
        defer { lock.unlock() }
        storage[key] = value
    }
}
```

**Use Sendable closures for actor boundaries:**

```swift
actor DataProcessor {
    func process(completion: @Sendable @escaping () -> Void) {
        Task {
            // work...
            completion()
        }
    }
}

// Caller must capture only Sendable values
let processor = DataProcessor()
let id = UUID()  // UUID is Sendable
await processor.process { [id] in
    print("Completed: \(id)")
}
```

Reference: [SE-0302 Sendable and @Sendable](https://github.com/apple/swift-evolution/blob/main/proposals/0302-concurrent-value-and-concurrent-closures.md)
