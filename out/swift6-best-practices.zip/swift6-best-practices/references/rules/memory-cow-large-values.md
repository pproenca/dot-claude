---
title: Implement Copy-on-Write for Large Value Types
impact: HIGH
impactDescription: avoids unnecessary copies of large data
tags: memory, swift6, copy-on-write, COW, value-types
---

## Implement Copy-on-Write for Large Value Types

For value types containing large data, implement Copy-on-Write (COW) to defer copying until mutation. This gives value semantics with reference type performance.

**Incorrect (copies entire buffer on every assignment):**

```swift
struct ImageBuffer {
    var pixels: [UInt8]

    mutating func setPixel(at index: Int, value: UInt8) {
        pixels[index] = value
    }
}

var buffer1 = ImageBuffer(pixels: Array(repeating: 0, count: 1_000_000))
var buffer2 = buffer1  // Copies 1MB immediately!
buffer2.setPixel(at: 0, value: 255)  // Already copied
```

**Correct (Copy-on-Write implementation):**

```swift
struct ImageBuffer {
    private var storage: ImageStorage

    init(pixels: [UInt8]) {
        storage = ImageStorage(pixels: pixels)
    }

    var pixels: [UInt8] {
        storage.pixels
    }

    mutating func setPixel(at index: Int, value: UInt8) {
        // Copy only if shared
        if !isKnownUniquelyReferenced(&storage) {
            storage = ImageStorage(pixels: storage.pixels)
        }
        storage.pixels[index] = value
    }
}

private final class ImageStorage {
    var pixels: [UInt8]

    init(pixels: [UInt8]) {
        self.pixels = pixels
    }
}

var buffer1 = ImageBuffer(pixels: Array(repeating: 0, count: 1_000_000))
var buffer2 = buffer1  // No copy yet, shares storage
buffer2.setPixel(at: 0, value: 255)  // Now copies (COW triggered)
// buffer1 unchanged, buffer2 has its own copy
```

**Generic COW wrapper:**

```swift
final class Box<T> {
    var value: T

    init(_ value: T) {
        self.value = value
    }
}

struct COW<T> {
    private var box: Box<T>

    init(_ value: T) {
        box = Box(value)
    }

    var value: T {
        get { box.value }
        set {
            if !isKnownUniquelyReferenced(&box) {
                box = Box(newValue)
            } else {
                box.value = newValue
            }
        }
    }

    mutating func mutate(_ transform: (inout T) -> Void) {
        if !isKnownUniquelyReferenced(&box) {
            box = Box(box.value)
        }
        transform(&box.value)
    }
}

// Usage
struct Document {
    private var content: COW<[Page]>

    mutating func appendPage(_ page: Page) {
        content.mutate { $0.append(page) }
    }
}
```

**Standard library types already use COW:**

```swift
// Array, Dictionary, Set, String all use COW
var array1 = [1, 2, 3, 4, 5]
var array2 = array1  // No copy yet
array2.append(6)     // COW triggered, array1 unchanged

// Your custom types should too when they wrap large data
```

Reference: [Copy-on-Write in Swift](https://developer.apple.com/documentation/swift/choosing-between-structures-and-classes)
