---
title: Optimize String Interpolation
impact: MEDIUM
impactDescription: reduces allocations in hot paths
tags: strings, swift6, interpolation, performance, formatting
---

## Optimize String Interpolation

String interpolation is convenient but creates intermediate strings. In hot paths, use append operations or pre-sized buffers for better performance.

**Incorrect (multiple intermediate strings):**

```swift
func buildLog(level: String, module: String, message: String, timestamp: Date) -> String {
    // Each interpolation creates intermediate strings
    let dateStr = "\(timestamp)"
    let prefix = "[\(level)]"
    let source = "(\(module))"

    return "\(dateStr) \(prefix) \(source): \(message)"
    // Creates ~5 intermediate strings
}

// In a loop, this compounds:
for i in 0..<10000 {
    logs.append("Item \(i): \(items[i].name) - \(items[i].value)")
}
```

**Correct (single buffer):**

```swift
func buildLog(level: String, module: String, message: String, timestamp: Date) -> String {
    var result = ""
    result.reserveCapacity(100)  // Estimate final size

    result.append(timestamp.description)
    result.append(" [")
    result.append(level)
    result.append("] (")
    result.append(module)
    result.append("): ")
    result.append(message)

    return result
}

// Or use a custom interpolation type
struct LogMessage: CustomStringConvertible {
    let level: String
    let module: String
    let message: String
    let timestamp: Date

    var description: String {
        "\(timestamp) [\(level)] (\(module)): \(message)"
    }
}
```

**Custom string interpolation for type safety:**

```swift
struct SQLQuery: ExpressibleByStringInterpolation {
    var sql: String
    var parameters: [Any]

    init(stringLiteral value: String) {
        sql = value
        parameters = []
    }

    init(stringInterpolation: StringInterpolation) {
        sql = stringInterpolation.sql
        parameters = stringInterpolation.parameters
    }

    struct StringInterpolation: StringInterpolationProtocol {
        var sql = ""
        var parameters: [Any] = []

        init(literalCapacity: Int, interpolationCount: Int) {
            sql.reserveCapacity(literalCapacity)
            parameters.reserveCapacity(interpolationCount)
        }

        mutating func appendLiteral(_ literal: String) {
            sql.append(literal)
        }

        mutating func appendInterpolation(_ value: some Any) {
            sql.append("?")
            parameters.append(value)
        }
    }
}

// Usage: Type-safe SQL with parameterized queries
let query: SQLQuery = "SELECT * FROM users WHERE id = \(userId)"
// query.sql = "SELECT * FROM users WHERE id = ?"
// query.parameters = [userId]
```

**Use DefaultStringInterpolation for debugging:**

```swift
extension DefaultStringInterpolation {
    mutating func appendInterpolation(debug value: some Any) {
        #if DEBUG
        appendLiteral(String(reflecting: value))
        #else
        appendLiteral("<redacted>")
        #endif
    }
}

// Usage
print("User data: \(debug: sensitiveUserData)")
```

**Benchmark:**

```swift
// 10,000 iterations:
// Interpolation: ~15ms
// Append operations: ~8ms
// Pre-reserved buffer: ~5ms

// For infrequent calls, interpolation is fine
// For hot paths (logging, serialization), optimize
```

Reference: [SE-0228 String Interpolation](https://github.com/apple/swift-evolution/blob/main/proposals/0228-fix-expressiblebystringinterpolation.md)
