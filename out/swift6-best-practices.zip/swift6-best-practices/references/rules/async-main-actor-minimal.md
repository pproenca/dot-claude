---
title: Minimize @MainActor Usage
impact: CRITICAL
impactDescription: reduces actor hopping overhead
tags: async, swift6, MainActor, concurrency, isolation
---

## Minimize @MainActor Usage

Only apply `@MainActor` to code that directly updates the UI. Marking entire types or functions as `@MainActor` when only a subset needs main thread access causes unnecessary actor hops and blocks the main thread.

**Incorrect (entire class on MainActor):**

```swift
@MainActor
class DataProcessor {
    var results: [Result] = []

    // This heavy computation blocks the main thread!
    func processData(_ data: [Data]) async {
        for item in data {
            let result = await heavyComputation(item)  // Runs on main thread
            results.append(result)
        }
        updateUI()  // Only this needs MainActor
    }

    func heavyComputation(_ data: Data) async -> Result {
        // CPU-intensive work blocking UI
        return Result(data: data)
    }

    func updateUI() {
        // Update labels, etc.
    }
}
```

**Correct (minimal MainActor scope):**

```swift
class DataProcessor {
    @MainActor var results: [Result] = []

    func processData(_ data: [Data]) async {
        var localResults: [Result] = []

        for item in data {
            let result = await heavyComputation(item)  // Runs off main thread
            localResults.append(result)
        }

        await MainActor.run {
            results = localResults
            updateUI()
        }
    }

    nonisolated func heavyComputation(_ data: Data) async -> Result {
        // CPU-intensive work on background
        return Result(data: data)
    }

    @MainActor func updateUI() {
        // Update labels, etc.
    }
}
```

**Alternative: Use nonisolated for pure computations:**

```swift
@MainActor
class ViewModel {
    var displayText: String = ""

    // Pure computation doesn't need actor isolation
    nonisolated func formatNumber(_ value: Double) -> String {
        String(format: "%.2f", value)
    }

    func update(with value: Double) {
        displayText = formatNumber(value)  // No actor hop needed
    }
}
```

Reference: [Swift Concurrency Documentation](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/)
