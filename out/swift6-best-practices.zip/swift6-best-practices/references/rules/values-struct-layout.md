---
title: Optimize Struct Memory Layout
impact: MEDIUM
impactDescription: reduces memory usage and improves cache efficiency
tags: values, swift6, structs, memory-layout, optimization
---

## Optimize Struct Memory Layout

Order struct properties to minimize padding and fit within cache lines. Swift respects declaration order for stored properties.

**Incorrect (poor alignment, wasted padding):**

```swift
struct PoorlyAligned {
    var a: Bool      // 1 byte  + 7 padding
    var b: Int64     // 8 bytes
    var c: Bool      // 1 byte  + 7 padding
    var d: Int64     // 8 bytes
    var e: Bool      // 1 byte  + 7 padding
    var f: Int64     // 8 bytes
}
// Total: 48 bytes (18 bytes data + 30 bytes padding)

print(MemoryLayout<PoorlyAligned>.size)    // 48
print(MemoryLayout<PoorlyAligned>.stride)  // 48
```

**Correct (optimal alignment):**

```swift
struct WellAligned {
    var b: Int64     // 8 bytes
    var d: Int64     // 8 bytes
    var f: Int64     // 8 bytes
    var a: Bool      // 1 byte
    var c: Bool      // 1 byte
    var e: Bool      // 1 byte  + 5 padding
}
// Total: 32 bytes (27 bytes data + 5 bytes padding)

print(MemoryLayout<WellAligned>.size)    // 32
print(MemoryLayout<WellAligned>.stride)  // 32
```

**General ordering rule:**

```swift
struct OptimalLayout {
    // 1. Largest alignment first (8-byte types)
    var pointer: UnsafeRawPointer?
    var int64: Int64
    var double: Double

    // 2. Medium alignment (4-byte types)
    var int32: Int32
    var float: Float

    // 3. Small alignment (2-byte types)
    var int16: Int16
    var char: UInt16

    // 4. Byte types last
    var byte1: UInt8
    var byte2: UInt8
    var bool1: Bool
    var bool2: Bool
}
```

**Pack related booleans with OptionSet:**

```swift
// Instead of multiple bools
struct PoorFlags {
    var isEnabled: Bool     // 1 + 7 padding
    var isVisible: Bool     // 1 + 7 padding
    var isSelected: Bool    // 1 + 7 padding
    var isHighlighted: Bool // 1 + 7 padding
}
// 32 bytes for 4 bits of data

// Use OptionSet for dense packing
struct Flags: OptionSet {
    let rawValue: UInt8

    static let enabled     = Flags(rawValue: 1 << 0)
    static let visible     = Flags(rawValue: 1 << 1)
    static let selected    = Flags(rawValue: 1 << 2)
    static let highlighted = Flags(rawValue: 1 << 3)
}
// 1 byte for 4 bits (can hold 8 flags)
```

**Consider cache line size (64 bytes):**

```swift
// Hot data should fit in one cache line
struct CacheOptimized {
    // Frequently accessed together - 64 bytes
    var position: SIMD3<Float>  // 16 bytes
    var velocity: SIMD3<Float>  // 16 bytes
    var acceleration: SIMD3<Float> // 16 bytes
    var mass: Float             // 4 bytes
    var flags: UInt32           // 4 bytes
    // Total: 56 bytes - fits in cache line

    // Rarely accessed - separate allocation or lazy
    var metadata: ParticleMetadata?
}
```

**Use MemoryLayout to verify:**

```swift
struct MyStruct {
    var a: Int64
    var b: Int32
    var c: Int16
    var d: Int8
}

print("Size:", MemoryLayout<MyStruct>.size)        // 15
print("Stride:", MemoryLayout<MyStruct>.stride)    // 16
print("Alignment:", MemoryLayout<MyStruct>.alignment) // 8

// Offset of each field
print(MemoryLayout<MyStruct>.offset(of: \MyStruct.a)!) // 0
print(MemoryLayout<MyStruct>.offset(of: \MyStruct.b)!) // 8
print(MemoryLayout<MyStruct>.offset(of: \MyStruct.c)!) // 12
print(MemoryLayout<MyStruct>.offset(of: \MyStruct.d)!) // 14
```

Reference: [Memory Layout](https://developer.apple.com/documentation/swift/memorylayout)
