---
title: Use inout for Large Struct Mutations
impact: MEDIUM
impactDescription: avoids copying large value types
tags: values, swift6, inout, structs, mutation, performance
---

## Use inout for Large Struct Mutations

When mutating large value types, use `inout` parameters to modify in-place rather than returning a copy. This avoids the overhead of copying the entire struct.

**Incorrect (copies on mutation):**

```swift
struct GameState {
    var players: [Player]          // ~1KB
    var board: [[Tile]]            // ~10KB
    var history: [Move]            // ~5KB
    var settings: GameSettings     // ~200B
}

func addPlayer(_ state: GameState, player: Player) -> GameState {
    var newState = state           // Copies ~16KB
    newState.players.append(player)
    return newState                // Another copy potential
}

func makeMove(_ state: GameState, move: Move) -> GameState {
    var newState = state           // Copies ~16KB each time
    newState.board[move.row][move.col] = move.tile
    newState.history.append(move)
    return newState
}

// Each move copies 16KB × 2
```

**Correct (in-place mutation):**

```swift
struct GameState {
    var players: [Player]
    var board: [[Tile]]
    var history: [Move]
    var settings: GameSettings

    mutating func addPlayer(_ player: Player) {
        players.append(player)     // Modifies in-place
    }

    mutating func makeMove(_ move: Move) {
        board[move.row][move.col] = move.tile
        history.append(move)       // No copying
    }
}

// Or with free functions using inout
func addPlayer(_ state: inout GameState, player: Player) {
    state.players.append(player)
}

func makeMove(_ state: inout GameState, move: Move) {
    state.board[move.row][move.col] = move.tile
    state.history.append(move)
}

// Usage
var gameState = GameState(...)
gameState.addPlayer(newPlayer)     // In-place
gameState.makeMove(move)           // No copies
```

**Use inout for collection transforms:**

```swift
// Incorrect - creates new array
func normalize(_ values: [Double]) -> [Double] {
    let max = values.max() ?? 1
    return values.map { $0 / max }  // New array allocation
}

// Correct - modifies in place
func normalize(_ values: inout [Double]) {
    guard let max = values.max(), max != 0 else { return }
    for i in values.indices {
        values[i] /= max  // In-place modification
    }
}

// Usage
var data = [1.0, 2.0, 3.0, 4.0, 5.0]
normalize(&data)  // data is now [0.2, 0.4, 0.6, 0.8, 1.0]
```

**Combine with COW for flexibility:**

```swift
struct Document {
    private var storage: DocumentStorage

    // Public read access
    var pages: [Page] { storage.pages }

    // Mutating method with COW
    mutating func appendPage(_ page: Page) {
        if !isKnownUniquelyReferenced(&storage) {
            storage = DocumentStorage(pages: storage.pages)
        }
        storage.pages.append(page)
    }
}

// Or use inout for batch operations
func batchUpdate(_ document: inout Document, pages: [Page]) {
    for page in pages {
        document.appendPage(page)
    }
}
```

**When NOT to use inout:**

```swift
// Small structs - copy is cheap
struct Point {
    var x, y: Double
}

func offset(_ point: Point, by delta: Point) -> Point {
    Point(x: point.x + delta.x, y: point.y + delta.y)
}

// When immutability is important for safety
func processData(_ data: [Int]) -> [Int] {
    // Return new array to preserve original
    data.map { $0 * 2 }
}

// When you need the original and modified versions
let original = gameState
var modified = gameState
modified.makeMove(move)
// Now have both versions
```

Reference: [In-Out Parameters](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/#In-Out-Parameters)
