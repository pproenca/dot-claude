---
title: Control Generic Specialization
impact: HIGH
impactDescription: balances compile time vs runtime performance
tags: compile, swift6, generics, specialization, binary-size
---

## Control Generic Specialization

Generic functions are specialized for each concrete type, which improves runtime performance but increases compile time and binary size. Control specialization for optimal balance.

**Problem (excessive specialization):**

```swift
// Each call site with different types creates new specialization
public func process<T: Numeric>(_ values: [T]) -> T {
    values.reduce(0, +)
}

// Generates separate code for:
process([1, 2, 3] as [Int])      // Int specialization
process([1.0, 2.0] as [Double])  // Double specialization
process([1, 2] as [Float])       // Float specialization
// ... potentially dozens of specializations
```

**Solution 1: Use type erasure for infrequent paths:**

```swift
// For rarely-used types, use existential to avoid specialization
protocol AnyProcessor {
    func process(_ values: [any Numeric]) -> any Numeric
}

// Only hot paths get specialized
@inlinable
public func processInts(_ values: [Int]) -> Int {
    values.reduce(0, +)
}

@inlinable
public func processDoubles(_ values: [Double]) -> Double {
    values.reduce(0, +)
}
```

**Solution 2: Use @_specialize for critical types:**

```swift
// Explicit specialization hints
@_specialize(where T == Int)
@_specialize(where T == Double)
public func process<T: Numeric>(_ values: [T]) -> T {
    values.reduce(0, +)
}

// Compiler prioritizes these specializations
// Other types use generic implementation
```

**Solution 3: Constrain generics more tightly:**

```swift
// Instead of overly broad constraint
func sort<T: Comparable>(_ array: inout [T]) { }

// Use protocol with fewer conforming types
func sort<T: BinaryInteger>(_ array: inout [T]) { }

// Or specific types
func sort(_ array: inout [Int]) { }
```

**Measure specialization impact:**

```swift
// Check binary size contribution
// In terminal:
// nm -size <binary> | grep 'process' | sort -n

// Use Xcode's Build Settings:
// - SWIFT_COMPILATION_MODE = wholemodule (enables optimization)
// - SWIFT_OPTIMIZATION_LEVEL = -O or -Osize
```

**Whole Module Optimization settings:**

```swift
// In Package.swift
.target(
    name: "MyLibrary",
    swiftSettings: [
        .unsafeFlags(["-whole-module-optimization"], .when(configuration: .release))
    ]
)

// Or in Xcode: Build Settings > Swift Compiler > Optimization Level
// - Debug: None [-Onone]
// - Release: Optimize for Speed [-O] or Optimize for Size [-Osize]
```

**Balance with @_semantics (internal use):**

```swift
// Standard library uses these to control optimization
// Not for general use, but understanding helps

// Prevent inlining when function is large
@_semantics("optimize.no.inline")
func largeGenericFunction<T>(_ value: T) { }

// Force specialization for critical paths
@_semantics("specialize.always")
func criticalPath<T>(_ value: T) { }
```

Reference: [Generics Manifesto](https://github.com/apple/swift/blob/main/docs/GenericsManifesto.md)
