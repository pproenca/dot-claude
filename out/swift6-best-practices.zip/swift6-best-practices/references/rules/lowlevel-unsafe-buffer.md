---
title: Use Unsafe Buffer Pointers for Bulk Operations
impact: LOW-MEDIUM
impactDescription: eliminates bounds checking in hot loops
tags: lowlevel, swift6, unsafe, buffers, performance
---

## Use Unsafe Buffer Pointers for Bulk Operations

For performance-critical loops over contiguous data, use `withUnsafeBufferPointer` to eliminate bounds checking and enable vectorization.

**Incorrect (bounds checking on every access):**

```swift
func dotProduct(_ a: [Double], _ b: [Double]) -> Double {
    precondition(a.count == b.count)
    var sum = 0.0

    for i in 0..<a.count {
        sum += a[i] * b[i]  // Bounds check on each access
    }

    return sum
}
```

**Correct (direct pointer access):**

```swift
func dotProduct(_ a: [Double], _ b: [Double]) -> Double {
    precondition(a.count == b.count)

    return a.withUnsafeBufferPointer { aBuffer in
        b.withUnsafeBufferPointer { bBuffer in
            var sum = 0.0
            for i in 0..<aBuffer.count {
                // No bounds checking, can be vectorized
                sum += aBuffer[i] * bBuffer[i]
            }
            return sum
        }
    }
}
```

**Even faster with pointer arithmetic:**

```swift
func dotProduct(_ a: [Double], _ b: [Double]) -> Double {
    precondition(a.count == b.count)
    let count = a.count

    return a.withUnsafeBufferPointer { aBuffer in
        b.withUnsafeBufferPointer { bBuffer in
            var sum = 0.0
            var aPtr = aBuffer.baseAddress!
            var bPtr = bBuffer.baseAddress!

            for _ in 0..<count {
                sum += aPtr.pointee * bPtr.pointee
                aPtr += 1
                bPtr += 1
            }

            return sum
        }
    }
}
```

**Mutable access with withUnsafeMutableBufferPointer:**

```swift
func normalize(_ values: inout [Double]) {
    guard let max = values.max(), max != 0 else { return }

    values.withUnsafeMutableBufferPointer { buffer in
        for i in buffer.indices {
            buffer[i] /= max
        }
    }
}

// Or with pointer arithmetic
func scaleInPlace(_ values: inout [Double], by factor: Double) {
    values.withUnsafeMutableBufferPointer { buffer in
        var ptr = buffer.baseAddress!
        let end = ptr + buffer.count

        while ptr < end {
            ptr.pointee *= factor
            ptr += 1
        }
    }
}
```

**Check for contiguous storage first:**

```swift
func processData<C: Collection>(_ data: C) where C.Element == Double {
    // Try contiguous fast path
    if let result = data.withContiguousStorageIfAvailable({ buffer in
        // Fast path: direct buffer access
        buffer.reduce(0, +)
    }) {
        print("Sum: \(result)")
        return
    }

    // Fallback: regular iteration
    let sum = data.reduce(0, +)
    print("Sum: \(sum)")
}
```

**Safety guidelines:**

```swift
// ALWAYS:
// - Check count before accessing
// - Ensure buffer lifetime covers usage
// - Keep unsafe code minimal and contained

// NEVER:
// - Store buffer pointers beyond the closure
// - Access beyond buffer bounds
// - Assume non-nil baseAddress without checking

func safeBufferAccess(_ array: [Int]) {
    array.withUnsafeBufferPointer { buffer in
        guard let base = buffer.baseAddress, buffer.count > 0 else {
            return
        }
        // Safe to use base pointer now
        print(base.pointee)
    }
    // buffer pointer is invalid here - DO NOT USE
}
```

Reference: [UnsafeBufferPointer](https://developer.apple.com/documentation/swift/unsafebufferpointer)
