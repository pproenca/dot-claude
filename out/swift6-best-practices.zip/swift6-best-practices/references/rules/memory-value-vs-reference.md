---
title: Prefer Value Types to Reduce Allocations
impact: HIGH
impactDescription: reduces heap allocations and ARC overhead
tags: memory, swift6, struct, class, value-types, allocations
---

## Prefer Value Types to Reduce Allocations

Use structs instead of classes when you don't need reference semantics. Value types are stack-allocated (when possible), avoiding heap allocation and ARC overhead.

**Incorrect (unnecessary heap allocation):**

```swift
class Point {
    var x: Double
    var y: Double

    init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
}

func calculateDistances(points: [Point]) -> [Double] {
    // Each Point is heap-allocated with ARC overhead
    points.map { sqrt($0.x * $0.x + $0.y * $0.y) }
}

// Creating 1M points = 1M heap allocations
let points = (0..<1_000_000).map { Point(x: Double($0), y: Double($0)) }
```

**Correct (stack allocation, no ARC):**

```swift
struct Point {
    var x: Double
    var y: Double
}

func calculateDistances(points: [Point]) -> [Double] {
    // Points are stored inline in the array, no individual allocations
    points.map { sqrt($0.x * $0.x + $0.y * $0.y) }
}

// Creating 1M points = 1 array allocation, points inline
let points = (0..<1_000_000).map { Point(x: Double($0), y: Double($0)) }
```

**When to use classes:**

```swift
// 1. When you need identity (same instance, not equal values)
class DatabaseConnection {
    let connectionId: UUID
    // ...
}

// 2. When you need inheritance
class Vehicle { }
class Car: Vehicle { }

// 3. When the type is very large and copying is expensive
class LargeBuffer {
    var data: [UInt8]  // Megabytes of data

    init(size: Int) {
        data = [UInt8](repeating: 0, count: size)
    }
}

// 4. When you need deinit for cleanup
class FileHandle {
    let handle: Int32

    deinit {
        close(handle)
    }
}
```

**Measure with Instruments:**

```swift
// Check if your structs are actually stack-allocated
struct SmallStruct {  // Likely stack-allocated
    var a: Int
    var b: Int
}

struct LargeStruct {  // May be heap-allocated
    var data: [Int]  // Array causes heap allocation anyway
}

// Use Instruments > Allocations to verify
```

**Consider final classes for reference semantics with less overhead:**

```swift
// 'final' allows compiler optimizations
final class OptimizedNode {
    var value: Int
    var next: OptimizedNode?

    init(value: Int) {
        self.value = value
    }
}
```

Reference: [Value and Reference Types](https://developer.apple.com/swift/blog/?id=10)
