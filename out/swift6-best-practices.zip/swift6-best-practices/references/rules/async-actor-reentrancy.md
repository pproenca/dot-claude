---
title: Handle Actor Reentrancy
impact: CRITICAL
impactDescription: prevents subtle state corruption bugs
tags: async, swift6, actor, reentrancy, state-management
---

## Handle Actor Reentrancy

Actors can be reentered at any `await` point. State may change between suspension points. Always re-validate state after awaiting, or capture state before suspension.

**Incorrect (assumes state unchanged across await):**

```swift
actor BankAccount {
    var balance: Decimal = 1000

    func withdraw(_ amount: Decimal) async throws {
        guard balance >= amount else {
            throw BankError.insufficientFunds
        }

        // Another withdrawal could complete here!
        await recordTransaction(amount)

        // balance may have changed, could go negative
        balance -= amount
    }

    func recordTransaction(_ amount: Decimal) async {
        // Simulates async database write
        try? await Task.sleep(for: .milliseconds(100))
    }
}
```

Two concurrent `withdraw(600)` calls could both pass the guard and cause negative balance.

**Correct (re-validate or capture state):**

```swift
actor BankAccount {
    var balance: Decimal = 1000

    func withdraw(_ amount: Decimal) async throws {
        // Option 1: Re-validate after each await
        guard balance >= amount else {
            throw BankError.insufficientFunds
        }

        await recordTransaction(amount)

        // Re-validate after suspension
        guard balance >= amount else {
            throw BankError.insufficientFunds
        }

        balance -= amount
    }
}
```

**Better: Use synchronous state transitions:**

```swift
actor BankAccount {
    var balance: Decimal = 1000
    private var pendingWithdrawals: Decimal = 0

    func withdraw(_ amount: Decimal) async throws {
        // Synchronous reservation (no suspension)
        let availableBalance = balance - pendingWithdrawals
        guard availableBalance >= amount else {
            throw BankError.insufficientFunds
        }
        pendingWithdrawals += amount

        do {
            await recordTransaction(amount)
            // Commit the withdrawal
            balance -= amount
            pendingWithdrawals -= amount
        } catch {
            // Rollback on failure
            pendingWithdrawals -= amount
            throw error
        }
    }
}
```

**Alternative: Process requests serially with AsyncStream:**

```swift
actor OrderProcessor {
    private var orderStream: AsyncStream<Order>.Continuation?

    init() {
        let (stream, continuation) = AsyncStream<Order>.makeStream()
        self.orderStream = continuation

        Task {
            for await order in stream {
                await processOrder(order)  // Serial processing
            }
        }
    }

    func submit(_ order: Order) {
        orderStream?.yield(order)
    }
}
```

Reference: [Actor Reentrancy in Swift](https://developer.apple.com/videos/play/wwdc2021/10133/)
