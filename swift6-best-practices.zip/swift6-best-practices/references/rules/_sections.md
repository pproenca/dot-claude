# Sections

This file defines all sections, their ordering, impact levels, and descriptions.
The section ID (in parentheses) is the filename prefix used to group rules.

---

## 1. Concurrency & Actors (async)

**Impact:** CRITICAL
**Description:** Swift 6 introduces strict concurrency checking by default. Proper use of actors, Sendable conformance, and structured concurrency eliminates data races at compile time and enables safe parallel execution. Misuse leads to runtime crashes or excessive actor hopping overhead.

## 2. Memory Management (memory)

**Impact:** CRITICAL
**Description:** Swift uses Automatic Reference Counting (ARC). Understanding retain cycles, choosing between weak/unowned references, and minimizing allocations directly impacts memory footprint and performance. Improper ARC usage causes memory leaks or crashes.

## 3. Collection Performance (collections)

**Impact:** HIGH
**Description:** Swift's standard library collections are highly optimized, but choosing the right collection type and access patterns can yield 2-10× improvements. Includes Array, ContiguousArray, Dictionary, Set, and lazy sequences.

## 4. Compile Time & Binary Size (compile)

**Impact:** HIGH
**Description:** Swift's type system and generics can lead to long compile times and code bloat. Strategic use of `@inlinable`, whole-module optimization, and avoiding unnecessary generic specialization improves both build times and runtime performance.

## 5. String Performance (strings)

**Impact:** MEDIUM-HIGH
**Description:** Swift strings are Unicode-correct by default, which introduces complexity. Understanding String vs Substring, UTF-8 views, and efficient character iteration prevents performance pitfalls common in text processing.

## 6. Protocol & Generics (protocols)

**Impact:** MEDIUM
**Description:** Protocols with associated types and existential containers have different performance characteristics than concrete generics. Choosing between protocol witnesses and generic specialization affects both compile time and runtime performance.

## 7. Value Semantics (values)

**Impact:** MEDIUM
**Description:** Swift's emphasis on value types enables safe concurrent code and predictable performance. Implementing Copy-on-Write correctly, choosing between structs and classes, and understanding when copies occur is essential for performance.

## 8. Low-Level Optimization (lowlevel)

**Impact:** LOW-MEDIUM
**Description:** For performance-critical code, Swift provides unsafe APIs, manual memory management, and SIMD operations. These patterns sacrifice safety for speed and should only be used when profiling indicates necessity.
