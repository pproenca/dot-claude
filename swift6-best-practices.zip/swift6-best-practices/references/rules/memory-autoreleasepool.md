---
title: Use autoreleasepool in Tight Loops
impact: CRITICAL
impactDescription: prevents memory spikes with Foundation objects
tags: memory, swift6, autoreleasepool, Foundation, loops
---

## Use autoreleasepool in Tight Loops

When creating many temporary Foundation objects (NSString, NSData, etc.) in loops, wrap the loop body in `autoreleasepool` to release memory promptly instead of waiting for the outer pool to drain.

**Incorrect (memory accumulates until function returns):**

```swift
func processImages(urls: [URL]) -> [UIImage] {
    var images: [UIImage] = []

    for url in urls {
        // These autoreleased objects accumulate
        let data = try? Data(contentsOf: url)
        if let data = data,
           let image = UIImage(data: data) {
            let processed = applyFilters(image)  // More temp objects
            images.append(processed)
        }
    }

    return images  // Memory spike: all temp objects released here
}
```

Processing 1000 images could spike memory to gigabytes before releasing.

**Correct (memory released each iteration):**

```swift
func processImages(urls: [URL]) -> [UIImage] {
    var images: [UIImage] = []
    images.reserveCapacity(urls.count)

    for url in urls {
        autoreleasepool {
            let data = try? Data(contentsOf: url)
            if let data = data,
               let image = UIImage(data: data) {
                let processed = applyFilters(image)
                images.append(processed)
            }
        }  // Temp objects released here, each iteration
    }

    return images
}
```

**For async contexts:**

```swift
func processImagesAsync(urls: [URL]) async -> [UIImage] {
    var images: [UIImage] = []

    for url in urls {
        let image = await withCheckedContinuation { continuation in
            autoreleasepool {
                let data = try? Data(contentsOf: url)
                let image = data.flatMap { UIImage(data: $0) }
                let processed = image.map { applyFilters($0) }
                continuation.resume(returning: processed)
            }
        }

        if let image = image {
            images.append(image)
        }
    }

    return images
}
```

**Batch processing optimization:**

```swift
func processLargeDataset(_ items: [Item]) -> [Result] {
    var results: [Result] = []
    results.reserveCapacity(items.count)

    // Process in batches to balance overhead vs memory
    let batchSize = 100
    for batch in items.chunks(ofCount: batchSize) {
        autoreleasepool {
            for item in batch {
                let result = process(item)
                results.append(result)
            }
        }
    }

    return results
}
```

**When NOT needed:**

```swift
// Pure Swift types don't use autorelease pools
func processNumbers(_ numbers: [Int]) -> [Int] {
    var results: [Int] = []
    for n in numbers {
        results.append(n * 2)  // No autoreleasepool needed
    }
    return results
}
```

Reference: [Memory Management in Swift](https://developer.apple.com/documentation/swift/using-autorelease-pool-blocks)
