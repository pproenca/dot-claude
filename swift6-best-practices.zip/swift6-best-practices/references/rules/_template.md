# Rule Template

Use this template when creating new rules.

---

```markdown
---
title: Rule Title Here
impact: MEDIUM
impactDescription: brief description of improvement
tags: category, swift6, specific-concept
---

## Rule Title Here

Brief explanation of the rule and why it matters in Swift 6 context.

**Incorrect ({description of problem}):**

```swift
// Bad code example
func badExample() {
    // problematic pattern
}
```

**Correct ({description of solution}):**

```swift
// Good code example
func goodExample() {
    // optimized pattern
}
```

Reference: [Swift Documentation](https://docs.swift.org/swift-book/)
```
