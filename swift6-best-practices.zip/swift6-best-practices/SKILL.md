---
name: swift6-best-practices
description: Swift 6 performance optimization guidelines. This skill should be used when writing, reviewing, or refactoring Swift 6 code to ensure optimal performance patterns. Triggers on tasks involving Swift concurrency, actor isolation, memory management, collection operations, or performance improvements.
---

# Swift 6 Best Practices

## Overview

Comprehensive performance optimization guide for Swift 6 applications, containing 45+ rules across 8 categories. Rules are prioritized by impact to guide automated refactoring and code generation. Emphasizes Swift 6's strict concurrency model, Sendable requirements, and modern Swift idioms.

## When to Apply

Reference these guidelines when:
- Writing new Swift 6 code with strict concurrency
- Implementing async/await and actor-based patterns
- Reviewing code for performance issues
- Refactoring existing Swift code to Swift 6
- Optimizing memory usage and ARC overhead
- Improving collection and string operations

## Priority-Ordered Guidelines

Rules are prioritized by impact:

| Priority | Category | Impact |
|----------|----------|--------|
| 1 | Concurrency & Actors (async) | CRITICAL |
| 2 | Memory Management (memory) | CRITICAL |
| 3 | Collection Performance (collections) | HIGH |
| 4 | Compile Time & Binary Size (compile) | HIGH |
| 5 | String Performance (strings) | MEDIUM-HIGH |
| 6 | Protocol & Generics (protocols) | MEDIUM |
| 7 | Value Semantics (values) | MEDIUM |
| 8 | Low-Level Optimization (lowlevel) | LOW-MEDIUM |

## Quick Reference

### Critical Patterns (Apply First)

**Concurrency & Actors:**
- Use `@MainActor` only where UI updates occur
- Prefer `nonisolated` for pure computations
- Use `TaskGroup` for parallel work, not multiple `Task {}`
- Mark value types as `Sendable` explicitly
- Use `AsyncStream` for bridging callback APIs

**Memory Management:**
- Use `[weak self]` in escaping closures that outlive `self`
- Prefer `unowned` when lifetime is guaranteed
- Use `autoreleasepool` in tight loops with Foundation objects
- Enable Copy-on-Write for large value types

### High-Impact Patterns

- Use `ContiguousArray` for non-bridged element types
- Prefer `Dictionary(uniqueKeysWithValues:)` over loops
- Use `lazy` sequences to defer computation
- Mark hot-path functions with `@inlinable`
- Use `@_specialize` for critical generic functions

### Medium-Impact Patterns

- Prefer `Substring` over `String` for temporary slices
- Use `utf8` view for byte-level string operations
- Avoid existentials in hot paths; use generics
- Implement Copy-on-Write for custom value types
- Use `reserveCapacity(_:)` before bulk insertions

## References

Full documentation with code examples is available in:

- `references/swift6-performance-guidelines.md` - Complete guide with all patterns
- `references/rules/` - Individual rule files organized by category

To look up a specific pattern, grep the rules directory:
```
grep -l "actor" references/rules/
grep -l "Sendable" references/rules/
grep -l "ContiguousArray" references/rules/
grep -l "inlinable" references/rules/
```

## Rule Categories in `references/rules/`

- `async-*` - Concurrency, actors, and async/await patterns
- `memory-*` - ARC optimization, retain cycles, allocations
- `collections-*` - Array, Dictionary, Set performance
- `compile-*` - Build time, binary size, specialization
- `strings-*` - String and character manipulation
- `protocols-*` - Protocol witnesses, generics, type erasure
- `values-*` - Value semantics, Copy-on-Write, structs
- `lowlevel-*` - Unsafe operations, pointers, SIMD
